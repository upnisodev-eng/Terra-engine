// ============================================================
// TERRA ENGINE — PROCEDURAL SKY SHADER
// skybox.frag
// ============================================================
// Physically-based sky model (Preetham / Rayleigh scattering).
// Dynamic: changes with time of day, weather, corruption.
// Sun disk with corona. Moon with craters. Star field at night.
// Corruption shifts sky to sickly purple-grey.
// ============================================================

#version 460

layout(location = 0) in vec3  in_dir;
layout(location = 0) out vec4 out_colour;

layout(set = 1, binding = 0) uniform SkyData {
    vec3  sun_direction;    // normalised, pointing toward sun
    vec3  moon_direction;
    float time_of_day;      // 0=midnight 0.25=sunrise 0.5=noon 0.75=sunset 1=midnight
    float turbidity;        // 2=clear 10=hazy
    float corruption;       // shifts sky toward grey-purple
    float is_night;
    float cloud_coverage;   // 0=clear 1=overcast
    vec2  resolution;
} sky;

const float PI = 3.14159265359;
const vec3  LAMBDA = vec3(680.0, 550.0, 440.0); // RGB wavelengths nm

// ============================================================
// RAYLEIGH SCATTERING COEFFICIENT
// ============================================================
vec3 RayleighCoeff(vec3 lambda) {
    return pow(400.0 / lambda, vec3(4.0)) * 0.0000059;
}

// ============================================================
// MIE SCATTERING (haze, dust)
// ============================================================
float MiePhase(float cos_theta, float g) {
    float g2 = g * g;
    return (3.0 * (1.0 - g2)) / (2.0 * (2.0 + g2))
         * (1.0 + cos_theta * cos_theta)
         / pow(1.0 + g2 - 2.0 * g * cos_theta, 1.5);
}

// ============================================================
// PREETHAM SKY MODEL — physically-based sky colour
// ============================================================
vec3 PreethamSky(vec3 view_dir, vec3 sun_dir) {
    float cos_theta  = max(dot(view_dir, vec3(0,1,0)), 0.0);
    float cos_gamma  = dot(view_dir, sun_dir);
    float theta      = acos(clamp(cos_theta, 0.0, 1.0));
    float gamma      = acos(clamp(cos_gamma, -1.0, 1.0));

    float sun_theta  = acos(clamp(dot(sun_dir, vec3(0,1,0)), -1.0, 1.0));
    float T          = sky.turbidity;

    // Perez function coefficients
    vec3 A = vec3(-0.0193, -0.0167,  0.1787) * T + vec3(-0.2592, -0.2608, -1.2216);
    vec3 B = vec3(-0.0665, -0.0950, -0.3554) * T + vec3( 0.0008,  0.0092,  0.4275);
    vec3 C = vec3(-0.0004, -0.0079, -0.1564) * T + vec3( 0.2125,  0.2102,  0.5158);
    vec3 D = vec3(-0.0641, -0.0441,  0.2576) * T + vec3(-0.8989, -1.6537, -2.5786);
    vec3 E = vec3(-0.0033, -0.0109, -0.0773) * T + vec3( 0.0452,  0.0529,  0.1876);

    // Perez luminance distribution
    vec3 F = (1.0 + A * exp(B / (cos_theta + 0.01)))
           * (1.0 + C * exp(D * gamma) + E * cos_gamma * cos_gamma);
    vec3 F0 = (1.0 + A * exp(B))
            * (1.0 + C * exp(D * sun_theta) + E);

    return F / F0;
}

// ============================================================
// SUN DISK
// ============================================================
vec3 SunDisk(vec3 view_dir, vec3 sun_dir) {
    float cos_angle = dot(view_dir, sun_dir);
    float sun_size  = 0.9998;  // angular size of sun
    float corona    = 0.9990;  // corona inner edge

    if (cos_angle > sun_size) {
        // White hot core
        float t = smoothstep(sun_size, 1.0, cos_angle);
        return vec3(10.0) * t; // very bright — produces bloom
    }
    if (cos_angle > corona) {
        // Corona glow
        float t = smoothstep(corona, sun_size, cos_angle);
        return vec3(2.0, 1.2, 0.5) * t;
    }
    return vec3(0.0);
}

// ============================================================
// MOON
// ============================================================
vec3 Moon(vec3 view_dir, vec3 moon_dir) {
    if (sky.is_night < 0.5) return vec3(0.0);

    float cos_angle = dot(view_dir, moon_dir);
    float moon_size = 0.9998;
    if (cos_angle < moon_size) return vec3(0.0);

    // Simple moon disc — grey-white
    float t = smoothstep(moon_size, 1.0, cos_angle);

    // Fake crater detail using hash
    vec3  dir_perp = normalize(cross(view_dir, vec3(0,1,0)));
    float crater   = fract(sin(dot(view_dir.xz * 10.0, vec2(127.1, 311.7))) * 43758.5);
    crater         = 1.0 - crater * 0.2;

    return vec3(0.9, 0.92, 0.95) * t * crater * 3.0;
}

// ============================================================
// STAR FIELD
// ============================================================
float Stars(vec3 view_dir) {
    if (sky.is_night < 0.5) return 0.0;

    // Hash-based star placement
    vec3  d   = normalize(view_dir);
    float s   = fract(sin(dot(d * 100.0, vec3(127.1, 311.7, 74.7))) * 43758.5);
    float star = max(0.0, s - 0.995) * 200.0; // sparse bright points
    star      *= clamp(view_dir.y * 3.0, 0.0, 1.0); // fade at horizon
    return star;
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec3  view_dir  = normalize(in_dir);
    vec3  sun_dir   = normalize(sky.sun_direction);

    // Below horizon — ground colour
    if (view_dir.y < -0.02) {
        vec3 ground = mix(vec3(0.15, 0.12, 0.08),  // brown earth
                          vec3(0.05, 0.03, 0.1),    // corrupt = dark purple
                          sky.corruption);
        out_colour  = vec4(ground, 1.0);
        return;
    }

    // ── Day sky ─────────────────────────────────────────────
    vec3 sky_col  = PreethamSky(view_dir, sun_dir);

    // Scale to physical luminance
    sky_col      *= 0.04;

    // ── Horizon gradient ─────────────────────────────────────
    float horizon = 1.0 - clamp(view_dir.y * 3.0, 0.0, 1.0);
    vec3  horizon_col = mix(vec3(0.7, 0.5, 0.3), // sunrise/sunset orange
                            vec3(0.5, 0.7, 1.0),   // noon blue-white
                            abs(sky.time_of_day - 0.5) * 2.0);
    sky_col      = mix(sky_col, horizon_col * 0.5, horizon * 0.4);

    // ── Sun disk ────────────────────────────────────────────
    if (sky.is_night < 0.5) {
        sky_col += SunDisk(view_dir, sun_dir);
    }

    // ── Night sky ───────────────────────────────────────────
    if (sky.is_night > 0.01) {
        // Dark blue-navy night sky
        vec3  night  = vec3(0.02, 0.03, 0.08) * (1.0 - sky.corruption * 0.5);
        sky_col      = mix(sky_col, night, sky.is_night);

        // Stars
        sky_col     += Stars(view_dir) * sky.is_night * 0.5;

        // Moon
        sky_col     += Moon(view_dir, normalize(sky.moon_direction));
    }

    // ── Overcast overlay ────────────────────────────────────
    if (sky.cloud_coverage > 0.3) {
        vec3  overcast = vec3(0.6, 0.65, 0.7); // grey-white cloud blanket
        float coverage = smoothstep(0.3, 0.9, sky.cloud_coverage);
        sky_col        = mix(sky_col, overcast * 0.3, coverage);
    }

    // ── Corruption sky taint ────────────────────────────────
    if (sky.corruption > 0.1) {
        float lum      = dot(sky_col, vec3(0.299, 0.587, 0.114));
        vec3  corrupt  = vec3(lum * 0.4, 0.0, lum * 0.5); // grey-purple
        sky_col        = mix(sky_col, corrupt, sky.corruption * 0.6);
    }

    out_colour = vec4(max(sky_col, vec3(0.0)), 1.0);
}
