// ============================================================
// TERRA ENGINE — ALL AGENTS IMPLEMENTATION
// Agents.cpp — Version 1.0.0
// ============================================================
// Implements all 6 Terra Engine agents:
//   AgentWorld, AgentEnvironment, AgentNPC,
//   AgentBoss, AgentCreature, AgentPlayerCare
// Each agent uses its TransformerPool for AI decisions.
// All AI calls go through AIConnector — no mock data.
// Providers: HuggingFace, OpenRouter, DeepSeek, Groq, Mistral
// ============================================================

#include "Agents.h"
#include "TerraCore.h"
#include <sstream>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <random>

namespace TerraEngine {

// ============================================================
// SHARED UTILITY
// ============================================================
static std::string MakeContext(const WorldState& ws,
                                const std::string& extra = "") {
    std::ostringstream ss;
    ss << "Island:"    << ws.current_island
       << " Time:"     << ws.time_of_day
       << " Weather:"  << ws.weather
       << " Corrupt:"  << ws.corruption_level
       << " PHealth:"  << ws.player_health
       << " PLvl:"     << ws.player_level
       << " Boss:"     << (ws.boss_active ? "yes" : "no")
       << " Combat:"   << (ws.player_in_combat ? "yes" : "no");
    if (!extra.empty()) ss << " " << extra;
    return ss.str();
}

// ============================================================
// ============================================================
// AGENT WORLD
// ============================================================
// ============================================================
AgentWorld::AgentWorld()
    : AgentBase("AgentWorld",
                {"island_generation", "terrain", "biome",
                 "corruption", "resource_distribution", "streaming"})
{
    // T0 — Terrain and island generation
    AddTransformer(std::make_shared<TransformerBase>(
        0, "terrain_generation", "AgentWorld", Model::OR_LLAMA405B));
    // T1 — Biome and resource placement
    AddTransformer(std::make_shared<TransformerBase>(
        1, "biome_resources", "AgentWorld", Model::GQ_LLAMA));
    // T2 — Corruption spread logic
    AddTransformer(std::make_shared<TransformerBase>(
        2, "corruption_management", "AgentWorld", Model::DS_CHAT));
    // T3 — Island streaming decisions
    AddTransformer(std::make_shared<TransformerBase>(
        3, "island_streaming", "AgentWorld", Model::GQ_LLAMA_FAST));
}

void AgentWorld::OnMessage(const AgentMessage& msg) {
    // ISSUE 2 FIX: guard all stoi calls — empty content = crash
    auto safe_stoi = [](const std::string& s, int fallback = 1) -> int {
        if (s.empty()) return fallback;
        try { return std::stoi(s); }
        catch (...) { return fallback; }
    };

    if      (msg.type == Events::ISLAND_ENTER)      StreamIsland(safe_stoi(msg.content));
    else if (msg.type == Events::ISLAND_GENERATE)   GenerateIsland(safe_stoi(msg.content));
    else if (msg.type == Events::CORRUPTION_SPREAD) HandleCorruptionSpread(msg);
    else if (msg.type == Events::BOSS_DEFEATED)     HandleBossDefeated(msg);
    else if (msg.type == Events::PLAYER_DIED)       HandlePlayerDied(msg);
}

void AgentWorld::OnTick(float delta_time) {
    // Slowly spread corruption if level > 0
    if (m_world_state.corruption_level > 0.01f) {
        m_corruption_tick += delta_time;
        if (m_corruption_tick >= 30.0f) {
            m_corruption_tick = 0.0f;
            SpreadCorruption(0.01f, "sector_" + std::to_string(
                m_world_state.current_island));
        }
    }
}

void AgentWorld::OnWorldStateChanged(const WorldState& state) {
    // If player moved to new island — start streaming
    if (state.current_island != m_world_state.current_island) {
        StreamIsland(state.current_island);
    }
}

void AgentWorld::GenerateIsland(int island_id) {
    Remember("generating_island", std::to_string(island_id));

    TransformerResult r = Think(
        MakeContext(m_world_state, "island_id:" + std::to_string(island_id)),
        "Generate island " + std::to_string(island_id) +
        " layout: describe terrain, biome, village placement,"
        " resource zones, and unique features in JSON-like format.",
        0, 2
    );

    if (r.success) {
        Remember("island_" + std::to_string(island_id) + "_layout", r.output);
        Send("AgentNPC", Events::ISLAND_GENERATE,
             "island:" + std::to_string(island_id) + " layout:" + r.output,
             MessagePriority::HIGH);
        Send("AgentCreature", Events::ISLAND_GENERATE,
             "island:" + std::to_string(island_id),
             MessagePriority::NORMAL);
        Log(LogLevel::INFO, "Island " + std::to_string(island_id) + " generated");
    }
}

void AgentWorld::StreamIsland(int island_id) {
    // Unload previous if it was 2+ islands ago
    if (m_last_island_id > 0 && island_id - m_last_island_id >= 2) {
        UnloadIsland(m_last_island_id);
    }
    m_last_island_id = island_id;

    // Generate if not in memory
    std::string key = "island_" + std::to_string(island_id) + "_layout";
    if (!Knows(key)) {
        GenerateIsland(island_id);
    }
    Log(LogLevel::INFO, "Streaming island " + std::to_string(island_id));
}

void AgentWorld::UnloadIsland(int island_id) {
    // Compress island data — keep seed and key facts only
    std::string key = "island_" + std::to_string(island_id) + "_layout";
    std::string layout = Recall(key);
    if (!layout.empty()) {
        Remember("island_" + std::to_string(island_id) + "_compressed", "true");
        Log(LogLevel::INFO, "Island " + std::to_string(island_id) + " unloaded");
    }
}

void AgentWorld::SpreadCorruption(float amount, const std::string& sector) {
    TransformerResult r = Think(
        MakeContext(m_world_state, "sector:" + sector),
        "Corruption spreading by " + std::to_string(amount) +
        " in " + sector + ". What areas are affected and what changes occur?"
        " Respond with: affected_zones, visual_changes, creature_mutations",
        2, 5
    );
    if (r.success) {
        Remember("corruption_" + sector, r.output);
        Send("AgentEnvironment", Events::CORRUPTION_SPREAD,
             sector + ":" + r.output, MessagePriority::HIGH);
        Send("AgentCreature", Events::CORRUPTION_SPREAD,
             sector, MessagePriority::NORMAL);
    }
}

void AgentWorld::PlaceVillage(int island_id, const std::string& biome) {
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "Place a village on island " + std::to_string(island_id) +
        " in " + biome + " biome. Describe: location, size, NPC count,"
        " key buildings, and what makes it unique.",
        1, 5
    );
    if (r.success) {
        Remember("village_island_" + std::to_string(island_id), r.output);
        Send("AgentNPC", "village_placed",
             "island:" + std::to_string(island_id) + " " + r.output,
             MessagePriority::NORMAL);
    }
}

void AgentWorld::HandleCorruptionSpread(const AgentMessage& msg) {
    SpreadCorruption(0.05f, msg.content);
}

void AgentWorld::HandleBossDefeated(const AgentMessage& msg) {
    // Corruption recedes after boss defeated
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "Boss defeated: " + msg.content +
        ". How does the world heal? What changes to terrain and biome occur?",
        2, 5
    );
    if (r.success) {
        Remember("world_healing", r.output);
        Log(LogLevel::INFO, "World healing after boss defeat");
    }
}

void AgentWorld::HandlePlayerDied(const AgentMessage& /*msg*/) {
    // ISSUE 3 FIX: was stoi(Recall()) which crashes if Recall returns ""
    // and called Recall twice — now safe
    std::string s = Recall("player_death_count");
    int count = 0;
    if (!s.empty()) { try { count = std::stoi(s); } catch (...) { count = 0; } }
    Remember("player_death_count", std::to_string(count + 1));
}

// ============================================================
// ============================================================
// AGENT ENVIRONMENT
// Merged: AgentWeather + AgentDay + AgentWater
// ============================================================
// ============================================================
AgentEnvironment::AgentEnvironment()
    : AgentBase("AgentEnvironment",
                {"weather", "day_night_cycle", "water",
                 "temperature", "fog", "environmental_hazards"})
{
    // T0 — Weather decisions
    AddTransformer(std::make_shared<TransformerBase>(
        0, "weather_control", "AgentEnvironment", Model::GQ_GEMMA));
    // T1 — Day/night cycle management
    AddTransformer(std::make_shared<TransformerBase>(
        1, "day_night_cycle", "AgentEnvironment", Model::GQ_LLAMA_FAST));
    // T2 — Water system (rivers, floods, ice)
    AddTransformer(std::make_shared<TransformerBase>(
        2, "water_system", "AgentEnvironment", Model::HF_MISTRAL));
    // T3 — Environmental response to world events
    AddTransformer(std::make_shared<TransformerBase>(
        3, "environment_response", "AgentEnvironment", Model::GQ_LLAMA));
    // T4 — Temperature and biome climate
    AddTransformer(std::make_shared<TransformerBase>(
        4, "climate_biome", "AgentEnvironment", Model::HF_GEMMA));
    // T5 — Corruption atmosphere effects
    AddTransformer(std::make_shared<TransformerBase>(
        5, "corruption_atmosphere", "AgentEnvironment", Model::DS_CHAT));
}

void AgentEnvironment::OnMessage(const AgentMessage& msg) {
    if      (msg.type == Events::STORM_START)       HandleStormStart(msg);
    else if (msg.type == Events::STORM_END)         HandleStormEnd(msg);
    else if (msg.type == Events::CORRUPTION_SPREAD) HandleCorruptionAtmosphere(msg);
    else if (msg.type == Events::BOSS_AWAKENED)     HandleBossAwakened(msg);
    else if (msg.type == Events::BOSS_DEFEATED)     HandleBossDefeated(msg);
    else if (msg.type == Events::FRAGMENT_FOUND)    HandleFragmentFound(msg);
}

void AgentEnvironment::OnTick(float delta_time) {
    // Advance day cycle
    m_day_progress += delta_time / m_day_duration;
    if (m_day_progress >= 1.0f) {
        m_day_progress = 0.0f;
        m_day_count++;
    }

    // Update time of day string and fire events at transitions
    UpdateTimeOfDay();

    // Tick weather
    m_weather_timer += delta_time;
    if (m_weather_timer >= m_weather_change_interval) {
        m_weather_timer = 0.0f;
        ConsiderWeatherChange();
    }

    // Water level responds to rain
    if (m_world_state.weather == "rain" || m_world_state.weather == "storm") {
        m_water_level = std::min(1.0f, m_water_level + delta_time * 0.002f);
        if (m_water_level > 0.8f && !m_flood_warned) {
            m_flood_warned = true;
            TERRA.FireEvent(Events::FLOOD_WARNING,
                            "level:" + std::to_string(m_water_level),
                            MessagePriority::HIGH);
        }
    } else {
        m_water_level = std::max(0.0f, m_water_level - delta_time * 0.001f);
        m_flood_warned = false;
    }
}

void AgentEnvironment::UpdateTimeOfDay() {
    std::string new_time;
    if      (m_day_progress < 0.25f) new_time = "morning";
    else if (m_day_progress < 0.5f)  new_time = "noon";
    else if (m_day_progress < 0.75f) new_time = "evening";
    else                              new_time = "night";

    if (new_time != m_current_time) {
        m_current_time = new_time;
        TERRA.SetTimeOfDay(new_time);
    }
}

void AgentEnvironment::ConsiderWeatherChange() {
    TransformerResult r = Think(
        MakeContext(m_world_state,
            "current_weather:" + m_current_weather
            + " day:" + std::to_string(m_day_count)
            + " corruption:" + std::to_string(m_world_state.corruption_level)),
        "Current weather is " + m_current_weather +
        ". Should weather change? Consider: biome, corruption level,"
        " story progression, time of day. Respond with:"
        " new_weather (sunny/rain/storm/fog/snow/clear), reason, duration_seconds",
        0, 7
    );
    if (r.success) {
        Remember("weather_decision", r.output);
        // Parse new weather from response
        if (r.output.find("storm") != std::string::npos && m_current_weather != "storm") {
            m_current_weather = "storm";
            TERRA.SetWeather("storm");
        } else if (r.output.find("rain") != std::string::npos && m_current_weather != "rain") {
            m_current_weather = "rain";
            TERRA.SetWeather("rain");
        } else if (r.output.find("clear") != std::string::npos || r.output.find("sunny") != std::string::npos) {
            m_current_weather = "clear";
            TERRA.SetWeather("clear");
        } else if (r.output.find("snow") != std::string::npos) {
            m_current_weather = "snow";
            TERRA.SetWeather("snow");
        } else if (r.output.find("fog") != std::string::npos) {
            m_current_weather = "fog";
            TERRA.SetWeather("fog");
        }
    }
}

void AgentEnvironment::HandleStormStart(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "Storm starting. What environmental effects occur?"
        " Affect: water levels, visibility, creature behavior hints,"
        " any flooding zones. Respond concisely.",
        3, 3
    );
    if (r.success) Remember("storm_effects", r.output);
    m_weather_change_interval = 120.0f; // storms last longer
}

void AgentEnvironment::HandleStormEnd(const AgentMessage& msg) {
    m_weather_change_interval = 300.0f;
    Remember("storm_ended", "true");
}

void AgentEnvironment::HandleCorruptionAtmosphere(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Corruption spreading in " + msg.content +
        ". What atmospheric changes occur? Sky color, fog color,"
        " temperature drop, unnatural weather near corruption zone.",
        5, 4
    );
    if (r.success) Remember("corruption_atmosphere", r.output);
}

void AgentEnvironment::HandleBossAwakened(const AgentMessage& msg) {
    // Boss awakens — dramatic sky change
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "A powerful boss has awakened. Create dramatic environmental response:"
        " sky darkening, lightning, weather shift, temperature change."
        " Be specific and cinematic.",
        3, 1
    );
    if (r.success) {
        Remember("boss_atmosphere", r.output);
        m_current_weather = "storm";
        m_weather_change_interval = 600.0f; // boss storm persists
    }
}

void AgentEnvironment::HandleBossDefeated(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "Boss defeated. Describe the environmental return to calm:"
        " clouds parting, light returning, water settling.",
        3, 3
    );
    if (r.success) Remember("boss_defeated_atmosphere", r.output);
    m_current_weather     = "clear";
    m_weather_change_interval = 300.0f;
    TERRA.SetWeather("clear");
}

void AgentEnvironment::HandleFragmentFound(const AgentMessage& msg) {
    // Fragment found — brief sky anomaly
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "A god fragment was found. Describe a brief atmospheric anomaly:"
        " sky pulse, color shift, brief stillness then return to normal.",
        0, 4
    );
    if (r.success) Remember("fragment_sky_event", r.output);
}

float AgentEnvironment::GetDayProgress() const { return m_day_progress; }
std::string AgentEnvironment::GetCurrentWeather() const { return m_current_weather; }
float AgentEnvironment::GetWaterLevel() const { return m_water_level; }
int AgentEnvironment::GetDayCount() const { return m_day_count; }

// ============================================================
// ============================================================
// AGENT NPC
// ============================================================
// ============================================================
AgentNPC::AgentNPC()
    : AgentBase("AgentNPC",
                {"npc_behavior", "village_economy", "dialogue",
                 "npc_needs", "reputation", "job_system"})
{
    // T0 — NPC personality and dialogue (best language model)
    AddTransformer(std::make_shared<TransformerBase>(
        0, "npc_dialogue", "AgentNPC", Model::OR_GPT4O));
    // T1 — NPC needs, mood, job decisions
    AddTransformer(std::make_shared<TransformerBase>(
        1, "npc_needs_mood", "AgentNPC", Model::GQ_LLAMA));
    // T2 — Village economy and trade
    AddTransformer(std::make_shared<TransformerBase>(
        2, "village_economy", "AgentNPC", Model::DS_CHAT));
    // T3 — NPC social interactions and relationships
    AddTransformer(std::make_shared<TransformerBase>(
        3, "npc_social", "AgentNPC", Model::GQ_LLAMA));
}

void AgentNPC::OnMessage(const AgentMessage& msg) {
    if      (msg.type == Events::VILLAGE_ATTACK)   HandleVillageAttack(msg);
    else if (msg.type == Events::NPC_HUNGRY)        HandleNPCHungry(msg);
    else if (msg.type == Events::NIGHT_FALL)        HandleNightFall(msg);
    else if (msg.type == Events::STORM_START)       HandleStormStart(msg);
    else if (msg.type == Events::BOSS_DEFEATED)     HandleBossDefeated(msg);
    else if (msg.type == Events::FRAGMENT_FOUND)    HandleFragmentFound(msg);
    else if (msg.type == "village_placed")          HandleVillagePlaced(msg);
    else if (msg.type == Events::ISLAND_GENERATE)   HandleIslandGenerate(msg);
}

void AgentNPC::OnTick(float delta_time) {
    // Simulate NPC needs every 10 seconds
    m_needs_tick += delta_time;
    if (m_needs_tick >= 10.0f) {
        m_needs_tick = 0.0f;
        SimulateNPCNeeds(delta_time);
    }

    // Economy update every 60 seconds
    m_economy_tick += delta_time;
    if (m_economy_tick >= 60.0f) {
        m_economy_tick = 0.0f;
        UpdateEconomy();
    }
}

void AgentNPC::SpawnNPC(const NPCData& npc) {
    m_npcs[npc.id] = npc;
    Remember("npc_" + npc.id, npc.name + "|" + npc.job + "|" + npc.personality);
    Log(LogLevel::DEBUG, "NPC spawned: " + npc.name + " (" + npc.job + ")");
}

std::string AgentNPC::GetDialogue(const std::string& npc_id,
                                    const std::string& player_action)
{
    auto it = m_npcs.find(npc_id);
    if (it == m_npcs.end()) return "...";

    const NPCData& npc = it->second;
    std::string mood_str = std::to_string(static_cast<int>(npc.mood * 100)) + "%";
    std::string memory   = Recall("npc_" + npc_id + "_history");

    TransformerResult r = Think(
        MakeContext(m_world_state,
            "npc_name:" + npc.name
            + " job:" + npc.job
            + " personality:" + npc.personality
            + " mood:" + mood_str
            + " history:" + memory),
        "Player action: " + player_action +
        ". Generate authentic dialogue for " + npc.name +
        " who is a " + npc.job + " with " + npc.personality +
        " personality. Keep it 1-3 sentences. Sound like a real person.",
        0, 3
    );

    std::string dialogue = r.success ? r.output : "I don't have time right now.";

    // Update NPC history
    std::string hist = Recall("npc_" + npc_id + "_history");
    hist += "|" + player_action + ":" + dialogue.substr(0, 30);
    Remember("npc_" + npc_id + "_history", hist);

    return dialogue;
}

float AgentNPC::GetItemPrice(const std::string& item_id) const {
    auto it = m_item_prices.find(item_id);
    return (it != m_item_prices.end()) ? it->second : 10.0f;
}

void AgentNPC::SetReputation(int island_id, float value) {
    m_reputation[island_id] = std::max(-1.0f, std::min(1.0f, value));
}

float AgentNPC::GetReputation(int island_id) const {
    auto it = m_reputation.find(island_id);
    return (it != m_reputation.end()) ? it->second : 0.0f;
}

int AgentNPC::GetNPCCount(int island_id) const {
    int count = 0;
    for (const auto& [id, npc] : m_npcs) {
        if (npc.island_id == island_id && npc.is_alive) count++;
    }
    return count;
}

void AgentNPC::SimulateNPCNeeds(float /*delta*/) {
    if (m_npcs.empty()) return;

    // Pick a random NPC to simulate
    auto it = m_npcs.begin();
    std::advance(it, rand() % m_npcs.size());
    NPCData& npc = it->second;

    // Reduce hunger and thirst
    npc.hunger = std::max(0.0f, npc.hunger - 0.05f);
    npc.thirst = std::max(0.0f, npc.thirst - 0.07f);

    // Fire hungry event if starving
    if (npc.hunger < 0.1f) {
        TERRA.FireEvent(Events::NPC_HUNGRY,
                        npc.id + ":" + npc.name,
                        MessagePriority::NORMAL);
    }

    // Mood drops when needs unmet
    if (npc.hunger < 0.3f || npc.thirst < 0.3f) {
        npc.mood = std::max(0.0f, npc.mood - 0.1f);
    }
}

void AgentNPC::UpdateEconomy() {
    if (m_npcs.empty()) return;

    TransformerResult r = Think(
        MakeContext(m_world_state,
            "npc_count:" + std::to_string(m_npcs.size())
            + " island:" + std::to_string(m_world_state.current_island)),
        "Current economy state for island " +
        std::to_string(m_world_state.current_island) +
        ". Adjust 3 item prices based on current world state."
        " Consider: weather, corruption, boss activity, time of day."
        " Format: item_name:new_price, item_name:new_price",
        2, 8
    );
    if (r.success) Remember("economy_state", r.output);
}

void AgentNPC::HandleVillageAttack(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Village is under attack: " + msg.content +
        ". How do NPCs respond? Who flees, who fights, who hides?"
        " What happens to the village economy and reputation?",
        0, 1
    );
    if (r.success) {
        Remember("village_attack_response", r.output);
        // Mark some NPCs as fleeing
        for (auto& [id, npc] : m_npcs) {
            if (npc.island_id == m_world_state.current_island) {
                npc.mood = std::max(0.0f, npc.mood - 0.4f);
            }
        }
    }
}

void AgentNPC::HandleNPCHungry(const AgentMessage& msg) {
    // NPC seeks food
    std::string npc_info = msg.content;
    TransformerResult r = Think(
        MakeContext(m_world_state, npc_info),
        "NPC " + npc_info + " is hungry. What do they do to find food?"
        " Consider: available resources on island, job, personality.",
        1, 5
    );
    if (r.success) Remember("npc_hunger_action_" + npc_info, r.output);
}

void AgentNPC::HandleNightFall(const AgentMessage& /*msg*/) {
    // NPCs go indoors at night
    for (auto& [id, npc] : m_npcs) {
        Remember("npc_" + id + "_location", "indoor");
    }
}

void AgentNPC::HandleStormStart(const AgentMessage& /*msg*/) {
    // NPCs seek shelter
    for (auto& [id, npc] : m_npcs) {
        npc.mood = std::max(0.0f, npc.mood - 0.1f);
        Remember("npc_" + id + "_location", "shelter");
    }
}

void AgentNPC::HandleBossDefeated(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Boss defeated: " + msg.content +
        ". How do NPCs react and celebrate? What changes in their morale,"
        " economy, and what stories do they start telling?",
        0, 5
    );
    if (r.success) {
        Remember("boss_defeat_reaction", r.output);
        // Boost all NPC moods on this island
        for (auto& [id, npc] : m_npcs) {
            if (npc.island_id == m_world_state.current_island) {
                npc.mood = std::min(1.0f, npc.mood + 0.3f);
            }
        }
        SetReputation(m_world_state.current_island,
                      GetReputation(m_world_state.current_island) + 0.2f);
    }
}

void AgentNPC::HandleFragmentFound(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "A god fragment was found. NPCs sense something powerful happened."
        " How do they react? What rumors start spreading?",
        3, 6
    );
    if (r.success) Remember("fragment_rumor", r.output);
}

void AgentNPC::HandleVillagePlaced(const AgentMessage& msg) {
    // Generate NPCs for new village
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "New village placed: " + msg.content +
        ". Generate 5 unique NPCs for this village. For each NPC specify:"
        " name, job (trader/blacksmith/farmer/guard/healer),"
        " personality (one word), and backstory (one sentence)."
        " Format: name|job|personality|backstory",
        0, 4
    );
    if (r.success) {
        Remember("village_npcs_island_" +
                 std::to_string(m_world_state.current_island), r.output);
        // Parse and spawn NPCs
        std::istringstream ss(r.output);
        std::string line;
        int idx = 0;
        while (std::getline(ss, line, '\n') && idx < 5) {
            if (line.empty()) continue;
            NPCData npc;
            npc.id        = "npc_island" +
                            std::to_string(m_world_state.current_island) +
                            "_" + std::to_string(idx++);
            npc.island_id = m_world_state.current_island;

            // Try to parse name|job|personality|backstory
            std::istringstream parts(line);
            std::string part;
            int p = 0;
            while (std::getline(parts, part, '|') && p < 4) {
                if      (p == 0) npc.name        = part;
                else if (p == 1) npc.job         = part;
                else if (p == 2) npc.personality = part;
                else if (p == 3) npc.backstory   = part;
                p++;
            }
            if (!npc.name.empty()) SpawnNPC(npc);
        }
    }
}

void AgentNPC::HandleIslandGenerate(const AgentMessage& msg) {
    // Extract island_id from msg
    size_t pos = msg.content.find("island:");
    if (pos != std::string::npos) {
        try {
            int id = std::stoi(msg.content.substr(pos + 7));
            PlaceVillage(id);
        } catch (...) {}
    }
}

void AgentNPC::PlaceVillage(int island_id) {
    // Notify world agent to place a village
    Send("AgentWorld", "village_request",
         "island:" + std::to_string(island_id),
         MessagePriority::NORMAL);
}

// ============================================================
// ============================================================
// AGENT BOSS
// ============================================================
// ============================================================
AgentBoss::AgentBoss()
    : AgentBase("AgentBoss",
                {"boss_ai", "combat_phases", "player_analysis",
                 "boss_taunts", "adaptive_strategy"})
{
    // T0 — Combat strategy (DeepSeek Reasoner — best logic)
    AddTransformer(std::make_shared<TransformerBase>(
        0, "combat_strategy", "AgentBoss", Model::DS_REASONER));
    // T1 — Player pattern analysis
    AddTransformer(std::make_shared<TransformerBase>(
        1, "player_pattern", "AgentBoss", Model::OR_GPT4O));
    // T2 — Phase transition logic
    AddTransformer(std::make_shared<TransformerBase>(
        2, "phase_control", "AgentBoss", Model::DS_CHAT));
    // T3 — Boss personality, taunts, emotional state
    AddTransformer(std::make_shared<TransformerBase>(
        3, "boss_personality", "AgentBoss", Model::OR_CLAUDE));
}

void AgentBoss::OnMessage(const AgentMessage& msg) {
    if      (msg.type == Events::BOSS_AWAKENED)     HandleBossAwakened(msg);
    else if (msg.type == Events::COMBAT_START)      HandleCombatStart(msg);
    else if (msg.type == Events::COMBAT_END)        HandleCombatEnd(msg);
    else if (msg.type == Events::FRAGMENT_ABSORBED) HandleFragmentAbsorbed(msg);
    else if (msg.type == Events::STORM_START)       HandleStormStart(msg);
    else if (msg.type == Events::NIGHT_FALL)        HandleNightFall(msg);
}

void AgentBoss::OnTick(float delta_time) {
    if (!m_boss_active) return;

    // Check phase transition
    if (CheckPhaseTransition()) {
        m_current_phase++;
        TransformerResult r = Think(
            MakeContext(m_world_state,
                "boss:" + m_active_boss_name
                + " phase:" + std::to_string(m_current_phase)
                + " hp:" + std::to_string(GetBossHPPercent())),
            "Boss entering phase " + std::to_string(m_current_phase) +
            ". What new abilities, tactics, and visual changes occur?"
            " What does the boss say/scream?",
            2, 1
        );
        if (r.success) {
            Remember("phase_" + std::to_string(m_current_phase), r.output);
            TERRA.FireEvent(Events::BOSS_PHASE_CHANGE,
                            std::to_string(m_current_phase),
                            MessagePriority::CRITICAL);
        }
    }
}

void AgentBoss::ActivateBoss(const std::string& boss_id,
                               const std::string& boss_name,
                               int island_id)
{
    m_boss_active       = true;
    m_active_boss_id    = boss_id;
    m_active_boss_name  = boss_name;
    m_island_id         = island_id;
    m_current_phase     = 1;
    m_boss_hp           = 1000.0f;
    m_boss_max_hp       = 1000.0f;
    m_player_actions.clear();

    // Set up default 3-phase fight
    if (m_phases.empty()) {
        m_phases = {
            {1, 1.0f,  "aggressive",   1.0f, true},
            {2, 0.6f,  "tactical",     1.5f, false},
            {3, 0.25f, "desperate",    2.0f, false}
        };
    }

    TransformerResult r = Think(
        MakeContext(m_world_state,
            "boss:" + boss_name + " island:" + std::to_string(island_id)),
        boss_name + " awakens on island " + std::to_string(island_id) +
        ". Describe the boss opening cinematic: roar, entrance,"
        " first phase behavior, and opening taunt.",
        3, 1
    );
    if (r.success) Remember("boss_intro", r.output);

    Log(LogLevel::INFO, "Boss activated: " + boss_name);
}

void AgentBoss::DeactivateBoss() {
    m_boss_active = false;
    m_phases.clear();
    Log(LogLevel::INFO, "Boss deactivated: " + m_active_boss_name);
    TERRA.FireEvent(Events::BOSS_DEFEATED, m_active_boss_name,
                    MessagePriority::HIGH);
}

void AgentBoss::SetBossHP(float hp, float max_hp) {
    m_boss_hp     = hp;
    m_boss_max_hp = max_hp;
    if (hp <= 0.0f && m_boss_active) DeactivateBoss();
}

std::string AgentBoss::GetNextAttack() {
    if (!m_boss_active) return "none";

    // Build player action summary
    std::string actions;
    for (const auto& [action, count] : m_player_actions) {
        actions += action + "x" + std::to_string(count) + " ";
    }

    TransformerResult r = Think(
        MakeContext(m_world_state,
            "boss:" + m_active_boss_name
            + " phase:" + std::to_string(m_current_phase)
            + " boss_hp:" + std::to_string(GetBossHPPercent())
            + " player_actions:" + actions),
        "Player has used these moves: " + actions +
        ". What is the most effective next attack for " + m_active_boss_name +
        " in phase " + std::to_string(m_current_phase) + "?"
        " Respond with: attack_name, reasoning (one line)",
        0, 1
    );
    return r.success ? r.output : "heavy_slam";
}

std::string AgentBoss::GetBossTaunt() {
    if (!m_boss_active) return "";

    TransformerResult r = Think(
        MakeContext(m_world_state,
            "boss:" + m_active_boss_name
            + " phase:" + std::to_string(m_current_phase)
            + " hp:" + std::to_string(GetBossHPPercent())),
        m_active_boss_name + " taunts the player in phase " +
        std::to_string(m_current_phase) + " at " +
        std::to_string(static_cast<int>(GetBossHPPercent())) + "% HP."
        " Make it feel powerful, threatening, personal."
        " One to two sentences. In character.",
        3, 4
    );
    return r.success ? r.output : "You cannot stop what has already begun.";
}

bool AgentBoss::ShouldChangePhase() const {
    return CheckPhaseTransition();
}

bool AgentBoss::CheckPhaseTransition() const {
    float hp_pct = GetBossHPPercent();
    for (const auto& phase : m_phases) {
        if (!phase.is_active && hp_pct <= phase.hp_threshold) {
            return true;
        }
    }
    return false;
}

void AgentBoss::OnPlayerAction(const std::string& action) {
    m_player_actions[action]++;
}

void AgentBoss::AddPhase(const BossPhase& phase) {
    m_phases.push_back(phase);
}

float AgentBoss::GetBossHPPercent() const {
    if (m_boss_max_hp <= 0.0f) return 0.0f;
    return (m_boss_hp / m_boss_max_hp) * 100.0f;
}

void AgentBoss::HandleBossAwakened(const AgentMessage& msg) {
    if (!m_boss_active) {
        ActivateBoss(msg.content, msg.content,
                     m_world_state.current_island);
    }
}

void AgentBoss::HandleCombatStart(const AgentMessage& /*msg*/) {
    if (!m_boss_active) return;
    // Boss enters heightened state during player combat
    TransformerResult r = Think(
        MakeContext(m_world_state, "boss:" + m_active_boss_name),
        "Player entered combat while " + m_active_boss_name +
        " is active. How does the boss react and what advantage does it take?",
        0, 3
    );
    if (r.success) Remember("combat_advantage", r.output);
}

void AgentBoss::HandleCombatEnd(const AgentMessage& /*msg*/) {
    if (!m_boss_active) return;
    Remember("combat_ended", "true");
}

void AgentBoss::HandleFragmentAbsorbed(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "A Varek fragment was absorbed. " + m_active_boss_name +
        " grows stronger. Describe power increase and new ability unlocked.",
        0, 1
    );
    if (r.success) {
        Remember("fragment_power_boost", r.output);
        m_boss_hp = std::min(m_boss_max_hp, m_boss_hp + 200.0f); // boss heals
    }
}

void AgentBoss::HandleStormStart(const AgentMessage& /*msg*/) {
    // Storm makes boss stronger
    if (m_boss_active) {
        Remember("storm_boost", "active");
        Log(LogLevel::INFO, m_active_boss_name + " empowered by storm");
    }
}

void AgentBoss::HandleNightFall(const AgentMessage& /*msg*/) {
    // Night makes boss stronger
    if (m_boss_active) {
        Remember("night_boost", "active");
    }
}

// ============================================================
// ============================================================
// AGENT CREATURE
// Merged: AgentEnemy + AgentAnimal
// ============================================================
// ============================================================
AgentCreature::AgentCreature()
    : AgentBase("AgentCreature",
                {"enemy_ai", "animal_behavior", "creature_spawning",
                 "pack_coordination", "territory", "creature_learning"})
{
    // T0 — Hostile combat decisions
    AddTransformer(std::make_shared<TransformerBase>(
        0, "hostile_combat", "AgentCreature", Model::DS_REASONER));
    // T1 — Peaceful animal behavior
    AddTransformer(std::make_shared<TransformerBase>(
        1, "peaceful_behavior", "AgentCreature", Model::GQ_LLAMA_FAST));
    // T2 — Pack coordination and territory
    AddTransformer(std::make_shared<TransformerBase>(
        2, "pack_territory", "AgentCreature", Model::GQ_LLAMA));
    // T3 — Creature world event response
    AddTransformer(std::make_shared<TransformerBase>(
        3, "event_response", "AgentCreature", Model::HF_MISTRAL));
    // T4 — Learning from player combat
    AddTransformer(std::make_shared<TransformerBase>(
        4, "combat_learning", "AgentCreature", Model::DS_CHAT));
    // T5 — Ecosystem balance
    AddTransformer(std::make_shared<TransformerBase>(
        5, "ecosystem", "AgentCreature", Model::GQ_GEMMA));
}

void AgentCreature::OnMessage(const AgentMessage& msg) {
    if      (msg.type == Events::NIGHT_FALL)        HandleNightFall(msg);
    else if (msg.type == Events::STORM_START)       HandleStormStart(msg);
    else if (msg.type == Events::BOSS_AWAKENED)     HandleBossAwakened(msg);
    else if (msg.type == Events::COMBAT_START)      HandleCombatStart(msg);
    else if (msg.type == Events::VILLAGE_ATTACK)    HandleVillageAttack(msg);
    else if (msg.type == Events::ISLAND_GENERATE)   HandleIslandEnter(msg);
    else if (msg.type == Events::CORRUPTION_SPREAD) HandleCorruptionSpread(msg);
}

void AgentCreature::OnTick(float delta_time) {
    m_behavior_tick += delta_time;
    if (m_behavior_tick >= 5.0f) {
        m_behavior_tick = 0.0f;
        UpdateCreatureMoods(delta_time);
    }
}

void AgentCreature::SpawnCreature(const CreatureData& creature) {
    m_creatures[creature.id] = creature;
    if (creature.in_pack && !creature.pack_id.empty()) {
        m_packs[creature.pack_id].push_back(creature.id);
    }
    Remember("creature_" + creature.id,
             creature.type + "|" + creature.behavior_mode);
}

void AgentCreature::RemoveCreature(const std::string& id) {
    auto it = m_creatures.find(id);
    if (it == m_creatures.end()) return;
    const CreatureData& c = it->second;
    if (c.in_pack && !c.pack_id.empty()) {
        auto& pack = m_packs[c.pack_id];
        pack.erase(std::remove(pack.begin(), pack.end(), id), pack.end());
    }
    m_creatures.erase(it);
}

void AgentCreature::SetAggressive(const std::string& id) {
    auto it = m_creatures.find(id);
    if (it != m_creatures.end()) it->second.behavior_mode = "hostile";
}

void AgentCreature::SetPeaceful(const std::string& id) {
    auto it = m_creatures.find(id);
    if (it != m_creatures.end()) it->second.behavior_mode = "peaceful";
}

void AgentCreature::SetFleeing(const std::string& id) {
    auto it = m_creatures.find(id);
    if (it != m_creatures.end()) it->second.behavior_mode = "fleeing";
}

std::vector<std::string> AgentCreature::GetNearbyHostiles(int island_id) const {
    std::vector<std::string> result;
    for (const auto& [id, c] : m_creatures) {
        if (c.island_id == island_id &&
            c.behavior_mode == "hostile" &&
            c.is_alive) {
            result.push_back(id);
        }
    }
    return result;
}

std::vector<std::string> AgentCreature::GetPackMembers(const std::string& pack_id) const {
    auto it = m_packs.find(pack_id);
    if (it == m_packs.end()) return {};
    return it->second;
}

std::string AgentCreature::GetAttackStrategy(const std::string& creature_id) {
    auto it = m_creatures.find(creature_id);
    if (it == m_creatures.end()) return "basic_attack";

    const CreatureData& c = it->second;
    std::string history = Recall("creature_combat_" + creature_id);

    TransformerResult r = Think(
        MakeContext(m_world_state,
            "creature:" + c.type
            + " mode:" + c.behavior_mode
            + " hp:" + std::to_string(c.hp)
            + " history:" + history),
        "What attack strategy should this " + c.type + " use now?"
        " Consider: player history, pack status, health, time of day."
        " Respond with: strategy_name, brief_reasoning",
        0, 2
    );
    return r.success ? r.output : "basic_attack";
}

bool AgentCreature::IsInTerritory(const std::string& id,
                                    const std::string& zone) const {
    auto it = m_creatures.find(id);
    if (it == m_creatures.end()) return false;
    return it->second.territory == zone;
}

int AgentCreature::GetCreatureCount(int island_id,
                                      const std::string& type) const {
    int count = 0;
    for (const auto& [id, c] : m_creatures) {
        if (c.island_id == island_id && c.is_alive) {
            if (type.empty() || c.type == type) count++;
        }
    }
    return count;
}

void AgentCreature::FleeFromEvent(const std::string& sector,
                                    const std::string& reason) {
    TransformerResult r = Think(
        MakeContext(m_world_state, "sector:" + sector + " reason:" + reason),
        "Creatures in " + sector + " are fleeing due to: " + reason +
        ". Which creature types flee, which stay? Where do they go?",
        3, 4
    );
    if (r.success) {
        // Set nearby peaceful creatures to fleeing
        for (auto& [id, c] : m_creatures) {
            if (c.island_id == m_world_state.current_island &&
                c.behavior_mode == "peaceful") {
                c.behavior_mode = "fleeing";
            }
        }
        Remember("flee_event_" + sector, r.output);
    }
}

void AgentCreature::HandleNightFall(const AgentMessage& /*msg*/) {
    // Nocturnal creatures become active, others rest
    TransformerResult r = Think(
        MakeContext(m_world_state),
        "Night falls. Which creature types become more active/aggressive?"
        " Which retreat? How does night affect creature spawning?",
        3, 5
    );
    if (r.success) Remember("night_creature_behavior", r.output);

    for (auto& [id, c] : m_creatures) {
        if (c.island_id == m_world_state.current_island &&
            c.behavior_mode == "peaceful") {
            // Some creatures get slightly more aggressive at night
            if (rand() % 3 == 0) c.behavior_mode = "hostile";
        }
    }
}

void AgentCreature::HandleStormStart(const AgentMessage& /*msg*/) {
    FleeFromEvent("all_sectors", "storm");
}

void AgentCreature::HandleBossAwakened(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Boss awakened: " + msg.content +
        ". How do nearby creatures react? Do some serve the boss?"
        " Do some flee? Are new creatures summoned?",
        3, 1
    );
    if (r.success) Remember("boss_creature_reaction", r.output);

    // Make creatures on this island more aggressive
    for (auto& [id, c] : m_creatures) {
        if (c.island_id == m_world_state.current_island) {
            c.behavior_mode = "hostile";
        }
    }
}

void AgentCreature::HandleCombatStart(const AgentMessage& /*msg*/) {
    // Alert nearby creatures to player position
    for (auto& [id, c] : m_creatures) {
        if (c.island_id == m_world_state.current_island &&
            c.behavior_mode != "fleeing") {
            c.behavior_mode = "hostile";
        }
    }
}

void AgentCreature::HandleVillageAttack(const AgentMessage& msg) {
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Creatures are attacking a village: " + msg.content +
        ". Which pack leads the attack? What is their formation and strategy?",
        2, 1
    );
    if (r.success) Remember("village_attack_strategy", r.output);
}

void AgentCreature::HandleIslandEnter(const AgentMessage& msg) {
    // Spawn creatures for new island
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Player entering: " + msg.content +
        ". Generate creature population for this island."
        " Specify: 3 hostile types with counts, 2 peaceful types with counts,"
        " 1 rare creature. Format: type|count|hostile(yes/no)|behavior",
        5, 4
    );
    if (r.success) {
        Remember("island_creatures_" +
                 std::to_string(m_world_state.current_island), r.output);
    }
}

void AgentCreature::HandleCorruptionSpread(const AgentMessage& msg) {
    // Corruption mutates creatures in affected zones
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Corruption spreading in " + msg.content +
        ". Which creatures are mutated? How do they change?",
        3, 5
    );
    if (r.success) {
        Remember("corruption_mutations", r.output);
        // Make creatures in corrupt zone more aggressive
        for (auto& [id, c] : m_creatures) {
            if (c.territory == msg.content) {
                c.behavior_mode = "hostile";
                c.hp *= 1.2f; // corruption buffs HP
            }
        }
    }
}

void AgentCreature::UpdateCreatureMoods(float /*delta*/) {
    if (m_creatures.empty()) return;

    // Pick a few random creatures to simulate
    int simulated = 0;
    for (auto& [id, c] : m_creatures) {
        if (!c.is_alive) continue;
        if (simulated++ > 5) break;

        // Hunger-like aggression increase
        if (c.behavior_mode == "peaceful" &&
            m_world_state.time_of_day == "night") {
            // Small chance to go hostile at night
            if (rand() % 100 < 5) c.behavior_mode = "hostile";
        }
    }
}

// ============================================================
// ============================================================
// AGENT PLAYER CARE
// ============================================================
// ============================================================
AgentPlayerCare::AgentPlayerCare()
    : AgentBase("AgentPlayerCare",
                {"player_monitoring", "boredom_detection",
                 "overwhelm_detection", "difficulty_adjustment",
                 "story_guidance"})
{
    // T0 — Boredom detection and event injection
    AddTransformer(std::make_shared<TransformerBase>(
        0, "boredom_detection", "AgentPlayerCare", Model::OR_GPT4O));
    // T1 — Overwhelm detection and difficulty tuning
    AddTransformer(std::make_shared<TransformerBase>(
        1, "overwhelm_detection", "AgentPlayerCare", Model::GQ_LLAMA));
    // T2 — Story drift detection
    AddTransformer(std::make_shared<TransformerBase>(
        2, "story_drift", "AgentPlayerCare", Model::DS_CHAT));
    // T3 — Overall emotional state analysis
    AddTransformer(std::make_shared<TransformerBase>(
        3, "player_emotion", "AgentPlayerCare", Model::OR_CLAUDE));
}

void AgentPlayerCare::OnMessage(const AgentMessage& msg) {
    if      (msg.type == Events::PLAYER_LOW_HEALTH) HandlePlayerLowHealth(msg);
    else if (msg.type == Events::PLAYER_DIED)       HandlePlayerDied(msg);
    else if (msg.type == Events::COMBAT_START)      HandleCombatStart(msg);
    else if (msg.type == Events::COMBAT_END)        HandleCombatEnd(msg);
    else if (msg.type == Events::FRAGMENT_FOUND)    HandleFragmentFound(msg);
}

void AgentPlayerCare::OnTick(float delta_time) {
    UpdateScores(delta_time);

    // Check boredom — inject event if too bored
    if (IsPlayerBored()) {
        TERRA.FireEvent(Events::PLAYER_BORED, "", MessagePriority::LOW);
        InjectInterestingEvent();
        m_boredom_score = 0.0f;
        m_time_since_action = 0.0f;
    }

    // Check overwhelm — reduce difficulty if overwhelmed
    if (IsPlayerOverwhelmed()) {
        TERRA.FireEvent(Events::PLAYER_OVERWHELMED, "", MessagePriority::NORMAL);
        ReduceDifficulty();
        m_overwhelm_score = 0.0f;
    }

    // Check story drift — nudge back to story
    if (IsPlayerDriftingFromStory()) {
        NudgeTowardStory();
        m_time_since_quest = 0.0f;
    }
}

void AgentPlayerCare::RecordPlayerAction(const std::string& action) {
    m_time_since_action = 0.0f;
    m_recent_kills += (action == "kill") ? 1 : 0;
    Remember("last_action", action);
}

void AgentPlayerCare::RecordDeath() {
    m_recent_deaths++;
    m_overwhelm_score = std::min(1.0f, m_overwhelm_score + 0.3f);
}

void AgentPlayerCare::RecordQuestIgnored(float seconds) {
    m_time_since_quest += seconds;
}

bool AgentPlayerCare::IsPlayerBored() const {
    return m_boredom_score >= BOREDOM_THRESHOLD;
}

bool AgentPlayerCare::IsPlayerOverwhelmed() const {
    return m_overwhelm_score >= OVERWHELM_THRESHOLD;
}

bool AgentPlayerCare::IsPlayerDriftingFromStory() const {
    return m_time_since_quest >= STORY_DRIFT_SECONDS;
}

void AgentPlayerCare::UpdateScores(float delta_time) {
    m_time_since_action += delta_time;
    m_time_since_quest  += delta_time;

    // Boredom increases with inaction
    float boredom_rate = 0.001f * delta_time;
    m_boredom_score = std::min(1.0f, m_boredom_score + boredom_rate);

    // Overwhelm decays over time
    m_overwhelm_score = std::max(0.0f, m_overwhelm_score - 0.0005f * delta_time);

    // Engagement score
    float action_factor = 1.0f / (1.0f + m_time_since_action / 60.0f);
    m_engagement_score  = action_factor * (1.0f - m_overwhelm_score);
}

void AgentPlayerCare::InjectInterestingEvent() {
    TransformerResult r = Think(
        MakeContext(m_world_state,
            "boredom:" + std::to_string(m_boredom_score)
            + " engagement:" + std::to_string(m_engagement_score)
            + " time_idle:" + std::to_string(m_time_since_action)),
        "Player has been idle for " + std::to_string(
            static_cast<int>(m_time_since_action)) +
        " seconds. What interesting event should the world generate?"
        " Options: wandering merchant, distant explosion, rare creature,"
        " NPC with urgent news, weather change, mysterious sound."
        " Choose one and describe it briefly.",
        0, 6
    );
    if (r.success) {
        Remember("injected_event", r.output);
        Send("AgentNPC", "inject_event", r.output, MessagePriority::NORMAL);
        Log(LogLevel::INFO, "Injected event: " + r.output.substr(0, 60));
    }
}

void AgentPlayerCare::ReduceDifficulty() {
    TransformerResult r = Think(
        MakeContext(m_world_state,
            "deaths:" + std::to_string(m_recent_deaths)
            + " overwhelm:" + std::to_string(m_overwhelm_score)),
        "Player has died " + std::to_string(m_recent_deaths) +
        " times recently. Suggest subtle difficulty adjustments:"
        " enemy count, health pickup placement, boss aggression level."
        " Must feel natural — player should not notice.",
        1, 3
    );
    if (r.success) {
        Remember("difficulty_adjustment", r.output);
        Send("AgentCreature", "reduce_aggression",
             "overwhelm:" + std::to_string(m_overwhelm_score),
             MessagePriority::NORMAL);
        m_recent_deaths = 0;
    }
}

void AgentPlayerCare::NudgeTowardStory() {
    TransformerResult r = Think(
        MakeContext(m_world_state,
            "time_from_story:" + std::to_string(m_time_since_quest)),
        "Player has ignored the main story quest for " +
        std::to_string(static_cast<int>(m_time_since_quest / 60.0f)) +
        " minutes. What subtle nudge brings them back?"
        " Options: Kael dreams/flashback, gauntlet pulses,"
        " NPC mentions a rumor, Sera's voice, mysterious marking."
        " Choose one, describe how it triggers.",
        2, 5
    );
    if (r.success) {
        Remember("story_nudge", r.output);
        Send("AgentNPC", "story_nudge", r.output, MessagePriority::NORMAL);
        Log(LogLevel::INFO, "Story nudge: " + r.output.substr(0, 60));
    }
}

void AgentPlayerCare::HandlePlayerLowHealth(const AgentMessage& msg) {
    m_overwhelm_score = std::min(1.0f, m_overwhelm_score + 0.15f);
    TransformerResult r = Think(
        MakeContext(m_world_state, msg.content),
        "Player health critical: " + msg.content +
        ". Should a friendly NPC appear nearby to help?"
        " Should a healing item be more visible?"
        " Respond: action, natural_reason",
        1, 1
    );
    if (r.success) {
        Remember("low_health_response", r.output);
        Send("AgentNPC", "player_needs_help", r.output, MessagePriority::HIGH);
    }
}

void AgentPlayerCare::HandlePlayerDied(const AgentMessage& /*msg*/) {
    RecordDeath();
    // BUG F FIX: was stoi(Recall()) which crashes if Recall returns ""
    std::string s = Recall("death_count");
    int count = 0;
    if (!s.empty()) { try { count = std::stoi(s); } catch (...) { count = 0; } }
    Remember("death_count", std::to_string(count + 1));
}

void AgentPlayerCare::HandleCombatStart(const AgentMessage& /*msg*/) {
    m_time_since_action = 0.0f;
    m_boredom_score     = std::max(0.0f, m_boredom_score - 0.4f);
}

void AgentPlayerCare::HandleCombatEnd(const AgentMessage& /*msg*/) {
    m_recent_kills = 0; // Reset for next combat window
}

void AgentPlayerCare::HandleFragmentFound(const AgentMessage& /*msg*/) {
    m_time_since_quest  = 0.0f;  // Story progress resets drift timer
    m_boredom_score     = 0.0f;
    m_engagement_score  = std::min(1.0f, m_engagement_score + 0.3f);
}

} // namespace TerraEngine
