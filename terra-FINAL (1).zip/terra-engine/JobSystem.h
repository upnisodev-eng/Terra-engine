// ============================================================
// TERRA ENGINE — JOB SYSTEM + ASYNC AI + DETERMINISTIC SIM
// JobSystem.h — Version 1.0.0
// ============================================================
// FIX 4  — Async AI pipeline: gameplay never waits for AI
// FIX 9  — Fiber job system: replaces raw std::thread
// FIX 15 — Deterministic simulation: fixed timestep + state hash
// ============================================================

#pragma once

#include "AIConnector.h"
#include <functional>
#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <future>
#include <memory>
#include <string>
#include <map>
#include <array>
#include <cstdint>

namespace TerraEngine {

// ============================================================
// JOB — a unit of work
// FIX 9: replaces raw std::thread spawning
// ============================================================
enum class JobPriority { CRITICAL = 0, HIGH = 1, NORMAL = 2, LOW = 3 };

struct Job {
    std::function<void()> work;
    std::string           name;
    JobPriority           priority = JobPriority::NORMAL;
    bool                  operator>(const Job& o) const {
        return static_cast<int>(priority) > static_cast<int>(o.priority);
    }
};

// ============================================================
// JOB SYSTEM — thread pool with priority queue
// FIX 9: replaces all std::thread usage in engine
// ============================================================
class JobSystem {
public:
    static JobSystem& Get() {
        static JobSystem instance;
        return instance;
    }

    void Init(int thread_count = 0); // 0 = auto detect cores
    void Shutdown();

    // Submit a job — fire and forget
    void Submit(Job job);
    void Submit(std::function<void()> fn,
                const std::string& name = "",
                JobPriority priority = JobPriority::NORMAL);

    // Submit with future — get result back
    template<typename T>
    std::future<T> SubmitFuture(std::function<T()> fn,
                                const std::string& name = "") {
        auto promise = std::make_shared<std::promise<T>>();
        auto future  = promise->get_future();
        Submit([fn, promise]() {
            try {
                promise->set_value(fn());
            } catch (...) {
                promise->set_exception(std::current_exception());
            }
        }, name);
        return future;
    }

    // Wait for all jobs to finish
    void WaitAll();

    // Stats
    int  ActiveThreads()  const { return static_cast<int>(m_workers.size()); }
    int  PendingJobs()    const;
    int  CompletedJobs()  const { return m_completed.load(); }

private:
    JobSystem() : m_running(false), m_completed(0) {}
    ~JobSystem() { Shutdown(); }

    using PQueue = std::priority_queue<Job, std::vector<Job>, std::greater<Job>>;

    std::vector<std::thread>    m_workers;
    PQueue                      m_queue;
    mutable std::mutex          m_mutex;
    std::condition_variable     m_cv;
    std::atomic<bool>           m_running;
    std::atomic<int>            m_completed;
    std::atomic<int>            m_active;

    void WorkerLoop();
    static const char* MOD;
};

// ============================================================
// ASYNC AI PIPELINE
// FIX 4: AI decisions happen on background threads
// Gameplay reads LAST completed AI result — never waits
// ============================================================
struct AIDecisionRequest {
    std::string agent_name;
    std::string context;
    std::string question;
    Model       model       = Model::GQ_LLAMA;
    int         priority    = 5;
    uint64_t    request_id  = 0;
};

struct AIDecisionResult {
    uint64_t    request_id  = 0;
    std::string agent_name;
    std::string output;
    bool        success     = false;
    double      latency_ms  = 0.0;
};

class AsyncAIPipeline {
public:
    static AsyncAIPipeline& Get() {
        static AsyncAIPipeline instance;
        return instance;
    }

    // Submit AI decision — returns request_id immediately
    // Gameplay continues. Result available when ready.
    uint64_t RequestDecision(const AIDecisionRequest& req);

    // Poll for result — returns nullptr if not ready yet
    const AIDecisionResult* PollResult(uint64_t request_id);

    // Get result blocking (use only in non-time-critical code)
    AIDecisionResult WaitResult(uint64_t request_id,
                                float timeout_seconds = 5.0f);

    // Check if any results are ready
    bool HasPendingResults() const;

    // Get all ready results and clear them
    std::vector<AIDecisionResult> DrainResults();

    // Per-frame processing — call once per tick
    void Tick();

    int PendingCount() const { return m_pending.load(); }

private:
    AsyncAIPipeline() : m_next_id(1), m_pending(0) {}

    std::atomic<uint64_t>                   m_next_id;
    std::atomic<int>                        m_pending;

    mutable std::mutex                      m_results_mutex;
    std::map<uint64_t, AIDecisionResult>    m_results;

    void ProcessRequest(AIDecisionRequest req);

    static const char* MOD;
};

// ============================================================
// DETERMINISTIC SIMULATION
// FIX 15: Fixed timestep + state hash for replay/multiplayer
// ============================================================
class DeterministicSim {
public:
    static DeterministicSim& Get() {
        static DeterministicSim instance;
        return instance;
    }

    // Fixed timestep — 60Hz physics, 20Hz AI, 1Hz ecosystem
    static constexpr float PHYSICS_DT   = 1.0f / 60.0f;
    static constexpr float AI_DT        = 1.0f / 20.0f;
    static constexpr float ECOSYSTEM_DT = 1.0f / 1.0f;

    // Tick with real delta — internally handles fixed steps
    void Tick(float real_delta_time);

    // State hash — used for multiplayer validation
    uint64_t ComputeStateHash() const;

    // Replay recording
    void StartRecording();
    void StopRecording();
    bool SaveReplay(const std::string& filepath) const;
    bool LoadReplay(const std::string& filepath);
    void PlaybackTick(); // advance one replay frame

    uint64_t GetFrame()   const { return m_frame.load(); }
    float    GetSimTime() const { return m_sim_time; }
    bool     IsRecording() const { return m_recording; }

private:
    DeterministicSim()
        : m_frame(0), m_sim_time(0.0f)
        , m_physics_acc(0.0f), m_ai_acc(0.0f)
        , m_eco_acc(0.0f), m_recording(false)
    {}

    std::atomic<uint64_t>   m_frame;
    float                   m_sim_time;
    float                   m_physics_acc;
    float                   m_ai_acc;
    float                   m_eco_acc;
    bool                    m_recording;

    struct ReplayFrame {
        uint64_t frame_id;
        uint64_t state_hash;
        float    sim_time;
    };
    std::vector<ReplayFrame>    m_replay;
    size_t                      m_playback_idx = 0;

    static const char* MOD;
};

// ============================================================
// MACROS
// ============================================================
#define JOBS   JobSystem::Get()
#define AIPIPE AsyncAIPipeline::Get()
#define DETSIM DeterministicSim::Get()

} // namespace TerraEngine
