// ============================================================
// TERRA ENGINE — CHARACTER FRAGMENT SHADER
// character.frag
// ============================================================
// PBR character rendering with:
//   - Subsurface scattering (skin, ears)
//   - Kael gauntlet lava crack emissive
//   - Sera magic charge emissive (purple-cyan)
//   - Corruption skin taint (dark purple veins)
//   - Hair strand lighting (ULTRA — Kajiya-Kay model)
// ============================================================

#version 460

layout(location = 0) in vec3  in_world_pos;
layout(location = 1) in vec3  in_normal;
layout(location = 2) in vec2  in_uv;
layout(location = 3) in vec4  in_tangent;
layout(location = 4) in vec4  in_color;
layout(location = 5) in float in_depth;
layout(location = 6) in float in_magic_charge;

// GBuffer outputs
layout(location = 0) out vec4 out_albedo_metallic;
layout(location = 1) out vec4 out_normal_roughness;
layout(location = 2) out vec4 out_emissive_ao;

// Character textures
layout(set = 1, binding = 0) uniform sampler2D tex_albedo;
layout(set = 1, binding = 1) uniform sampler2D tex_normal;
layout(set = 1, binding = 2) uniform sampler2D tex_metallic_roughness;
layout(set = 1, binding = 3) uniform sampler2D tex_emissive;     // gauntlet crack / magic mask
layout(set = 1, binding = 4) uniform sampler2D tex_sss;          // SSS thickness map
layout(set = 1, binding = 5) uniform sampler2D tex_corruption;   // corruption vein mask

layout(push_constant) uniform CharPush {
    mat4  model;
    mat4  view_proj;
    float time;
    float magic_charge;
    float corruption;
    int   is_kael;        // 1=Kael 0=Sera/NPC
} push;

layout(set = 0, binding = 0) uniform CharMaterial {
    vec4  albedo_tint;
    float metallic;
    float roughness;
    float sss_strength;      // subsurface scatter intensity
    vec3  sss_colour;        // skin = warm peach, elf = cooler
    float emissive_intensity;
    int   use_hair_lighting; // ULTRA only
} mat;

// ============================================================
// NORMAL MAP
// ============================================================
vec3 ApplyNormalMap(vec3 N, vec4 T, vec2 uv) {
    vec3 t    = normalize(T.xyz);
    vec3 b    = cross(N, t) * T.w;
    mat3 TBN  = mat3(t, b, N);
    vec3 n    = texture(tex_normal, uv).rgb * 2.0 - 1.0;
    return normalize(TBN * n);
}

// ============================================================
// SUBSURFACE SCATTERING — pre-integrated skin SSS
// Simulates light bleeding through ears, nose, fingers
// ============================================================
vec3 SubsurfaceScatter(vec3 albedo, float thickness, vec3 sun_dir, vec3 N) {
    // Wrap lighting — light bleeds around edges
    float wrap_light = max(0.0, dot(N, -sun_dir) * 0.5 + 0.5);

    // Thickness-driven colour bleed
    vec3  trans      = mat.sss_colour * exp(-thickness * 3.0) * wrap_light;

    return trans * mat.sss_strength;
}

// ============================================================
// GAUNTLET GLOW — Kael's ancient power weapon
// ============================================================
vec3 GauntletEmissive(vec2 uv, float charge, float time) {
    vec4 crack_mask = texture(tex_emissive, uv);

    if (crack_mask.r < 0.1) return vec3(0.0);

    // Lava-crack glow — orange-gold, pulses with charge
    float pulse   = 0.7 + 0.3 * sin(time * 4.0);
    float intensity = crack_mask.r * charge * pulse * mat.emissive_intensity;

    // Colour shifts from deep orange to bright white at full charge
    vec3 low_col  = vec3(1.0, 0.3, 0.0);  // deep orange
    vec3 high_col = vec3(1.0, 0.8, 0.4);  // bright gold
    vec3 colour   = mix(low_col, high_col, charge);

    // Varek fragment corruption at max charge — purple taint
    if (charge > 0.8) {
        vec3 varek_col = vec3(0.7, 0.0, 1.0);
        colour = mix(colour, varek_col, (charge - 0.8) * 5.0 * 0.3);
    }

    return colour * intensity;
}

// ============================================================
// MAGIC EMISSIVE — Sera's purple-cyan magic circles
// ============================================================
vec3 MagicEmissive(vec2 uv, float charge, float time) {
    vec4 magic_mask = texture(tex_emissive, uv);
    if (magic_mask.g < 0.1) return vec3(0.0);

    // Rotating energy rings
    float ring    = magic_mask.g;
    float pulse   = 0.6 + 0.4 * sin(time * 3.5 + uv.x * 6.28);
    float spin    = 0.5 + 0.5 * sin(time * 2.0 + uv.y * 6.28 * 2.0);

    float intensity = ring * charge * pulse * mat.emissive_intensity;

    // Purple-cyan gradient based on power level
    vec3 purple   = vec3(0.8, 0.1, 1.0);
    vec3 cyan     = vec3(0.0, 0.9, 1.0);
    vec3 white    = vec3(1.0);

    vec3 colour   = mix(purple, cyan, spin);
    colour        = mix(colour, white, charge * 0.2); // bright white at max charge

    return colour * intensity;
}

// ============================================================
// CORRUPTION VEINS
// ============================================================
vec3 CorruptionEffect(vec3 albedo, vec2 uv, float corruption) {
    if (corruption < 0.1) return albedo;

    float vein_mask = texture(tex_corruption, uv).r;
    float lum       = dot(albedo, vec3(0.299, 0.587, 0.114));

    // Dark purple veins spreading across skin
    float pulse     = 0.5 + 0.5 * sin(push.time * 1.5 + vein_mask * 3.14);
    vec3  vein_col  = vec3(0.2, 0.0, 0.3) * pulse;
    float vein      = vein_mask * corruption;

    return mix(albedo, vein_col, vein * 0.8);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec4  albedo_tex = texture(tex_albedo, in_uv);
    if (albedo_tex.a < 0.1) discard;

    vec3  albedo     = albedo_tex.rgb * mat.albedo_tint.rgb * in_color.rgb;

    // Metallic/roughness
    vec2  mr         = texture(tex_metallic_roughness, in_uv).bg;
    float metallic   = mat.metallic  * mr.x;
    float roughness  = mat.roughness * mr.y;

    // Normal
    vec3  N          = ApplyNormalMap(normalize(in_normal), in_tangent, in_uv);

    // Subsurface scattering thickness (skin/ears = thick, armour = 0)
    float thickness  = texture(tex_sss, in_uv).r;

    // Apply corruption to skin
    albedo = CorruptionEffect(albedo, in_uv, push.corruption);

    // Build emissive
    vec3 emissive = vec3(0.0);
    if (push.is_kael == 1) {
        emissive += GauntletEmissive(in_uv, in_magic_charge, push.time);
    } else {
        emissive += MagicEmissive(in_uv, in_magic_charge, push.time);
    }

    // Pack SSS into AO channel (decoded in lighting pass)
    // Negative AO values signal SSS to lighting shader
    float ao_or_sss = mix(1.0, -thickness * mat.sss_strength, step(0.01, thickness));

    out_albedo_metallic  = vec4(albedo, metallic);
    out_normal_roughness = vec4(N * 0.5 + 0.5, roughness);
    out_emissive_ao      = vec4(emissive, ao_or_sss);
}
