// ============================================================
// TERRA ENGINE — TRANSFORMER BASE IMPLEMENTATION
// TransformerBase.cpp — Version 1.0.0
// ============================================================

#include "TransformerBase.h"
#include "AIConnector.h"
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <chrono>

namespace TerraEngine {

// ============================================================
// STATIC AI CONNECTOR — shared by all transformers
// ============================================================
// ============================================================
// SINGLE SHARED AI CONNECTOR
// ISSUE 1 FIX: Was two separate singletons — two curl_global_init
// calls = undefined behavior. Now one singleton shared everywhere.
// GetGlobalAI() is the single source of truth.
// ============================================================
AIConnector& TransformerBase::GetAI() {
    return GetGlobalAI(); // delegates to AIConnector.cpp singleton
}

// ============================================================
// TRANSFORMER BASE — CONSTRUCTOR
// ============================================================
TransformerBase::TransformerBase(int index,
                                  const std::string& domain,
                                  const std::string& agent_name,
                                  Model model)
    : m_index(index)
    , m_domain(domain)
    , m_agent_name(agent_name)
    , m_model(model)
    , m_state(TransformerState::IDLE)
    , m_fail_count(0)
{
    Log(LogLevel::INFO, "T[" + std::to_string(index) + "] born — domain: " + domain);
}

// ============================================================
// PROCESS — core task execution
// ============================================================
TransformerResult TransformerBase::Process(const TransformerTask& task) {
    // Guard — do not process if failed
    if (m_state.load() == TransformerState::FAILED) {
        TransformerResult result;
        result.success        = false;
        result.error          = "Transformer T[" + std::to_string(m_index) + "] is in FAILED state";
        result.task_id        = task.id;
        result.transformer_index = m_index;
        return result;
    }

    m_state.store(TransformerState::THINKING);
    auto t_start = std::chrono::high_resolution_clock::now();

    // Build prompt
    std::string prompt = BuildPrompt(task);

    // Build AI request
    AIRequest req;
    req.model         = m_model;
    req.prompt        = prompt;
    req.max_tokens    = 200;
    req.temperature   = 0.7f;
    req.system_prompt = "You are " + m_domain + " controller for the agent "
                      + m_agent_name + " in Legends of Terra game engine."
                      + " Respond concisely and decisively.";

    // Fallback chain — if primary model fails use these
    std::vector<Model> fallbacks = {
        Model::GQ_LLAMA,    // Groq — fast fallback
        Model::HF_MISTRAL,  // HuggingFace — free fallback
        Model::HF_PHI3      // Last resort
    };

    AIResponse ai_response = GetAI().CallWithFallback(req, fallbacks);

    auto t_end = std::chrono::high_resolution_clock::now();
    double latency = std::chrono::duration<double, std::milli>(t_end - t_start).count();

    TransformerResult result = ParseResponse(ai_response, task);
    result.transformer_index = m_index;
    result.latency_ms        = latency;

    if (result.success) {
        m_state.store(TransformerState::IDLE);
        UpdateStats(true, latency);
        Log(LogLevel::DEBUG, "T[" + std::to_string(m_index)
                           + "] done in " + std::to_string(static_cast<int>(latency)) + "ms");
    } else {
        m_fail_count++;
        m_last_error = result.error;
        m_state.store(m_fail_count >= 3 ? TransformerState::FAILED
                                        : TransformerState::RECOVERING);
        UpdateStats(false, latency);
        Log(LogLevel::WARNING, "T[" + std::to_string(m_index)
                             + "] failed: " + result.error);
    }

    return result;
}

// ============================================================
// BUILD PROMPT — override in subclasses for specialised prompts
// ============================================================
std::string TransformerBase::BuildPrompt(const TransformerTask& task) const {
    std::ostringstream ss;
    ss << "Agent: "     << m_agent_name << "\n";
    ss << "Domain: "    << m_domain     << "\n";
    ss << "Context: "   << task.context << "\n";
    ss << "Task: "      << task.question << "\n";
    ss << "Priority: "  << task.priority << "/10\n";
    ss << "Respond with a clear, decisive action in 1-3 sentences.";
    return ss.str();
}

// ============================================================
// PARSE RESPONSE — override for specialised parsing
// ============================================================
TransformerResult TransformerBase::ParseResponse(const AIResponse& response,
                                                   const TransformerTask& task) const
{
    TransformerResult result;
    result.task_id = task.id;

    if (!response.success) {
        result.success = false;
        result.error   = response.error.empty() ? "AI call failed" : response.error;
        return result;
    }

    if (response.text.empty()) {
        result.success = false;
        result.error   = "Empty response from AI";
        return result;
    }

    result.success    = true;
    result.output     = response.text;
    result.confidence = 0.8f; // Default confidence

    return result;
}

// ============================================================
// HEALTH AND STATE
// ============================================================
bool TransformerBase::IsHealthy() const {
    TransformerState s = m_state.load();
    return s != TransformerState::FAILED;
}

TransformerState TransformerBase::GetState() const {
    return m_state.load();
}

void TransformerBase::Reset() {
    m_state.store(TransformerState::IDLE);
    m_fail_count.store(0);
    m_last_error.clear();
    Log(LogLevel::INFO, "T[" + std::to_string(m_index) + "] reset");
}

void TransformerBase::MarkFailed(const std::string& reason) {
    m_state.store(TransformerState::FAILED);
    m_last_error = reason;
    Log(LogLevel::ERR, "T[" + std::to_string(m_index) + "] marked failed: " + reason);
}

// ============================================================
// MEMORY
// ============================================================
void TransformerBase::AddMemory(const std::string& key,
                                  const std::string& value)
{
    std::lock_guard<std::mutex> lock(m_memory_mutex);

    // Remove oldest if at capacity
    if (m_memory.size() >= MAX_MEMORY && !m_memory_order.empty()) {
        m_memory.erase(m_memory_order.front().first);
        m_memory_order.pop_front();
    }

    // Update existing or add new
    auto it = m_memory.find(key);
    if (it != m_memory.end()) {
        it->second = value;
    } else {
        m_memory[key] = value;
        m_memory_order.push_back({key, value});
    }
}

std::string TransformerBase::GetMemory(const std::string& key) const {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    auto it = m_memory.find(key);
    return (it != m_memory.end()) ? it->second : "";
}

void TransformerBase::ClearMemory() {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    m_memory.clear();
    m_memory_order.clear();
}

size_t TransformerBase::MemorySize() const {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    return m_memory.size();
}

// ============================================================
// STATS
// ============================================================
void TransformerBase::UpdateStats(bool success, double latency_ms) {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.tasks_processed++;
    if (!success) m_stats.tasks_failed++;
    // Welford online average
    double delta = latency_ms - m_stats.avg_latency_ms;
    m_stats.avg_latency_ms += delta / m_stats.tasks_processed;
}

TransformerBase::Stats TransformerBase::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}

// ============================================================
// LOGGING
// ============================================================
void TransformerBase::Log(LogLevel level, const std::string& msg) const {
    std::string mod = m_agent_name + "::T" + std::to_string(m_index);
    Logger::Get().Log(level, mod, msg);
}

// ============================================================
// TRANSFORMER POOL — STATIC
// ============================================================
const char* TransformerPool::MOD = "TransformerPool";

// ============================================================
// TRANSFORMER POOL — CONSTRUCTOR
// ============================================================
TransformerPool::TransformerPool(const std::string& agent_name)
    : m_agent_name(agent_name)
{
    TLOG_INFO(MOD, agent_name + " pool created");
}

// ============================================================
// ADD TRANSFORMER
// ============================================================
void TransformerPool::AddTransformer(std::shared_ptr<TransformerBase> transformer) {
    std::lock_guard<std::mutex> lock(m_mutex);
    // BUG 11 FIX: cap raised from 4 to 8
    // AgentEnvironment and AgentCreature both register 6 transformers
    if (m_transformers.size() >= 8) {
        TLOG_WARN(MOD, m_agent_name + " already has 8 transformers — max reached");
        return;
    }
    m_transformers.push_back(std::move(transformer));
    TLOG_INFO(MOD, m_agent_name + " now has "
                 + std::to_string(m_transformers.size()) + " transformers");
}

// ============================================================
// PROCESS — fault tolerant delegation
// ============================================================
TransformerResult TransformerPool::Process(const TransformerTask& task) {
    std::lock_guard<std::mutex> lock(m_mutex);

    if (m_transformers.empty()) {
        TransformerResult r;
        r.success = false;
        r.error   = m_agent_name + " has no transformers";
        TLOG_ERR(MOD, r.error);
        return r;
    }

    // Try transformers in order — skip failed ones
    for (size_t i = 0; i < m_transformers.size(); i++) {
        auto& t = m_transformers[i];
        if (!t || !t->IsHealthy()) {
            TLOG_WARN(MOD, m_agent_name + " T[" + std::to_string(i) + "] unhealthy — skipping");
            continue;
        }

        TransformerResult result = t->Process(task);
        if (result.success) return result;

        TLOG_WARN(MOD, m_agent_name + " T[" + std::to_string(i) + "] failed — trying next");
    }

    // All failed
    TransformerResult r;
    r.success = false;
    r.error   = m_agent_name + " all transformers failed for task: " + task.id;
    TLOG_ERR(MOD, r.error);
    return r;
}

// ============================================================
// PROCESS ON SPECIFIC TRANSFORMER
// ============================================================
TransformerResult TransformerPool::ProcessOn(int index,
                                               const TransformerTask& task) {
    std::lock_guard<std::mutex> lock(m_mutex);

    if (index < 0 || index >= static_cast<int>(m_transformers.size())) {
        TransformerResult r;
        r.success = false;
        r.error   = "Transformer index " + std::to_string(index) + " out of range";
        TLOG_ERR(MOD, r.error);
        return r;
    }

    auto& t = m_transformers[index];
    if (!t) {
        TransformerResult r;
        r.success = false;
        r.error   = "Transformer at index " + std::to_string(index) + " is null";
        return r;
    }

    return t->Process(task);
}

// ============================================================
// HEALTH
// ============================================================
int TransformerPool::HealthyCount() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    int count = 0;
    for (const auto& t : m_transformers) {
        if (t && t->IsHealthy()) count++;
    }
    return count;
}

bool TransformerPool::HasHealthy() const {
    return HealthyCount() > 0;
}

void TransformerPool::ResetAll() {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& t : m_transformers) {
        if (t) t->Reset();
    }
    TLOG_INFO(MOD, m_agent_name + " all transformers reset");
}

std::shared_ptr<TransformerBase> TransformerPool::Get(int index) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (index < 0 || index >= static_cast<int>(m_transformers.size()))
        return nullptr;
    return m_transformers[index];
}

std::shared_ptr<TransformerBase> TransformerPool::GetHealthy(int preferred) {
    std::lock_guard<std::mutex> lock(m_mutex);
    // Try preferred first
    if (preferred >= 0 && preferred < static_cast<int>(m_transformers.size())) {
        if (m_transformers[preferred] && m_transformers[preferred]->IsHealthy())
            return m_transformers[preferred];
    }
    // Otherwise find first healthy
    for (auto& t : m_transformers) {
        if (t && t->IsHealthy()) return t;
    }
    return nullptr;
}

void TransformerPool::PrintStatus() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    TLOG_INFO(MOD, "--- " + m_agent_name + " Transformer Pool ---");
    for (size_t i = 0; i < m_transformers.size(); i++) {
        if (!m_transformers[i]) {
            TLOG_INFO(MOD, "  T[" + std::to_string(i) + "] NULL");
            continue;
        }
        auto& t = *m_transformers[i];
        std::string healthy = t.IsHealthy() ? "OK" : "FAILED";
        TLOG_INFO(MOD, "  T[" + std::to_string(i) + "] "
                     + t.GetDomain() + " — " + healthy
                     + " — fails: " + std::to_string(t.GetFailCount())
                     + " — memory: " + std::to_string(t.MemorySize()));
    }
}

} // namespace TerraEngine
