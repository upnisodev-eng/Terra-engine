// ============================================================
// TERRA ENGINE — SKYBOX VERTEX SHADER
// skybox.vert
// ============================================================

#version 460

layout(location = 0) out vec3 out_dir;

layout(set = 0, binding = 0) uniform SkyCamera {
    mat4 inv_view_rot;  // view matrix with translation zeroed
    mat4 inv_proj;
} cam;

void main() {
    // Fullscreen triangle — same as postprocess
    vec2 pos[3] = vec2[](vec2(-1,-1), vec2(3,-1), vec2(-1,3));
    vec2 ndc    = pos[gl_VertexIndex];
    gl_Position = vec4(ndc, 1.0, 1.0); // z=1 = far plane

    // Unproject to world direction
    vec4 clip   = vec4(ndc, 1.0, 1.0);
    vec4 view   = cam.inv_proj * clip;
    view.w      = 0.0;
    out_dir     = (cam.inv_view_rot * view).xyz;
}
