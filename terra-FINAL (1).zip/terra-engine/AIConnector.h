// ============================================================
// TERRA ENGINE — AI CONNECTOR HEADER
// AIConnector.h — Version 1.3.0
// ============================================================
// BUG 2 FIX: Renamed to match AIConnector.cpp exactly:
//   MapModels()       → InitModelMappings()
//   CallOpenAIStyle() → CallOpenAICompat()
//   m_model_map       → m_model_providers
// BUG 3 FIX: GetGlobalAI() now implemented in AIConnector.cpp
// Providers: HuggingFace, OpenRouter, DeepSeek, Groq, Mistral
// ============================================================

#pragma once

#include <string>
#include <map>
#include <vector>
#include <functional>
#include <memory>
#include <chrono>
#include <thread>
#include <mutex>
#include <fstream>
#include <sstream>
#include <iostream>

namespace TerraEngine {

// ============================================================
// LOGGER
// ============================================================
enum class LogLevel { DEBUG, INFO, WARNING, ERR, CRITICAL };

class Logger {
public:
    static Logger& Get() { static Logger i; return i; }
    void SetLevel(LogLevel l) { m_level = l; }
    void OpenFile(const std::string& p) {
        std::lock_guard<std::mutex> lock(m_mx);
        m_file.open(p, std::ios::app);
    }
    void Log(LogLevel l, const std::string& mod, const std::string& msg) {
        if (l < m_level) return;
        std::lock_guard<std::mutex> lock(m_mx);
        std::string line = Prefix(l) + " [" + mod + "] " + msg;
        std::cout << line << "\n";
        if (m_file.is_open()) { m_file << line << "\n"; m_file.flush(); }
    }
private:
    Logger() : m_level(LogLevel::INFO) {}
    ~Logger() { if (m_file.is_open()) m_file.close(); }
    LogLevel      m_level;
    std::mutex    m_mx;
    std::ofstream m_file;
    static const char* Prefix(LogLevel l) {
        switch (l) {
            case LogLevel::DEBUG:    return "[DEBUG]   ";
            case LogLevel::INFO:     return "[INFO]    ";
            case LogLevel::WARNING:  return "[WARNING] ";
            case LogLevel::ERR:      return "[ERROR]   ";
            case LogLevel::CRITICAL: return "[CRITICAL]";
            default:                 return "[LOG]     ";
        }
    }
};

#define TLOG_INFO(m,s)     TerraEngine::Logger::Get().Log(TerraEngine::LogLevel::INFO,    m,s)
#define TLOG_WARN(m,s)     TerraEngine::Logger::Get().Log(TerraEngine::LogLevel::WARNING, m,s)
#define TLOG_ERR(m,s)      TerraEngine::Logger::Get().Log(TerraEngine::LogLevel::ERR,     m,s)
#define TLOG_DEBUG(m,s)    TerraEngine::Logger::Get().Log(TerraEngine::LogLevel::DEBUG,   m,s)
#define TLOG_CRITICAL(m,s) TerraEngine::Logger::Get().Log(TerraEngine::LogLevel::CRITICAL,m,s)

// ============================================================
// ENV LOADER
// FIX 3: s_env shared across threads — all access now mutex-protected
// FIX 11: validate required keys exist after loading, warn on missing
// ============================================================
class EnvLoader {
public:
    static bool Load(const std::string& path = ".env") {
        std::ifstream f(path);
        if (!f.is_open()) { TLOG_WARN("EnvLoader","Cannot open: "+path); return false; }

        std::string line; int n = 0;
        std::map<std::string, std::string> loaded;

        while (std::getline(f, line)) {
            if (!line.empty() && line.back()=='\r') line.pop_back();
            if (line.empty() || line[0]=='#') continue;
            auto pos = line.find('=');
            if (pos==std::string::npos) continue;
            std::string k=Trim(line.substr(0,pos)), v=Trim(line.substr(pos+1));
            if (!k.empty() && !v.empty()) { loaded[k]=v; n++; }
        }

        // FIX 3: write to s_env under mutex
        {
            std::lock_guard<std::mutex> lock(s_mutex);
            for (auto& [k, v] : loaded) s_env[k] = v;
        }

        TLOG_INFO("EnvLoader","Loaded "+std::to_string(n)+" keys from "+path);

        // FIX 11: validate required provider keys exist
        ValidateRequiredKeys();
        return n > 0;
    }

    static std::string Get(const std::string& k, const std::string& fb="") {
        // FIX 3: read under mutex
        {
            std::lock_guard<std::mutex> lock(s_mutex);
            auto it = s_env.find(k);
            if (it != s_env.end()) return it->second;
        }
        // fallback to OS environment (read-only, thread-safe)
        const char* os = std::getenv(k.c_str());
        if (os) return std::string(os);
        return fb;
    }

    static bool Has(const std::string& k) {
        std::lock_guard<std::mutex> lock(s_mutex);
        return s_env.count(k) > 0;
    }

private:
    static std::map<std::string, std::string> s_env;
    static std::mutex                          s_mutex;

    // FIX 11: check required keys, warn clearly on missing
    static void ValidateRequiredKeys() {
        const char* required[] = {
            "HF_API_KEY",  "HF_BASE_URL",
            "OR_API_KEY",  "OR_BASE_URL",
            "DS_API_KEY",  "DS_BASE_URL",
            "GQ_API_KEY",  "GQ_BASE_URL",
            "MS_API_KEY",  "MS_BASE_URL",
            "REQUEST_TIMEOUT", "MAX_RETRIES",
            nullptr
        };
        for (int i = 0; required[i] != nullptr; i++) {
            if (!Has(required[i])) {
                TLOG_WARN("EnvLoader",
                    std::string("MISSING required key: ") + required[i]
                    + " — provider will be disabled");
            }
        }
    }

    static std::string Trim(const std::string& s) {
        const std::string ws=" \t\r\n\"'";
        size_t a=s.find_first_not_of(ws), b=s.find_last_not_of(ws);
        return a==std::string::npos?"":s.substr(a,b-a+1);
    }
};

// ============================================================
// PROVIDER ENUM
// ============================================================
enum class Provider {
    HUGGINGFACE, OPENROUTER, DEEPSEEK,
    GROQ, MISTRAL,
    UNKNOWN
};

// ============================================================
// MODEL ENUM
// ============================================================
enum class Model {
    HF_PHI3, HF_QWEN, HF_MISTRAL, HF_LLAMA, HF_GEMMA,
    HF_BARK, HF_WHISPER,
    OR_GPT4O, OR_CLAUDE, OR_LLAMA405B, OR_MIXTRAL, OR_CLAUDE_HAIKU,
    DS_CHAT, DS_CODER, DS_REASONER,
    GQ_LLAMA, GQ_MIXTRAL, GQ_GEMMA, GQ_LLAMA_FAST,
    MS_LARGE, MS_MEDIUM, MS_SMALL, MS_NEMO,
    UNKNOWN
};

// ============================================================
// AI REQUEST / RESPONSE
// ============================================================
struct AIRequest {
    std::string prompt;
    Model       model        = Model::UNKNOWN;
    int         max_tokens   = 300;
    float       temperature  = 0.7f;
    std::string system_prompt;
};

struct AIResponse {
    bool        success       = false;
    std::string text;
    std::string model_used;
    std::string provider_name;
    int         tokens_used   = 0;
    double      latency_ms    = 0.0;
    std::string error;
    int         retry_count   = 0;
    Provider    provider_used = Provider::UNKNOWN;
};

// ============================================================
// PROVIDER CONFIG / ENGINE CONFIG
// ============================================================
struct ProviderConfig {
    std::string api_key;
    std::string base_url;
    bool        enabled    = true;
    int         rate_limit = 100;
    int         calls_made = 0;
};

struct EngineConfig {
    int   max_retries     = 3;
    int   timeout_seconds = 30;
    int   max_tokens      = 300;
    float temperature     = 0.7f;
    bool  debug           = false;
};

// ============================================================
// AI CONNECTOR
// ============================================================
class AIConnector {
public:
    AIConnector();
    ~AIConnector();

    bool Init(const std::string& env_path = ".env");

    AIResponse Call(const AIRequest& request);

    AIResponse CallWithFallback(
        const AIRequest& request,
        const std::vector<Model>& fallback_chain
    );

    void CallAsync(
        const AIRequest& request,
        std::function<void(AIResponse)> callback
    );

    void WaitAllAsync();

    bool                     TestProvider(Provider p);
    std::map<Provider, bool> TestAll();
    bool                     IsProviderAvailable(Provider p);

    struct Stats {
        int                     total_calls      = 0;
        int                     successful_calls = 0;
        int                     failed_calls     = 0;
        double                  avg_latency_ms   = 0.0;
        std::map<Provider, int> calls_per_provider;
        std::map<Provider, int> failures_per_provider;
    };
    Stats GetStats()    const;
    void  PrintStats()  const;
    void  ResetRateLimits();

private:
    static const char* MOD;

    EngineConfig                       m_config;
    std::map<Provider, ProviderConfig> m_providers;
    // BUG 2 FIX: renamed from m_model_map to match cpp
    std::map<Model, Provider>          m_model_providers;
    std::map<Model, std::string>       m_model_ids;

    mutable std::mutex m_stats_mutex;
    Stats              m_stats;

    // BUG 3 FIX: m_threads vector leaked — joinable() returns true for
    // finished-but-not-joined threads so remove_if never pruned them.
    // Replaced with detach + atomic counter. Zero memory growth.
    std::atomic<int> m_active_async{0};
    // m_threads and m_threads_mutex removed — no longer needed

    bool        LoadConfig      (const std::string& path);
    // BUG 2 FIX: renamed from MapModels to match cpp
    void        InitModelMappings();
    std::string Var             (const std::string& k, const std::string& fb = "");

    AIResponse  CallHuggingFace (const AIRequest& req, const ProviderConfig& cfg);
    // BUG 2 FIX: renamed from CallOpenAIStyle to match cpp
    AIResponse  CallOpenAICompat(const AIRequest& req, const ProviderConfig& cfg);
    AIResponse  CallWithRetry   (const AIRequest& req, Provider provider);

    bool        IsRateLimited   (Provider p);
    void        IncrementCount  (Provider p);
    void        UpdateStats     (const AIResponse& r, double ms);
    std::string ProviderName    (Provider p) const;
    std::string ModelName       (Model m)    const;
};

// ============================================================
// BUG 3 FIX: GetGlobalAI() — implemented in AIConnector.cpp
// Returns the single shared AIConnector used by all transformers
// This is the same instance as TransformerBase::GetAI()
// ============================================================
AIConnector& GetGlobalAI();

} // namespace TerraEngine
