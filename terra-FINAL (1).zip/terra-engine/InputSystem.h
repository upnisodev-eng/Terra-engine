// ============================================================
// TERRA ENGINE — INPUT SYSTEM
// InputSystem.h — Version 1.0.0
// ============================================================
// Unified input for: Keyboard, Mouse, Gamepad, Touch.
// Platform: Windows, Linux, macOS, Android, iOS.
// Action mapping — game code uses action names not raw keys.
// Supports rebinding. Analog sticks with dead zones.
// ============================================================

#pragma once

#include <string>
#include <map>
#include <vector>
#include <functional>
#include <mutex>
#include <atomic>
#include <array>
#include <set>

namespace TerraEngine {

// ============================================================
// KEY CODES — platform-agnostic
// ============================================================
enum class Key {
    // Letters
    A,B,C,D,E,F,G,H,I,J,K,L,M,
    N,O,P,Q,R,S,T,U,V,W,X,Y,Z,
    // Numbers
    Num0,Num1,Num2,Num3,Num4,
    Num5,Num6,Num7,Num8,Num9,
    // Function
    F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,
    // Control
    Space,Enter,Escape,Tab,BackSpace,
    LShift,RShift,LCtrl,RCtrl,LAlt,RAlt,
    // Arrow
    Up,Down,Left,Right,
    // Numpad
    NP0,NP1,NP2,NP3,NP4,NP5,NP6,NP7,NP8,NP9,
    // Misc
    Tilde,Minus,Equals,LeftBracket,RightBracket,
    Semicolon,Apostrophe,Comma,Period,Slash,BackSlash,
    Insert,Delete,Home,End,PageUp,PageDown,
    COUNT
};

// ============================================================
// MOUSE BUTTON
// ============================================================
enum class MouseButton { Left, Right, Middle, X1, X2, COUNT };

// ============================================================
// GAMEPAD BUTTON
// ============================================================
enum class GamepadButton {
    A, B, X, Y,
    LBumper, RBumper,
    LTrigger, RTrigger,
    LStick, RStick,
    DPadUp, DPadDown, DPadLeft, DPadRight,
    Start, Select, Guide,
    COUNT
};

// ============================================================
// GAMEPAD AXIS
// ============================================================
enum class GamepadAxis {
    LeftX, LeftY,
    RightX, RightY,
    LeftTrigger, RightTrigger,
    COUNT
};

// ============================================================
// INPUT STATE
// ============================================================
enum class InputState { Released, Pressed, Held, Repeated };

// ============================================================
// ACTION — named input mapping
// ============================================================
struct ActionBinding {
    std::string  name;
    Key          key          = Key::COUNT;
    MouseButton  mouse_btn    = MouseButton::COUNT;
    GamepadButton gamepad_btn = GamepadButton::COUNT;
    bool         shift        = false;
    bool         ctrl         = false;
    bool         alt          = false;
};

// ============================================================
// TOUCH POINT
// ============================================================
struct TouchPoint {
    int   id       = 0;
    float x        = 0.0f;
    float y        = 0.0f;
    float dx       = 0.0f;  // delta from last frame
    float dy       = 0.0f;
    float pressure = 1.0f;
    bool  active   = false;
};

// ============================================================
// INPUT SYSTEM
// ============================================================
class InputSystem {
public:
    static InputSystem& Get() {
        static InputSystem instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init / Shutdown
    // Call Init with your GLFW window pointer
    // --------------------------------------------------------
    void Init(void* window_handle);
    void Shutdown();

    // Per-frame — call at START of frame before game update
    void BeginFrame();
    // Per-frame — call at END of frame
    void EndFrame();

    // --------------------------------------------------------
    // KEYBOARD
    // --------------------------------------------------------
    bool IsKeyDown    (Key k) const;  // held this frame
    bool IsKeyPressed (Key k) const;  // just went down
    bool IsKeyReleased(Key k) const;  // just went up
    bool IsKeyRepeated(Key k) const;  // OS repeat event

    // --------------------------------------------------------
    // MOUSE
    // --------------------------------------------------------
    bool  IsMouseDown    (MouseButton b) const;
    bool  IsMousePressed (MouseButton b) const;
    bool  IsMouseReleased(MouseButton b) const;

    float GetMouseX()   const { return m_mouse_x; }
    float GetMouseY()   const { return m_mouse_y; }
    float GetMouseDX()  const { return m_mouse_dx; }
    float GetMouseDY()  const { return m_mouse_dy; }
    float GetScrollX()  const { return m_scroll_x; }
    float GetScrollY()  const { return m_scroll_y; }

    void  SetMouseCapture(bool capture);  // FPS mode — hides cursor
    bool  IsMouseCaptured() const { return m_mouse_captured; }

    // --------------------------------------------------------
    // GAMEPAD (up to 4 controllers)
    // --------------------------------------------------------
    bool  IsGamepadConnected (int pad_id = 0) const;
    bool  IsGamepadDown      (GamepadButton b, int pad_id = 0) const;
    bool  IsGamepadPressed   (GamepadButton b, int pad_id = 0) const;
    bool  IsGamepadReleased  (GamepadButton b, int pad_id = 0) const;
    float GetGamepadAxis     (GamepadAxis a,   int pad_id = 0) const;

    void  SetDeadZone(float dz) { m_dead_zone = dz; }

    // --------------------------------------------------------
    // TOUCH (mobile)
    // --------------------------------------------------------
    int              GetTouchCount() const;
    const TouchPoint GetTouch(int idx) const;
    bool             IsTouching()     const { return m_touch_count > 0; }

    // Gesture detection
    bool  IsSwipeLeft()   const;
    bool  IsSwipeRight()  const;
    bool  IsSwipeUp()     const;
    bool  IsSwipeDown()   const;
    float GetPinchDelta() const;  // positive = spread, negative = pinch

    // --------------------------------------------------------
    // ACTION MAPPING
    // --------------------------------------------------------
    void BindAction (const ActionBinding& binding);
    void UnbindAction(const std::string& name);
    bool IsActionDown    (const std::string& name) const;
    bool IsActionPressed (const std::string& name) const;
    bool IsActionReleased(const std::string& name) const;

    // Built-in game actions
    void BindDefaultGameActions();

    // --------------------------------------------------------
    // CALLBACKS — register to receive raw events
    // --------------------------------------------------------
    using KeyCallback    = std::function<void(Key, InputState)>;
    using MouseCallback  = std::function<void(MouseButton, InputState)>;
    using TextCallback   = std::function<void(unsigned int)>; // unicode char

    void OnKey  (const std::string& id, KeyCallback   cb);
    void OnMouse(const std::string& id, MouseCallback cb);
    void OnText (const std::string& id, TextCallback  cb);
    void RemoveCallback(const std::string& id);

    // --------------------------------------------------------
    // GLFW callbacks — called by GLFW internals
    // --------------------------------------------------------
    void _OnKey      (int key, int scancode, int action, int mods);
    void _OnMouseBtn (int button, int action, int mods);
    void _OnMouseMove(double x, double y);
    void _OnScroll   (double dx, double dy);
    void _OnChar     (unsigned int codepoint);

    // --------------------------------------------------------
    // Config — save/load keybindings
    // --------------------------------------------------------
    bool SaveBindings(const std::string& filepath) const;
    bool LoadBindings(const std::string& filepath);

private:
    InputSystem();

    static constexpr int MAX_KEYS    = static_cast<int>(Key::COUNT);
    static constexpr int MAX_MOUSE   = static_cast<int>(MouseButton::COUNT);
    static constexpr int MAX_GAMEPAD = static_cast<int>(GamepadButton::COUNT);
    static constexpr int MAX_PADS    = 4;
    static constexpr int MAX_TOUCHES = 10;

    // Keyboard state — current + previous frame
    std::array<bool, MAX_KEYS> m_keys_cur  = {};
    std::array<bool, MAX_KEYS> m_keys_prev = {};
    std::array<bool, MAX_KEYS> m_keys_rep  = {}; // OS repeat

    // Mouse state
    std::array<bool, MAX_MOUSE> m_mouse_cur  = {};
    std::array<bool, MAX_MOUSE> m_mouse_prev = {};
    float m_mouse_x = 0, m_mouse_y = 0;
    float m_mouse_dx = 0, m_mouse_dy = 0;
    float m_mouse_last_x = 0, m_mouse_last_y = 0;
    float m_scroll_x = 0, m_scroll_y = 0;
    bool  m_mouse_captured = false;
    bool  m_mouse_first    = true;

    // Gamepad state
    struct GamepadState {
        bool  connected                          = false;
        std::array<bool,  MAX_GAMEPAD> btns_cur  = {};
        std::array<bool,  MAX_GAMEPAD> btns_prev = {};
        std::array<float, static_cast<int>(GamepadAxis::COUNT)> axes = {};
    };
    std::array<GamepadState, MAX_PADS> m_pads;
    float m_dead_zone = 0.15f;

    // Touch
    std::array<TouchPoint, MAX_TOUCHES> m_touches;
    int m_touch_count = 0;
    float m_pinch_delta = 0.0f;

    // Action map
    mutable std::mutex                      m_mutex;
    std::map<std::string, ActionBinding>    m_actions;

    // Callbacks
    std::map<std::string, KeyCallback>   m_key_cbs;
    std::map<std::string, MouseCallback> m_mouse_cbs;
    std::map<std::string, TextCallback>  m_text_cbs;

    void* m_window = nullptr;

    void PollGamepads();
    float ApplyDeadZone(float v) const;

    // GLFW key to our Key enum
    static Key GLFWKeyToKey(int glfw_key);
    static MouseButton GLFWButtonToMouseButton(int btn);

    static const char* MOD;
};

#define INPUT InputSystem::Get()

} // namespace TerraEngine
