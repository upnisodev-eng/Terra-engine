// ============================================================
// TERRA ENGINE — ENTITY COMPONENT SYSTEM
// ECS.h — Version 1.0.0
// ============================================================
// FIX 2: Replaces deep inheritance with flat ECS.
// Entities are IDs. Components are plain data structs.
// Systems operate on component arrays — cache friendly.
// No virtual calls. No deep hierarchy. Pure data.
// ============================================================

#pragma once

#include "AIConnector.h"
#include <cstdint>
#include <array>
#include <vector>
#include <map>
#include <bitset>
#include <memory>
#include <functional>
#include <mutex>
#include <string>

namespace TerraEngine {

// ============================================================
// ENTITY — just an ID
// ============================================================
using Entity   = uint32_t;
using EntityVer= uint32_t;

static constexpr Entity   NULL_ENTITY    = 0;
static constexpr uint32_t MAX_ENTITIES   = 65536;
static constexpr uint32_t MAX_COMPONENTS = 64;

using ComponentMask = std::bitset<MAX_COMPONENTS>;

// ============================================================
// COMPONENT IDs — each type gets a unique compile-time ID
// ============================================================
struct ComponentID {
    static uint32_t Next() {
        static uint32_t counter = 0;
        return counter++;
    }
    template<typename T>
    static uint32_t Get() {
        static uint32_t id = Next();
        return id;
    }
};

// ============================================================
// COMPONENTS — plain data, no logic, no virtual
// ============================================================

struct TransformComponent {
    float x = 0.0f, y = 0.0f, z = 0.0f;
    float rot_y = 0.0f;   // yaw only for now
    float scale = 1.0f;
};

struct VelocityComponent {
    float vx = 0.0f, vy = 0.0f, vz = 0.0f;
    float max_speed = 5.0f;
};

struct HealthComponent {
    float hp     = 100.0f;
    float max_hp = 100.0f;
    bool  alive  = true;
    float regen_rate = 0.0f;
};

struct AIStateComponent {
    std::string behavior    = "idle";
    std::string target_id;
    float       think_timer = 0.0f;
    float       think_rate  = 1.0f; // seconds between AI ticks
    bool        is_npc      = false;
    bool        is_enemy    = false;
    bool        is_boss     = false;
};

struct CombatComponent {
    float damage         = 10.0f;
    float attack_range   = 2.0f;
    float attack_cooldown = 1.0f;
    float cooldown_timer  = 0.0f;
    bool  in_combat      = false;
    std::string weapon_type = "none";
};

struct InventoryComponent {
    static constexpr int MAX_SLOTS = 40;
    struct Slot { std::string item_id; int count = 0; };
    std::array<Slot, MAX_SLOTS> slots;
    int  gold    = 0;
    bool is_open = false;
};

struct RenderComponent {
    std::string model_id;
    std::string texture_id;
    bool        visible   = true;
    float       lod_level = 0.0f; // 0=high 1=low
    bool        cast_shadow = true;
};

struct AnimationComponent {
    std::string current_anim = "idle";
    std::string queued_anim;
    float       anim_time   = 0.0f;
    float       anim_speed  = 1.0f;
    bool        loop        = true;
    bool        blending    = false;
    float       blend_alpha = 0.0f;
};

struct CollisionComponent {
    float radius   = 0.5f;
    float height   = 1.8f;
    bool  is_solid = true;
    bool  trigger  = false;
    std::string collision_layer = "default";
};

struct NPCDataComponent {
    std::string name;
    std::string job;
    std::string personality;
    float       hunger     = 1.0f;
    float       thirst     = 1.0f;
    float       mood       = 0.7f;
    float       money      = 0.5f;
    int         island_id  = 1;
    bool        is_vendor  = false;
};

struct PlayerComponent {
    bool  is_kael      = true;  // false = Sera
    int   level        = 1;
    float xp           = 0.0f;
    float xp_to_next   = 100.0f;
    float stamina      = 100.0f;
    float max_stamina  = 100.0f;
    float hunger       = 1.0f;
    float thirst       = 1.0f;
    float gauntlet_charge = 0.0f; // Kael only
    float magic_charge    = 0.0f; // Sera only
};

struct BossComponent {
    std::string boss_id;
    std::string boss_name;
    int         phase           = 1;
    int         max_phases      = 3;
    float       phase_threshold = 0.6f;
    bool        is_enraged      = false;
    float       power_mult      = 1.0f;
};

struct CreatureComponent {
    std::string type          = "wolf";
    std::string behavior_mode = "peaceful";
    std::string pack_id;
    float       aggro_range   = 15.0f;
    bool        is_nocturnal  = false;
    bool        is_corrupted  = false;
};

struct PhysicsComponent {
    float mass         = 1.0f;
    bool  gravity      = true;
    bool  on_ground    = false;
    float friction     = 0.8f;
    float restitution  = 0.1f;
    bool  is_kinematic = false;
};

// ============================================================
// COMPONENT POOL — stores one component type contiguously
// FIX 10: Data-oriented, cache-friendly storage
// ============================================================
template<typename T>
class ComponentPool {
public:
    ComponentPool() {
        m_data.reserve(1024);
        m_entity_to_index.reserve(1024);
        m_index_to_entity.reserve(1024);
    }

    void Add(Entity e, const T& component) {
        if (m_entity_to_index.count(e)) {
            m_data[m_entity_to_index[e]] = component;
            return;
        }
        m_entity_to_index[e] = static_cast<uint32_t>(m_data.size());
        m_index_to_entity.push_back(e);
        m_data.push_back(component);
    }

    void Remove(Entity e) {
        auto it = m_entity_to_index.find(e);
        if (it == m_entity_to_index.end()) return;
        uint32_t idx  = it->second;
        uint32_t last = static_cast<uint32_t>(m_data.size()) - 1;
        // Swap with last to keep dense
        if (idx != last) {
            m_data[idx]          = m_data[last];
            Entity last_entity   = m_index_to_entity[last];
            m_entity_to_index[last_entity] = idx;
            m_index_to_entity[idx]         = last_entity;
        }
        m_data.pop_back();
        m_index_to_entity.pop_back();
        m_entity_to_index.erase(it);
    }

    T* Get(Entity e) {
        auto it = m_entity_to_index.find(e);
        if (it == m_entity_to_index.end()) return nullptr;
        return &m_data[it->second];
    }

    const T* Get(Entity e) const {
        auto it = m_entity_to_index.find(e);
        if (it == m_entity_to_index.end()) return nullptr;
        return &m_data[it->second];
    }

    bool Has(Entity e) const { return m_entity_to_index.count(e) > 0; }

    // Direct array access for cache-friendly iteration
    T*       Data()       { return m_data.data(); }
    const T* Data() const { return m_data.data(); }
    size_t   Size() const { return m_data.size(); }

    Entity EntityAt(size_t index) const { return m_index_to_entity[index]; }

    void ForEach(std::function<void(Entity, T&)> fn) {
        for (size_t i = 0; i < m_data.size(); i++) {
            fn(m_index_to_entity[i], m_data[i]);
        }
    }

private:
    std::vector<T>                   m_data;
    std::map<Entity, uint32_t>       m_entity_to_index;
    std::vector<Entity>              m_index_to_entity;
};

// ============================================================
// ECS WORLD — entity lifecycle + component access
// ============================================================
class ECSWorld {
public:
    static ECSWorld& Get() {
        static ECSWorld instance;
        return instance;
    }

    // Entity management
    Entity   CreateEntity();
    void     DestroyEntity(Entity e);
    bool     IsAlive(Entity e) const;
    uint32_t EntityCount() const;

    // Component management
    template<typename T>
    void AddComponent(Entity e, const T& component) {
        GetPool<T>().Add(e, component);
        uint32_t cid = ComponentID::Get<T>();
        if (cid < MAX_COMPONENTS) m_masks[e].set(cid);
    }

    template<typename T>
    void RemoveComponent(Entity e) {
        GetPool<T>().Remove(e);
        uint32_t cid = ComponentID::Get<T>();
        if (cid < MAX_COMPONENTS) m_masks[e].reset(cid);
    }

    template<typename T>
    T* GetComponent(Entity e) {
        return GetPool<T>().Get(e);
    }

    template<typename T>
    const T* GetComponent(Entity e) const {
        return GetPool<T>().Get(e);
    }

    template<typename T>
    bool HasComponent(Entity e) const {
        return GetPool<T>().Has(e);
    }

    template<typename T>
    ComponentPool<T>& GetPool() {
        uint32_t id = ComponentID::Get<T>();
        auto it = m_pools.find(id);
        if (it == m_pools.end()) {
            m_pools[id] = std::make_shared<ComponentPool<T>>();
        }
        return *static_cast<ComponentPool<T>*>(m_pools[id].get());
    }

    // Query — get all entities with specific components
    template<typename T>
    std::vector<Entity> Query() {
        auto& pool = GetPool<T>();
        std::vector<Entity> result;
        result.reserve(pool.Size());
        pool.ForEach([&](Entity e, T&) { result.push_back(e); });
        return result;
    }

    template<typename T1, typename T2>
    void ForEach(std::function<void(Entity, T1&, T2&)> fn) {
        auto& pool = GetPool<T1>();
        pool.ForEach([&](Entity e, T1& c1) {
            T2* c2 = GetComponent<T2>(e);
            if (c2) fn(e, c1, *c2);
        });
    }

    template<typename T1, typename T2, typename T3>
    void ForEach(std::function<void(Entity, T1&, T2&, T3&)> fn) {
        auto& pool = GetPool<T1>();
        pool.ForEach([&](Entity e, T1& c1) {
            T2* c2 = GetComponent<T2>(e);
            T3* c3 = GetComponent<T3>(e);
            if (c2 && c3) fn(e, c1, *c2, *c3);
        });
    }

    ComponentMask GetMask(Entity e) const;

    // Bulk operations
    void Clear();

private:
    ECSWorld();

    std::vector<Entity>     m_free_list;
    std::vector<EntityVer>  m_versions;
    uint32_t                m_next_entity = 1;

    std::map<uint32_t, std::shared_ptr<void>> m_pools;
    std::array<ComponentMask, MAX_ENTITIES>   m_masks;

    mutable std::mutex m_mutex;
    static const char* MOD;
};

// ============================================================
// ECS SYSTEMS — operate on component data
// Each system is a function — no classes needed
// ============================================================
namespace Systems {

    // Movement system — updates positions from velocities
    void MovementSystem(float delta_time);

    // AI system — ticks AI state machines
    void AISystem(float delta_time);

    // Combat system — handles attack cooldowns
    void CombatSystem(float delta_time);

    // Health system — regen, death detection
    void HealthSystem(float delta_time);

    // Animation system — advances animation timers
    void AnimationStateSystem(float delta_time);

    // Player system — stamina, hunger, thirst
    void PlayerSystem(float delta_time);

    // Physics integration — applies gravity, friction
    void PhysicsSystem(float delta_time);

} // namespace Systems

// ============================================================
// CONVENIENCE MACRO
// ============================================================
#define ECS ECSWorld::Get()

} // namespace TerraEngine
