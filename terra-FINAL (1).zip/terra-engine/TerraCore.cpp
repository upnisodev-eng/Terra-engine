// ============================================================
// TERRA ENGINE — CORE BRAIN IMPLEMENTATION
// TerraCore.cpp — Version 1.0.0
// ============================================================

#include "TerraCore.h"
#include "Agents.h"
#include "TerraAssert.h"
#include "JobSystem.h"
#include "ECS.h"
#include <sstream>
#include <chrono>
#include <algorithm>
#include <cstdlib>
#include <random>

namespace TerraEngine {

const char* TerraCore::MOD = "TerraCore";

// ============================================================
// CONSTRUCTOR / DESTRUCTOR
// ============================================================
TerraCore::TerraCore()
    : m_status(CoreStatus::OFFLINE)
{
    m_stats.start_time = std::chrono::steady_clock::now();
    TLOG_INFO(MOD, "TerraCore created");
}

TerraCore::~TerraCore() {
    if (m_status.load() == CoreStatus::RUNNING) {
        Shutdown();
    }
}

// ============================================================
// INIT
// ============================================================
bool TerraCore::Init(const std::string& env_path) {
    m_status.store(CoreStatus::STARTING);
    TLOG_INFO(MOD, "=== TERRA ENGINE STARTING ===");

    // BUG E FIX: seed rand() once — was never seeded = same sequence every run
    // Use random_device for true entropy, fallback to time if unavailable
    {
        std::random_device rd;
        unsigned int seed = rd.entropy() > 0
            ? rd()
            : static_cast<unsigned int>(
                std::chrono::steady_clock::now().time_since_epoch().count());
        std::srand(seed);
        TLOG_INFO(MOD, "RNG seeded: " + std::to_string(seed));
    }

    // FIX 3.1: Set phase BEFORE creating agents
    // No messages can be sent during agent creation — race condition prevented
    ENGINE_GUARD.SetPhase(EngineInitGuard::Phase::CREATING_AGENTS);

    // Init job system first — agents need it
    JOBS.Init();

    // Create all agents
    if (!CreateAgents()) {
        TLOG_CRITICAL(MOD, "Failed to create agents");
        m_status.store(CoreStatus::OFFLINE);
        return false;
    }

    // Register ALL agents on bus BEFORE any can send messages
    if (!RegisterAgents()) {
        TLOG_CRITICAL(MOD, "Failed to register agents");
        m_status.store(CoreStatus::OFFLINE);
        return false;
    }

    // FIX 3.1: Only NOW allow messages — all agents exist
    ENGINE_GUARD.SetPhase(EngineInitGuard::Phase::AGENTS_READY);

    // Build event routing table
    BuildEventRoutes();

    // Start async bus processing
    m_bus.StartProcessingLoop();

    // Start all agents
    int started = 0;
    for (auto& agent : m_agents) {
        if (agent && agent->Start()) {
            started++;
        } else {
            TLOG_WARN(MOD, "Agent failed to start: "
                         + (agent ? agent->GetName() : "null"));
        }
    }

    if (started == 0) {
        TLOG_CRITICAL(MOD, "No agents started");
        m_status.store(CoreStatus::OFFLINE);
        return false;
    }

    m_status.store(started < static_cast<int>(m_agents.size())
                   ? CoreStatus::DEGRADED
                   : CoreStatus::RUNNING);

    TLOG_INFO(MOD, "=== TERRA ENGINE READY === agents:"
                 + std::to_string(started) + "/"
                 + std::to_string(m_agents.size()));
    return true;
}

// ============================================================
// CREATE AGENTS
// ============================================================
bool TerraCore::CreateAgents() {
    // All 5 merged agents — defined in Agents.h/.cpp
    m_agents.push_back(std::make_unique<AgentWorld>());
    m_agents.push_back(std::make_unique<AgentEnvironment>());
    m_agents.push_back(std::make_unique<AgentNPC>());
    m_agents.push_back(std::make_unique<AgentBoss>());
    m_agents.push_back(std::make_unique<AgentCreature>());
    m_agents.push_back(std::make_unique<AgentPlayerCare>());

    TLOG_INFO(MOD, std::to_string(m_agents.size()) + " agents created");
    return !m_agents.empty();
}

// ============================================================
// REGISTER AGENTS ON BUS
// ============================================================
bool TerraCore::RegisterAgents() {
    for (auto& agent : m_agents) {
        if (!agent) continue;
        m_bus.Register(agent.get());
    }
    TLOG_INFO(MOD, "All agents registered on bus");
    return true;
}

// ============================================================
// BUILD EVENT ROUTES
// Maps event types to which agents should receive them
// ============================================================
void TerraCore::BuildEventRoutes() {
    // World events
    m_event_routes[Events::ISLAND_ENTER]      = {"AgentWorld", "AgentEnvironment", "AgentNPC", "AgentCreature"};
    m_event_routes[Events::ISLAND_GENERATE]   = {"AgentWorld"};
    m_event_routes[Events::CORRUPTION_SPREAD] = {"AgentWorld", "AgentEnvironment", "AgentNPC", "AgentCreature", "AgentBoss"};

    // Weather events
    m_event_routes[Events::STORM_START]       = {"AgentEnvironment", "AgentNPC", "AgentCreature", "AgentBoss"};
    m_event_routes[Events::STORM_END]         = {"AgentEnvironment", "AgentNPC", "AgentCreature"};
    m_event_routes[Events::NIGHT_FALL]        = {"AgentEnvironment", "AgentCreature", "AgentBoss", "AgentNPC"};
    m_event_routes[Events::DAY_BREAK]         = {"AgentEnvironment", "AgentNPC", "AgentCreature"};
    m_event_routes[Events::FLOOD_WARNING]     = {"AgentEnvironment", "AgentNPC", "AgentCreature"};

    // NPC events
    m_event_routes[Events::NPC_HUNGRY]        = {"AgentNPC", "AgentWorld"};
    m_event_routes[Events::NPC_IN_DANGER]     = {"AgentNPC", "AgentCreature", "AgentPlayerCare"};
    m_event_routes[Events::VILLAGE_ATTACK]    = {"AgentNPC", "AgentCreature", "AgentBoss", "AgentPlayerCare"};
    m_event_routes[Events::NPC_JOB_CHANGE]    = {"AgentNPC", "AgentWorld"};

    // Boss events
    m_event_routes[Events::BOSS_AWAKENED]     = {"AgentBoss", "AgentEnvironment", "AgentCreature", "AgentPlayerCare"};
    m_event_routes[Events::BOSS_PHASE_CHANGE] = {"AgentBoss", "AgentEnvironment", "AgentPlayerCare"};
    m_event_routes[Events::BOSS_DEFEATED]     = {"AgentBoss", "AgentNPC", "AgentEnvironment", "AgentWorld"};

    // Combat events
    m_event_routes[Events::COMBAT_START]      = {"AgentCreature", "AgentBoss", "AgentPlayerCare"};
    m_event_routes[Events::COMBAT_END]        = {"AgentCreature", "AgentBoss", "AgentPlayerCare", "AgentNPC"};
    m_event_routes[Events::PLAYER_LOW_HEALTH] = {"AgentPlayerCare", "AgentNPC"};
    m_event_routes[Events::PLAYER_DIED]       = {"AgentPlayerCare", "AgentWorld", "AgentNPC"};

    // Fragment events
    m_event_routes[Events::FRAGMENT_FOUND]    = {"AgentBoss", "AgentWorld", "AgentNPC", "AgentEnvironment"};
    m_event_routes[Events::FRAGMENT_ABSORBED] = {"AgentBoss", "AgentPlayerCare"};

    // Player care events
    m_event_routes[Events::PLAYER_BORED]      = {"AgentPlayerCare", "AgentNPC", "AgentCreature"};
    m_event_routes[Events::PLAYER_OVERWHELMED]= {"AgentPlayerCare"};

    TLOG_INFO(MOD, "Event routes built: "
                 + std::to_string(m_event_routes.size()) + " event types");
}

// ============================================================
// TICK — called every game frame
// ============================================================
void TerraCore::Tick(float delta_time) {
    if (m_status.load() == CoreStatus::OFFLINE ||
        m_status.load() == CoreStatus::SHUTTING_DOWN) return;

    auto t_start = std::chrono::high_resolution_clock::now();

    // Tick all agents
    for (auto& agent : m_agents) {
        if (agent && agent->IsRunning()) {
            agent->Tick(delta_time);
        }
    }

    // Health check — update status
    int healthy = HealthyAgentCount();
    if (healthy == 0) {
        m_status.store(CoreStatus::DEGRADED);
    } else if (healthy < static_cast<int>(m_agents.size())) {
        m_status.store(CoreStatus::DEGRADED);
    } else {
        m_status.store(CoreStatus::RUNNING);
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double tick_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    UpdateStats(tick_ms);
}

// ============================================================
// FIRE EVENT
// ============================================================
void TerraCore::FireEvent(const std::string& event_type,
                           const std::string& data,
                           MessagePriority priority)
{
    auto it = m_event_routes.find(event_type);
    if (it == m_event_routes.end()) {
        // Unknown event — broadcast to all agents
        AgentMessage msg;
        msg.id         = event_type + "_broadcast";
        msg.from_agent = "TerraCore";
        msg.to_agent   = "ALL";
        msg.type       = event_type;
        msg.content    = data;
        msg.priority   = priority;
        m_bus.Broadcast(msg, "TerraCore");
    } else {
        // Route to specific agents
        for (const std::string& agent_name : it->second) {
            AgentMessage msg;
            msg.id         = event_type + "_" + agent_name;
            msg.from_agent = "TerraCore";
            msg.to_agent   = agent_name;
            msg.type       = event_type;
            msg.content    = data;
            msg.priority   = priority;
            m_bus.Route(msg);
        }
    }

    // Fire C++ callbacks
    FireCallbacks(event_type, data);

    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.events_fired++;
}

// ============================================================
// WORLD STATE SETTERS
// ============================================================
void TerraCore::SetWorldState(const WorldState& state) {
    m_world_state = state;
    m_bus.PropagateWorldState(state);
}

void TerraCore::SetIsland(int island_id) {
    m_world_state.current_island = island_id;
    m_bus.PropagateWorldState(m_world_state);
    FireEvent(Events::ISLAND_ENTER, std::to_string(island_id), MessagePriority::HIGH);
}

void TerraCore::SetTimeOfDay(const std::string& time) {
    m_world_state.time_of_day = time;
    m_bus.PropagateWorldState(m_world_state);
    if (time == "night")   FireEvent(Events::NIGHT_FALL, "", MessagePriority::NORMAL);
    if (time == "morning") FireEvent(Events::DAY_BREAK,  "", MessagePriority::NORMAL);
}

void TerraCore::SetWeather(const std::string& weather) {
    std::string prev = m_world_state.weather;
    m_world_state.weather = weather;
    m_bus.PropagateWorldState(m_world_state);
    if (weather == "storm" && prev != "storm")
        FireEvent(Events::STORM_START, weather, MessagePriority::HIGH);
    else if (prev == "storm" && weather != "storm")
        FireEvent(Events::STORM_END, weather, MessagePriority::NORMAL);
}

void TerraCore::SetCorruption(float level) {
    float prev = m_world_state.corruption_level;
    m_world_state.corruption_level = level;
    m_bus.PropagateWorldState(m_world_state);
    if (level > prev + 0.05f)
        FireEvent(Events::CORRUPTION_SPREAD, std::to_string(level), MessagePriority::HIGH);
}

void TerraCore::SetPlayerHealth(int health) {
    int prev = m_world_state.player_health;
    m_world_state.player_health = health;
    m_bus.PropagateWorldState(m_world_state);
    if (health <= 20 && prev > 20)
        FireEvent(Events::PLAYER_LOW_HEALTH, std::to_string(health), MessagePriority::CRITICAL);
    if (health <= 0 && prev > 0)
        FireEvent(Events::PLAYER_DIED, "", MessagePriority::CRITICAL);
}

void TerraCore::SetBossActive(bool active) {
    m_world_state.boss_active = active;
    m_bus.PropagateWorldState(m_world_state);
    if (active)
        FireEvent(Events::BOSS_AWAKENED, "", MessagePriority::CRITICAL);
}

void TerraCore::SetPlayerInCombat(bool in_combat) {
    bool prev = m_world_state.player_in_combat;
    m_world_state.player_in_combat = in_combat;
    m_bus.PropagateWorldState(m_world_state);
    if (in_combat && !prev)
        FireEvent(Events::COMBAT_START, "", MessagePriority::HIGH);
    else if (!in_combat && prev)
        FireEvent(Events::COMBAT_END,   "", MessagePriority::NORMAL);
}

// ============================================================
// SHUTDOWN
// ============================================================
void TerraCore::Shutdown() {
    m_status.store(CoreStatus::SHUTTING_DOWN);
    TLOG_INFO(MOD, "Shutting down...");

    m_bus.StopProcessingLoop();

    for (auto& agent : m_agents) {
        if (agent) agent->Stop();
    }

    m_agents.clear();
    m_status.store(CoreStatus::OFFLINE);
    TLOG_INFO(MOD, "=== TERRA ENGINE OFFLINE ===");
}

// ============================================================
// AGENT ACCESS
// ============================================================
AgentBase* TerraCore::GetAgent(const std::string& name) const {
    return m_bus.GetAgent(name);
}

int TerraCore::HealthyAgentCount() const {
    int count = 0;
    for (const auto& agent : m_agents) {
        if (agent && agent->IsHealthy()) count++;
    }
    return count;
}

// ============================================================
// EVENT CALLBACKS
// ============================================================
void TerraCore::OnEvent(const std::string& event_type,
                         EventCallback callback)
{
    std::lock_guard<std::mutex> lock(m_callback_mutex);
    m_callbacks[event_type] = std::move(callback);
}

void TerraCore::RemoveCallback(const std::string& event_type) {
    std::lock_guard<std::mutex> lock(m_callback_mutex);
    m_callbacks.erase(event_type);
}

void TerraCore::FireCallbacks(const std::string& type,
                               const std::string& data)
{
    std::lock_guard<std::mutex> lock(m_callback_mutex);
    auto it = m_callbacks.find(type);
    if (it != m_callbacks.end() && it->second) {
        try {
            it->second(type, data);
        } catch (const std::exception& e) {
            TLOG_ERR(MOD, "Callback threw: " + std::string(e.what()));
        }
    }
}

// ============================================================
// STATUS
// ============================================================
std::string TerraCore::StatusString() const {
    switch (m_status.load()) {
        case CoreStatus::OFFLINE:       return "OFFLINE";
        case CoreStatus::STARTING:      return "STARTING";
        case CoreStatus::RUNNING:       return "RUNNING";
        case CoreStatus::DEGRADED:      return "DEGRADED";
        case CoreStatus::SHUTTING_DOWN: return "SHUTTING_DOWN";
        default:                        return "UNKNOWN";
    }
}

void TerraCore::PrintStatus() const {
    TLOG_INFO(MOD, "=== TerraCore Status ===");
    TLOG_INFO(MOD, "Status: " + StatusString());
    TLOG_INFO(MOD, "Healthy agents: "
                 + std::to_string(HealthyAgentCount())
                 + "/" + std::to_string(m_agents.size()));
    m_bus.PrintRegisteredAgents();
    m_bus.PrintStats();
}

// ============================================================
// STATS
// ============================================================
void TerraCore::UpdateStats(double tick_ms) {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.ticks_processed++;
    double delta = tick_ms - m_stats.avg_tick_ms;
    m_stats.avg_tick_ms += delta / static_cast<double>(m_stats.ticks_processed);
}

TerraCore::Stats TerraCore::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}

void TerraCore::PrintStats() const {
    Stats s = GetStats();
    TLOG_INFO(MOD, "--- TerraCore Stats ---");
    TLOG_INFO(MOD, "Events fired:   " + std::to_string(s.events_fired));
    TLOG_INFO(MOD, "Ticks:          " + std::to_string(s.ticks_processed));
    TLOG_INFO(MOD, "Avg tick:       "
                 + std::to_string(static_cast<int>(s.avg_tick_ms)) + "ms");
}

} // namespace TerraEngine
