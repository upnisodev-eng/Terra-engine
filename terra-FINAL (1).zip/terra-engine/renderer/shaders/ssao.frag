// ============================================================
// TERRA ENGINE — SSAO SHADER
// ssao.frag
// ============================================================
// Screen Space Ambient Occlusion.
// Samples: 8 (MEDIUM) | 16 (HIGH) | 32 (ULTRA)
// Runs at half resolution — bilateral blur in blur pass.
// Output: R8_UNORM occlusion factor (1=lit, 0=occluded)
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;
layout(location = 0) out float out_occlusion;

layout(set = 0, binding = 0) uniform sampler2D gbuf_depth;
layout(set = 0, binding = 1) uniform sampler2D gbuf_normals;
layout(set = 0, binding = 2) uniform sampler2D noise_tex;    // 4x4 random rotation

layout(set = 1, binding = 0) uniform SSAOData {
    mat4  projection;
    mat4  inv_projection;
    vec4  samples[32];         // precomputed hemisphere samples
    float radius;
    float bias;
    float power;
    int   sample_count;        // 8 / 16 / 32
    vec2  noise_scale;         // screen_size / 4.0
} ssao;

// ============================================================
// RECONSTRUCT VIEW-SPACE POSITION FROM DEPTH
// ============================================================
vec3 ReconstructViewPos(vec2 uv, float depth) {
    vec4 clip  = vec4(uv * 2.0 - 1.0, depth, 1.0);
    vec4 view  = ssao.inv_projection * clip;
    return view.xyz / view.w;
}

// ============================================================
// MAIN
// ============================================================
void main() {
    float depth     = texture(gbuf_depth, in_uv).r;
    if (depth >= 0.9999) { out_occlusion = 1.0; return; } // sky = no occlusion

    vec3  frag_pos  = ReconstructViewPos(in_uv, depth);
    vec3  normal    = normalize(texture(gbuf_normals, in_uv).rgb * 2.0 - 1.0);

    // Random rotation from tiled noise texture — breaks banding
    vec3  random    = normalize(texture(noise_tex, in_uv * ssao.noise_scale).xyz);

    // Gram-Schmidt TBN — orient hemisphere to surface normal
    vec3  tangent   = normalize(random - normal * dot(random, normal));
    vec3  bitangent = cross(normal, tangent);
    mat3  TBN       = mat3(tangent, bitangent, normal);

    float occlusion = 0.0;

    for (int i = 0; i < ssao.sample_count; i++) {
        // Transform sample to view space
        vec3 sample_pos = TBN * ssao.samples[i].xyz;
        sample_pos      = frag_pos + sample_pos * ssao.radius;

        // Project to screen UV
        vec4 offset = ssao.projection * vec4(sample_pos, 1.0);
        offset.xyz /= offset.w;
        vec2 s_uv   = offset.xy * 0.5 + 0.5;

        // Check if sample is occluded
        float sample_depth = texture(gbuf_depth, s_uv).r;
        vec3  sample_view  = ReconstructViewPos(s_uv, sample_depth);

        // Range check — avoid occlusion from far geometry
        float range_check  = smoothstep(0.0, 1.0,
            ssao.radius / abs(frag_pos.z - sample_view.z));

        // Occlusion test with surface bias to avoid acne
        occlusion += (sample_view.z >= sample_pos.z + ssao.bias ? 1.0 : 0.0)
                   * range_check;
    }

    occlusion    = occlusion / float(ssao.sample_count);
    out_occlusion = pow(1.0 - occlusion, ssao.power);
}
