// ============================================================
// TERRA ENGINE — POST PROCESS SHADER
// postprocess.frag
// ============================================================
// All post-process in single full-screen pass.
// MEDIUM:  Tone mapping + TAA resolve + vignette
// HIGH:    + Depth of field (bokeh)
// ULTRA:   + Motion blur + Chromatic aberration
//
// Corruption: desaturate + purple shift + noise
// Night:      cool tones + contrast boost
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;
layout(location = 0) out vec4 out_ldr;

// ── Inputs ──────────────────────────────────────────────────
layout(set = 0, binding = 0) uniform sampler2D hdr_input;       // lit HDR scene
layout(set = 0, binding = 1) uniform sampler2D bloom_texture;   // blurred bright areas
layout(set = 0, binding = 2) uniform sampler2D depth_buffer;
layout(set = 0, binding = 3) uniform sampler2D velocity_buffer; // for motion blur
layout(set = 0, binding = 4) uniform sampler2D cloud_texture;   // composited clouds
layout(set = 0, binding = 5) uniform sampler2D ssr_texture;

layout(set = 1, binding = 0) uniform PostData {
    // Bloom
    float bloom_intensity;
    float bloom_threshold;

    // Tone mapping
    float exposure;
    float gamma;
    float saturation;
    float contrast;

    // Depth of field (HIGH+)
    float dof_focus_distance;
    float dof_focus_range;
    float dof_bokeh_radius;
    int   dof_enabled;

    // Motion blur (ULTRA)
    float motion_blur_strength;
    int   motion_blur_samples;
    int   motion_blur_enabled;

    // Chromatic aberration (ULTRA)
    float chroma_strength;
    int   chroma_enabled;

    // World state
    float corruption;
    float is_night;
    float time;

    // Vignette
    float vignette_strength;

    // Resolution
    vec2  resolution;
} data;

// ============================================================
// TONE MAPPING
// ============================================================

// ACES Filmic — industry standard, used in Unreal/UE4
vec3 ACESFilmic(vec3 x) {
    float a = 2.51f;
    float b = 0.03f;
    float c = 2.43f;
    float d = 0.59f;
    float e = 0.14f;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Reinhard extended — preserves highlights better
vec3 ReinhardExtended(vec3 x, float max_white) {
    vec3 num = x * (1.0 + x / (max_white * max_white));
    return num / (1.0 + x);
}

// ============================================================
// DEPTH OF FIELD — Bokeh blur (HIGH+)
// ============================================================
vec3 DepthOfField(vec2 uv, float depth) {
    // Calculate circle of confusion
    float scene_depth = depth * (data.dof_focus_distance + data.dof_focus_range * 10.0);
    float coc = abs(scene_depth - data.dof_focus_distance) / data.dof_focus_range;
    coc = clamp(coc * data.dof_bokeh_radius, 0.0, data.dof_bokeh_radius);

    if (coc < 0.5) return texture(hdr_input, uv).rgb;

    // Hexagonal bokeh kernel — 37 samples on 3 rings
    vec3  accum  = vec3(0.0);
    float weight = 0.0;
    vec2  texel  = 1.0 / data.resolution;

    // Ring samples
    const int RINGS = 3;
    for (int r = 1; r <= RINGS; r++) {
        int   samples = r * 6;
        float radius  = float(r) / float(RINGS) * coc;
        for (int s = 0; s < samples; s++) {
            float angle  = float(s) / float(samples) * 6.28318;
            vec2  offset = vec2(cos(angle), sin(angle)) * radius * texel;
            float d      = texture(depth_buffer, uv + offset).r;
            float w      = 1.0; // could weight by depth
            accum       += texture(hdr_input, uv + offset).rgb * w;
            weight      += w;
        }
    }

    return accum / weight;
}

// ============================================================
// MOTION BLUR (ULTRA)
// ============================================================
vec3 MotionBlur(vec2 uv) {
    vec2 velocity = texture(velocity_buffer, uv).rg;
    velocity     *= data.motion_blur_strength;

    if (length(velocity) < 0.0001) return texture(hdr_input, uv).rgb;

    vec3  accum = vec3(0.0);
    float total = 0.0;
    int   steps = data.motion_blur_samples;

    for (int i = 0; i < steps; i++) {
        float t    = (float(i) / float(steps - 1)) - 0.5;
        vec2  s_uv = clamp(uv + velocity * t, vec2(0.001), vec2(0.999));
        accum     += texture(hdr_input, s_uv).rgb;
        total     += 1.0;
    }

    return accum / total;
}

// ============================================================
// CHROMATIC ABERRATION (ULTRA)
// ============================================================
vec3 ChromaticAberration(vec2 uv) {
    vec2  dir    = (uv - 0.5) * data.chroma_strength;
    float r      = texture(hdr_input, uv + dir * 1.0).r;
    float g      = texture(hdr_input, uv + dir * 0.5).g;
    float b      = texture(hdr_input, uv - dir * 0.5).b;
    return vec3(r, g, b);
}

// ============================================================
// CORRUPTION COLOUR GRADE
// ============================================================
vec3 CorruptionGrade(vec3 colour, float corruption) {
    if (corruption < 0.01) return colour;

    // Desaturate
    float lum         = dot(colour, vec3(0.299, 0.587, 0.114));
    vec3  desaturated = vec3(lum);
    colour            = mix(colour, desaturated, corruption * 0.7);

    // Purple tint
    colour = mix(colour, vec3(lum * 0.5, lum * 0.1, lum * 0.9), corruption * 0.4);

    // Noise flicker at high corruption
    if (corruption > 0.7) {
        float flicker = fract(sin(dot(in_uv * data.time, vec2(127.1, 311.7))) * 43758.5);
        float noise   = (corruption - 0.7) / 0.3;
        colour       += vec3(flicker * 0.05 * noise);
    }

    return colour;
}

// ============================================================
// NIGHT COLOUR GRADE
// ============================================================
vec3 NightGrade(vec3 colour, float is_night) {
    if (is_night < 0.01) return colour;

    // Cool blue shift
    colour = mix(colour, colour * vec3(0.7, 0.8, 1.2), is_night * 0.4);

    // Slight desaturation at night
    float lum = dot(colour, vec3(0.299, 0.587, 0.114));
    colour    = mix(colour, vec3(lum), is_night * 0.2);

    // Contrast boost
    colour = mix(vec3(0.5), colour, 1.0 + is_night * 0.2);

    return colour;
}

// ============================================================
// VIGNETTE
// ============================================================
float Vignette(vec2 uv) {
    vec2  d  = uv - 0.5;
    float r  = dot(d, d);
    return 1.0 - r * data.vignette_strength * 4.0;
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec2  uv    = in_uv;
    float depth = texture(depth_buffer, uv).r;

    // ── Sample HDR scene ────────────────────────────────────
    vec3 colour;

    if (data.chroma_enabled == 1) {
        colour = ChromaticAberration(uv);         // ULTRA
    } else if (data.motion_blur_enabled == 1) {
        colour = MotionBlur(uv);                  // ULTRA
    } else if (data.dof_enabled == 1) {
        colour = DepthOfField(uv, depth);         // HIGH
    } else {
        colour = texture(hdr_input, uv).rgb;      // MEDIUM
    }

    // ── Composite clouds (ULTRA) ────────────────────────────
    vec4 cloud = texture(cloud_texture, uv);
    colour     = colour * cloud.a + cloud.rgb;

    // ── SSR blend (HIGH+) ───────────────────────────────────
    vec4 ssr_col = texture(ssr_texture, uv);
    colour      += ssr_col.rgb * ssr_col.a;

    // ── Bloom ───────────────────────────────────────────────
    vec3 bloom = texture(bloom_texture, uv).rgb;
    colour    += bloom * data.bloom_intensity;

    // ── Exposure ────────────────────────────────────────────
    colour *= data.exposure;

    // ── Tone mapping (ACES Filmic) ──────────────────────────
    colour = ACESFilmic(colour);

    // ── Colour grading ──────────────────────────────────────
    colour = CorruptionGrade(colour, data.corruption);
    colour = NightGrade     (colour, data.is_night);

    // Saturation
    float lum  = dot(colour, vec3(0.299, 0.587, 0.114));
    colour     = mix(vec3(lum), colour, data.saturation);

    // Contrast
    colour     = mix(vec3(0.5), colour, data.contrast);

    // ── Vignette ────────────────────────────────────────────
    colour    *= Vignette(uv);

    // ── Gamma correction ────────────────────────────────────
    colour     = pow(clamp(colour, 0.0, 1.0), vec3(1.0 / data.gamma));

    out_ldr    = vec4(colour, 1.0);
}
