// ============================================================
// TERRA ENGINE — PHYSICS WORLD
// PhysicsWorld.h — Version 1.0.0
// ============================================================
// Wraps Jolt Physics (MIT license, single-header optional).
// Provides: rigid bodies, character controller,
//           ray casts, shape casts, triggers.
// Each island has its own physics world instance.
// ============================================================

#pragma once
#include "AIConnector.h"
#include "ECS.h"
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <mutex>
#include <memory>

namespace TerraEngine {

// ============================================================
// COLLISION LAYERS — what collides with what
// ============================================================
enum class PhysicsLayer : uint8_t {
    STATIC       = 0,  // terrain, buildings — never moves
    DYNAMIC      = 1,  // enemies, NPCs, objects
    PLAYER       = 2,  // player character
    TRIGGER      = 3,  // zones, pickups — no physics response
    PROJECTILE   = 4,  // arrows, magic bolts
    WATER        = 5,  // water volumes
    COUNT        = 6,
    // NEW-6 FIX: Dedicated ALL sentinel for "hit any layer" raycasts.
    // Previously PhysicsLayer::STATIC was (mis)used as a wildcard — meaning
    // you could never intentionally raycast only static geometry, and the
    // wildcard behaviour was invisible and undocumented.
    ALL          = 255
};

// ============================================================
// COLLISION SHAPE TYPES
// ============================================================
enum class ShapeType { BOX, SPHERE, CAPSULE, MESH, CONVEX_HULL };

// ============================================================
// PHYSICS BODY DESC — create a rigid body from this
// ============================================================
struct PhysicsBodyDesc {
    ShapeType   shape         = ShapeType::CAPSULE;
    float       half_x        = 0.5f;  // box half extents / capsule radius
    float       half_y        = 0.9f;  // box half / capsule half-height
    float       half_z        = 0.5f;
    float       mass          = 70.0f; // kg (0 = static/kinematic)
    float       restitution   = 0.1f;
    float       friction      = 0.6f;
    float       linear_damping = 0.5f;
    float       angular_damping= 0.8f;
    PhysicsLayer layer        = PhysicsLayer::DYNAMIC;
    bool        is_trigger    = false;
    bool        is_kinematic  = false;  // moved by code not physics
    bool        lock_rotation = false;  // prevent tipping (NPCs/player)
    Entity      entity        = 0;      // ECS entity this body belongs to
};

// ============================================================
// RAYCAST RESULT
// ============================================================
struct RaycastHit {
    bool        hit          = false;
    float       distance     = 0.0f;
    float       point[3]     = {};
    float       normal[3]    = {};
    Entity      entity       = 0;
    PhysicsLayer layer;
};

// ============================================================
// CONTACT EVENT — collision callback data
// ============================================================
struct ContactEvent {
    Entity      body_a;
    Entity      body_b;
    float       contact_point[3];
    float       contact_normal[3];
    float       impulse;
    bool        is_trigger;
};

// ============================================================
// PHYSICS WORLD
// ============================================================
class PhysicsWorld {
public:
    static PhysicsWorld& Get() {
        static PhysicsWorld instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init / Shutdown
    // --------------------------------------------------------
    bool Init(float gravity_y = -9.81f);
    void Shutdown();

    // --------------------------------------------------------
    // Step — call every physics tick (60Hz via DeterministicSim)
    // --------------------------------------------------------
    void Step(float delta_time);

    // --------------------------------------------------------
    // Body management
    // --------------------------------------------------------
    uint32_t CreateBody    (const PhysicsBodyDesc& desc,
                            float pos_x, float pos_y, float pos_z);
    void     DestroyBody   (uint32_t body_id);
    bool     IsBodyAlive   (uint32_t body_id) const;

    // Position / velocity setters
    void SetPosition  (uint32_t id, float x, float y, float z);
    void SetVelocity  (uint32_t id, float vx, float vy, float vz);
    void AddImpulse   (uint32_t id, float x,  float y,  float z);
    void AddForce     (uint32_t id, float x,  float y,  float z);

    // Position / velocity getters
    void GetPosition  (uint32_t id, float& x,  float& y,  float& z) const;
    void GetVelocity  (uint32_t id, float& vx, float& vy, float& vz) const;
    bool IsOnGround   (uint32_t id) const;

    // --------------------------------------------------------
    // Character controller — special body for player/NPCs
    // Handles: step-up over small obstacles, slope limit
    // --------------------------------------------------------
    uint32_t CreateCharacterController(
        float radius, float height,
        float pos_x, float pos_y, float pos_z,
        Entity entity,
        PhysicsLayer layer = PhysicsLayer::PLAYER
    );

    void MoveCharacter(uint32_t id,
                       float move_x, float move_z,
                       float jump_velocity = 0.0f,
                       float delta_time    = 0.016f);

    // --------------------------------------------------------
    // Queries
    // --------------------------------------------------------
    RaycastHit Raycast(float ox, float oy, float oz,
                       float dx, float dy, float dz,
                       float max_dist     = 1000.0f,
                       PhysicsLayer mask  = PhysicsLayer::ALL) const;   // NEW-6 FIX: was STATIC (wrong wildcard)

    std::vector<Entity> OverlapSphere(float x, float y, float z,
                                       float radius,
                                       PhysicsLayer mask = PhysicsLayer::DYNAMIC) const;

    // --------------------------------------------------------
    // Callbacks
    // --------------------------------------------------------
    using ContactCB = std::function<void(const ContactEvent&)>;
    void OnContact(ContactCB cb) { m_contact_cb = cb; }

    // Trigger zone entered/exited
    using TriggerCB = std::function<void(Entity trigger, Entity other, bool entered)>;
    void OnTrigger(TriggerCB cb) { m_trigger_cb = cb; }

    // --------------------------------------------------------
    // Layer collision matrix — which layers collide
    // --------------------------------------------------------
    void SetLayerCollision(PhysicsLayer a, PhysicsLayer b, bool collides);

    // --------------------------------------------------------
    // Debug draw (renders physics shapes in debug mode)
    // --------------------------------------------------------
    void DebugDraw() const;

    // --------------------------------------------------------
    // Terrain mesh — load from chunk heightmap
    // --------------------------------------------------------
    uint32_t CreateTerrainBody(const float* heightmap,
                               int size_x, int size_z,
                               float cell_size,
                               float height_scale,
                               float pos_x, float pos_z);

private:
    PhysicsWorld() : m_initialized(false), m_gravity_y(-9.81f) {}

    bool m_initialized;
    float m_gravity_y;

    // Body registry — maps engine body ID to Jolt body ID
    struct BodyEntry {
        uint32_t   jolt_id    = 0;
        Entity     entity     = 0;
        PhysicsLayer layer    = PhysicsLayer::DYNAMIC;
        bool       is_character = false;
        bool       is_trigger   = false;
        bool       on_ground    = false;
    };

    mutable std::mutex               m_mutex;
    std::map<uint32_t, BodyEntry>    m_bodies;
    uint32_t                         m_next_id = 1;

    ContactCB m_contact_cb;
    TriggerCB m_trigger_cb;

    // Layer collision table
    bool m_layer_table[static_cast<int>(PhysicsLayer::COUNT)]
                      [static_cast<int>(PhysicsLayer::COUNT)];

    void InitDefaultLayerMatrix();
    void SyncECSTransforms();  // writes physics positions back to ECS TransformComponent

    static const char* MOD;
};

} // namespace TerraEngine
