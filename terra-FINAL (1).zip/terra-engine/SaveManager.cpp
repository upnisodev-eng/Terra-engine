// ============================================================
// TERRA ENGINE — SAVE MANAGER IMPLEMENTATION
// SaveManager.cpp — Version 1.0.0
// ============================================================

#include "SaveManager.h"
#include "JobSystem.h"
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <sstream>
#include <fstream>
#include <chrono>
#include <algorithm>
#include <set>
#include <cstdio>   // BUG 2 FIX: std::remove(const char*) for file deletion
                    // Without this, <algorithm>'s std::remove shadows it → compile error

using json = nlohmann::json;
using namespace TerraEngine;

const char* SaveManager::MOD = "SaveManager";

// ============================================================
// CURL HELPER
// ============================================================
static size_t WriteCallback(void* c, size_t s, size_t n, std::string* o) {
    o->append(static_cast<char*>(c), s * n);
    return s * n;
}

// ============================================================
// CONSTRUCTOR
// ============================================================
SaveManager::SaveManager()
    : m_online(false)
{
    TLOG_INFO(MOD, "SaveManager created");
}

// ============================================================
// INIT
// ============================================================
bool SaveManager::Init(const std::string& api_base,
                        const std::string& supabase_url,
                        const std::string& supabase_key)
{
    m_api_base      = api_base;
    m_supabase_url  = supabase_url;
    m_supabase_key  = supabase_key;

    // Try to restore saved session
    if (LoadTokenLocally()) {
        m_account.is_logged_in = true;
        TLOG_INFO(MOD, "Session restored from local token");
    }

    // Check if online
    CheckOnlineStatus();

    // Register auto-save tick with SimulationManager
    SIMSYS.RegisterSystem("SaveManager::Tick",
        [this](float dt) { this->Tick(dt); },
        0.0f,   // every frame — internal timer manages interval
        9       // low priority
    );

    TLOG_INFO(MOD, "Init complete — online: "
                 + std::string(m_online.load() ? "yes" : "no"));
    return true;
}

// ============================================================
// AUTH — LOGIN
// ============================================================
bool SaveManager::Login(const std::string& username,
                         const std::string& password)
{
    json body = {{"username", username}, {"password", password}};
    std::string resp = HttpPost("/auth/login", body.dump(), false);

    if (resp.empty()) {
        TLOG_ERR(MOD, "Login failed — no response");
        return false;
    }

    try {
        json r = json::parse(resp);
        if (!r.contains("token")) {
            TLOG_ERR(MOD, "Login failed: " + resp.substr(0, 100));
            return false;
        }

        m_account.jwt_token    = r["token"];
        m_account.player_id    = r.value("player_id", "");
        m_account.username     = username;
        m_account.is_logged_in = true;
        m_account.is_guest     = false;

        SaveTokenLocally(m_account.jwt_token);
        TLOG_INFO(MOD, "Logged in: " + username);
        return true;

    } catch (const std::exception& e) {
        TLOG_ERR(MOD, "Login parse error: " + std::string(e.what()));
        return false;
    }
}

// ============================================================
// AUTH — REGISTER
// ============================================================
bool SaveManager::Register(const std::string& username,
                             const std::string& email,
                             const std::string& password)
{
    json body = {
        {"username", username},
        {"email",    email},
        {"password", password}
    };
    std::string resp = HttpPost("/auth/register", body.dump(), false);

    if (resp.empty()) return false;

    try {
        json r = json::parse(resp);
        if (r.value("status", "") == "created") {
            TLOG_INFO(MOD, "Registered: " + username);
            return Login(username, password);
        }
        TLOG_ERR(MOD, "Register failed: " + resp.substr(0, 100));
        return false;
    } catch (const std::exception& e) {
        TLOG_ERR(MOD, "Register parse error: " + std::string(e.what()));
        return false;
    }
}

// ============================================================
// AUTH — GUEST
// ============================================================
void SaveManager::LoginAsGuest(const std::string& guest_name) {
    m_account.is_logged_in = false;
    m_account.is_guest     = true;
    m_account.username     = guest_name.empty() ? "Guest" : guest_name;
    m_account.player_id    = "guest_local";
    TLOG_INFO(MOD, "Logged in as guest");
}

// ============================================================
// AUTH — LOGOUT
// ============================================================
void SaveManager::Logout() {
    m_account = PlayerAccount{};
    // Delete local token
    std::remove(m_local_token_path.c_str());
    TLOG_INFO(MOD, "Logged out");
}

// ============================================================
// SAVE — FULL
// ============================================================
SaveResult SaveManager::Save(const GameSaveData& data) {
    SaveResult result;

    // Always save locally first — instant
    SaveLocal(data);

    // If not logged in or offline — queue sync
    if (!m_account.is_logged_in || !m_online.load()) {
        EnqueueSync(SyncType::FULL_SAVE, SerializeSave(data));
        result.success      = true;
        result.was_offline  = true;
        TLOG_INFO(MOD, "Saved locally — queued for cloud sync");
        return result;
    }

    // Online + logged in — sync to cloud async
    auto data_copy = data;
    JOBS.Submit([this, data_copy]() {
        auto t_start = std::chrono::high_resolution_clock::now();
        std::string body = SerializeSave(data_copy);
        std::string resp = HttpPost("/save/push", body);

        auto t_end = std::chrono::high_resolution_clock::now();
        double ms  = std::chrono::duration<double, std::milli>(
                         t_end - t_start).count();

        SaveResult r;
        r.success = !resp.empty();
        r.was_offline = false;

        if (!r.success) {
            // Cloud failed — queue it
            EnqueueSync(SyncType::FULL_SAVE, body);
            TLOG_WARN(MOD, "Cloud save failed — queued");
        } else {
            TLOG_INFO(MOD, "Cloud save OK " + std::to_string(static_cast<int>(ms)) + "ms");
        }

        UpdateStats(r.success, ms);
        if (m_on_save) m_on_save(r);

        // Broadcast save event
        ChannelMessage msg("save_completed",
                           r.success ? "cloud" : "local",
                           "SaveManager");
        ROUTER.Post(Channel::WORLD_STATE, msg);

    }, "SaveManager::Save", JobPriority::LOW);

    result.success = true;
    return result;
}

// ============================================================
// QUICK SAVE
// ============================================================
SaveResult SaveManager::QuickSave(int island, int level,
                                    float xp, int fragments)
{
    if (!m_live_data) {
        SaveResult r; r.success = false;
        r.error = "No live data pointer set"; return r;
    }

    m_live_data->current_island  = island;
    m_live_data->player_level    = level;
    m_live_data->player_xp       = xp;
    m_live_data->fragments_found = fragments;

    return Save(*m_live_data);
}

// ============================================================
// LOAD
// ============================================================
bool SaveManager::Load(GameSaveData& out) {
    // If online and logged in — pull from cloud
    if (m_account.is_logged_in && m_online.load()) {
        if (PullFromCloud(out)) return true;
        TLOG_WARN(MOD, "Cloud pull failed — loading local cache");
    }
    // Fallback to local
    return LoadLocal(out);
}

// ============================================================
// PULL FROM CLOUD
// ============================================================
bool SaveManager::PullFromCloud(GameSaveData& out) {
    if (!m_account.is_logged_in) return false;

    std::string resp = HttpGet("/save/pull");
    if (resp.empty()) return false;

    try {
        json r = json::parse(resp);
        if (!r.contains("save") || r["save"].is_null()) {
            TLOG_INFO(MOD, "No cloud save found for player");
            return false;
        }
        bool ok = DeserializeSave(r["save"].dump(), out);

        // Parse inventory
        if (r.contains("inventory") && r["inventory"].is_array()) {
            out.inventory.clear();
            for (const auto& item : r["inventory"]) {
                InventoryItem i;
                i.item_id     = item.value("item_id", "");
                i.quantity    = item.value("quantity", 1);
                i.slot        = item.value("slot", -1);
                i.is_equipped = item.value("is_equipped", false);
                i.metadata    = item.value("metadata", "");
                out.inventory.push_back(i);
            }
        }

        // Parse cosmetics
        if (r.contains("cosmetics") && r["cosmetics"].is_array()) {
            out.cosmetics.clear();
            for (const auto& c : r["cosmetics"]) {
                CosmeticItem ci;
                ci.cosmetic_id  = c.value("cosmetic_id", "");
                ci.is_equipped  = c.value("is_equipped", false);
                out.cosmetics.push_back(ci);
            }
        }

        // Coins
        out.terra_coins = r.value("coins", 0);

        // Cache locally after successful pull
        SaveLocal(out);
        TLOG_INFO(MOD, "Pulled from cloud — island:"
                     + std::to_string(out.current_island)
                     + " level:" + std::to_string(out.player_level));
        return ok;

    } catch (const std::exception& e) {
        TLOG_ERR(MOD, "Pull parse error: " + std::string(e.what()));
        return false;
    }
}

// ============================================================
// GRANULAR SYNC METHODS
// ============================================================
void SaveManager::SyncItemAdd(const std::string& item_id,
                               int qty,
                               const std::string& metadata)
{
    json body = {
        {"item_id",  item_id},
        {"quantity", qty},
        {"metadata", metadata}
    };
    EnqueueSync(SyncType::ITEM_ADD, body.dump());
    if (m_online.load() && m_account.is_logged_in) FlushQueue();
}

void SaveManager::SyncItemRemove(const std::string& item_id, int qty) {
    json body = {{"item_id", item_id}, {"quantity", qty}};
    EnqueueSync(SyncType::ITEM_REMOVE, body.dump());
    if (m_online.load() && m_account.is_logged_in) FlushQueue();
}

void SaveManager::SyncItemEquip(const std::string& item_id, bool equipped) {
    json body = {{"item_id", item_id}, {"equipped", equipped}};
    EnqueueSync(SyncType::ITEM_EQUIP, body.dump());
}

void SaveManager::SyncCosmeticEquip(const std::string& cosmetic_id) {
    json body = {{"cosmetic_id", cosmetic_id}};
    EnqueueSync(SyncType::COSMETIC_EQUIP, body.dump());
    // Cosmetics sync immediately — visible to other players
    if (m_online.load() && m_account.is_logged_in) FlushQueue();
}

void SaveManager::SyncCoinsUpdate(int new_balance) {
    json body = {{"coins", new_balance}};
    EnqueueSync(SyncType::COINS_UPDATE, body.dump());
    // Coins sync immediately — prevent duplication exploit
    if (m_online.load() && m_account.is_logged_in) FlushQueue();
}

void SaveManager::SyncWorldChange(const WorldChange& change) {
    json body = {
        {"change_type", change.change_type},
        {"island_id",   change.island_id},
        {"data",        change.data},
        {"timestamp",   change.timestamp}
    };
    EnqueueSync(SyncType::WORLD_CHANGE, body.dump());
}

void SaveManager::SyncMilestone(const std::string& event_type,
                                  const std::string& data)
{
    json body = {{"event", event_type}, {"data", data}};
    EnqueueSync(SyncType::MILESTONE, body.dump());
    // Milestones sync immediately — boss defeats, islands reached
    if (m_online.load() && m_account.is_logged_in) FlushQueue();
}

// ============================================================
// OFFLINE QUEUE
// ============================================================
void SaveManager::EnqueueSync(SyncType type, const std::string& payload) {
    auto now = std::chrono::steady_clock::now();
    SyncEvent event;
    event.type      = type;
    event.payload   = payload;
    event.timestamp = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            now.time_since_epoch()).count());

    std::lock_guard<std::mutex> lock(m_queue_mutex);
    m_sync_queue.push(event);

    std::lock_guard<std::mutex> slock(m_stats_mutex);
    m_stats.syncs_queued++;
}

void SaveManager::FlushQueue() {
    if (!m_online.load() || !m_account.is_logged_in) return;

    // Process queue on background thread
    JOBS.Submit([this]() {
        int flushed = 0;
        while (true) {
            SyncEvent event;
            {
                std::lock_guard<std::mutex> lock(m_queue_mutex);
                if (m_sync_queue.empty()) break;
                event = m_sync_queue.front();
                m_sync_queue.pop();
            }
            if (ProcessSyncEvent(event)) {
                flushed++;
            } else if (event.retry_count < 3) {
                // Re-queue with retry count
                event.retry_count++;
                std::lock_guard<std::mutex> lock(m_queue_mutex);
                m_sync_queue.push(event);
                break; // stop flushing — will retry next time
            }
        }
        if (flushed > 0) {
            TLOG_INFO(MOD, "Flushed " + std::to_string(flushed)
                         + " queued syncs");
            std::lock_guard<std::mutex> slock(m_stats_mutex);
            m_stats.syncs_flushed += flushed;
        }
    }, "SaveManager::FlushQueue", JobPriority::LOW);
}

bool SaveManager::ProcessSyncEvent(const SyncEvent& event) {
    std::string endpoint;
    switch (event.type) {
        case SyncType::FULL_SAVE:       endpoint = "/save/push";         break;
        case SyncType::ITEM_ADD:        endpoint = "/inventory/add";     break;
        case SyncType::ITEM_REMOVE:     endpoint = "/inventory/remove";  break;
        case SyncType::ITEM_EQUIP:      endpoint = "/inventory/equip";   break;
        case SyncType::COSMETIC_EQUIP:  endpoint = "/cosmetics/equip";   break;
        case SyncType::COINS_UPDATE:    endpoint = "/wallet/update";     break;
        case SyncType::WORLD_CHANGE:    endpoint = "/world/change";      break;
        case SyncType::MILESTONE:       endpoint = "/milestone";         break;
        default:                        endpoint = "/save/push";         break;
    }

    std::string resp = HttpPost(endpoint, event.payload);
    return !resp.empty();
}

bool SaveManager::HasQueuedEvents() const {
    std::lock_guard<std::mutex> lock(m_queue_mutex);
    return !m_sync_queue.empty();
}

int SaveManager::QueuedEventCount() const {
    std::lock_guard<std::mutex> lock(m_queue_mutex);
    return static_cast<int>(m_sync_queue.size());
}

// ============================================================
// LOCAL SAVE — binary format
// ============================================================
bool SaveManager::SaveLocal(const GameSaveData& data,
                              const std::string& filepath)
{
    std::string path = filepath.empty()
        ? "save_" + std::to_string(data.save_slot) + ".terra"
        : filepath;

    // BUG 7 FIX: Create backup of existing save before overwrite
    // If new save is corrupt, player can restore from .bak
    std::string backup_path = path + ".bak";
    {
        std::ifstream existing(path, std::ios::binary);
        if (existing.is_open()) {
            std::ofstream backup(backup_path, std::ios::binary);
            backup << existing.rdbuf();
        }
    }

    // Write to temp file first — atomic swap prevents half-written saves
    std::string temp_path = path + ".tmp";
    {
        std::ofstream f(temp_path, std::ios::binary);
        if (!f.is_open()) {
            TLOG_ERR(MOD, "Cannot write local save: " + temp_path);
            return false;
        }

        const uint32_t MAGIC = 0x53415645; // "SAVE"
        const uint32_t VER   = 2;
        f.write(reinterpret_cast<const char*>(&MAGIC), sizeof(MAGIC));
        f.write(reinterpret_cast<const char*>(&VER),   sizeof(VER));

        f.write(reinterpret_cast<const char*>(&data.world_seed),          sizeof(data.world_seed));
        f.write(reinterpret_cast<const char*>(&data.current_island),      sizeof(data.current_island));
        f.write(reinterpret_cast<const char*>(&data.game_time),           sizeof(data.game_time));
        f.write(reinterpret_cast<const char*>(&data.fragments_found),     sizeof(data.fragments_found));
        f.write(reinterpret_cast<const char*>(&data.corruption_level),    sizeof(data.corruption_level));
        f.write(reinterpret_cast<const char*>(&data.player_level),        sizeof(data.player_level));
        f.write(reinterpret_cast<const char*>(&data.player_xp),           sizeof(data.player_xp));
        f.write(reinterpret_cast<const char*>(&data.player_health),       sizeof(data.player_health));
        f.write(reinterpret_cast<const char*>(&data.player_max_health),   sizeof(data.player_max_health));
        f.write(reinterpret_cast<const char*>(&data.player_stamina),      sizeof(data.player_stamina));
        f.write(reinterpret_cast<const char*>(&data.terra_coins),         sizeof(data.terra_coins));
        uint8_t kael = data.is_kael ? 1 : 0;
        f.write(reinterpret_cast<const char*>(&kael), sizeof(kael));

        std::string json_blob = SerializeSave(data);
        uint32_t json_len = static_cast<uint32_t>(json_blob.size());
        f.write(reinterpret_cast<const char*>(&json_len), sizeof(json_len));
        f.write(json_blob.c_str(), json_len);

        // Write checksum at end for corruption detection
        uint32_t checksum = static_cast<uint32_t>(json_blob.size() ^ 0xDEADBEEF);
        f.write(reinterpret_cast<const char*>(&checksum), sizeof(checksum));
    }

    // Atomic rename: temp → actual save
    std::remove(path.c_str());
    if (std::rename(temp_path.c_str(), path.c_str()) != 0) {
        TLOG_ERR(MOD, "Save atomic rename failed — restoring backup");
        std::rename(backup_path.c_str(), path.c_str());
        return false;
    }

    TLOG_DEBUG(MOD, "Local save written with backup: " + path);
    return true;
}

bool SaveManager::LoadLocal(GameSaveData& out,
                              const std::string& filepath)
{
    std::string path = filepath.empty()
        ? "save_1.terra"
        : filepath;

    std::ifstream f(path, std::ios::binary);
    if (!f.is_open()) {
        TLOG_DEBUG(MOD, "No local save found: " + path);
        return false;
    }

    uint32_t magic = 0, ver = 0;
    f.read(reinterpret_cast<char*>(&magic), sizeof(magic));
    f.read(reinterpret_cast<char*>(&ver),   sizeof(ver));

    if (magic != 0x53415645) {
        TLOG_ERR(MOD, "Invalid save file magic");
        return false;
    }

    f.read(reinterpret_cast<char*>(&out.world_seed),        sizeof(out.world_seed));
    f.read(reinterpret_cast<char*>(&out.current_island),    sizeof(out.current_island));
    f.read(reinterpret_cast<char*>(&out.game_time),         sizeof(out.game_time));
    f.read(reinterpret_cast<char*>(&out.fragments_found),   sizeof(out.fragments_found));
    f.read(reinterpret_cast<char*>(&out.corruption_level),  sizeof(out.corruption_level));
    f.read(reinterpret_cast<char*>(&out.player_level),      sizeof(out.player_level));
    f.read(reinterpret_cast<char*>(&out.player_xp),         sizeof(out.player_xp));
    f.read(reinterpret_cast<char*>(&out.player_health),     sizeof(out.player_health));
    f.read(reinterpret_cast<char*>(&out.player_max_health), sizeof(out.player_max_health));
    f.read(reinterpret_cast<char*>(&out.player_stamina),    sizeof(out.player_stamina));
    f.read(reinterpret_cast<char*>(&out.terra_coins),       sizeof(out.terra_coins));
    uint8_t kael = 1;
    f.read(reinterpret_cast<char*>(&kael), sizeof(kael));
    out.is_kael = (kael == 1);

    uint32_t json_len = 0;
    f.read(reinterpret_cast<char*>(&json_len), sizeof(json_len));
    std::string json_blob(json_len, '\0');
    f.read(&json_blob[0], json_len);

    // Parse complex data from JSON blob
    DeserializeSave(json_blob, out);

    TLOG_INFO(MOD, "Local save loaded — island:"
                 + std::to_string(out.current_island)
                 + " level:" + std::to_string(out.player_level));
    return true;
}

// ============================================================
// CONFLICT RESOLUTION
// ============================================================
GameSaveData SaveManager::ResolveConflict(const GameSaveData& local,
                                            const GameSaveData& cloud) const
{
    GameSaveData merged = cloud; // start with cloud as base

    // Rule 1: Progress — take higher values
    merged.current_island  = std::max(local.current_island,  cloud.current_island);
    merged.player_level    = std::max(local.player_level,    cloud.player_level);
    merged.player_xp       = std::max(local.player_xp,       cloud.player_xp);
    merged.fragments_found = std::max(local.fragments_found, cloud.fragments_found);
    merged.game_time       = std::max(local.game_time,       cloud.game_time);

    // Rule 2: Items — merge both inventories
    std::map<std::string, int> item_counts;
    for (const auto& item : local.inventory)  item_counts[item.item_id] += item.quantity;
    for (const auto& item : cloud.inventory)  item_counts[item.item_id]  = std::max(
        item_counts[item.item_id], item.quantity);
    merged.inventory.clear();
    for (const auto& [id, qty] : item_counts) {
        InventoryItem item;
        item.item_id  = id;
        item.quantity = qty;
        merged.inventory.push_back(item);
    }

    // Rule 3: Coins — take highest balance
    merged.terra_coins = std::max(local.terra_coins, cloud.terra_coins);

    // Rule 4: Cosmetics — keep all owned
    std::set<std::string> cosmetic_ids;
    for (const auto& c : local.cosmetics)  cosmetic_ids.insert(c.cosmetic_id);
    for (const auto& c : cloud.cosmetics)  cosmetic_ids.insert(c.cosmetic_id);
    merged.cosmetics.clear();
    for (const auto& id : cosmetic_ids) {
        CosmeticItem ci;
        ci.cosmetic_id = id;
        merged.cosmetics.push_back(ci);
    }

    // Rule 5: Story flags — OR merge (if either had it, merged has it)
    for (const auto& [k, v] : local.story_flags) {
        merged.story_flags[k] = merged.story_flags[k] || v;
    }
    for (const auto& [k, v] : local.bosses_defeated) {
        merged.bosses_defeated[k] = merged.bosses_defeated[k] || v;
    }

    TLOG_INFO(MOD, "Conflict resolved — island:"
                 + std::to_string(merged.current_island)
                 + " items:" + std::to_string(merged.inventory.size())
                 + " coins:" + std::to_string(merged.terra_coins));
    return merged;
}

// ============================================================
// AUTO-SAVE TICK
// ============================================================
void SaveManager::Tick(float delta_time) {
    m_autosave_timer += delta_time;

    if (m_autosave_timer >= m_autosave_interval) {
        m_autosave_timer = 0.0f;
        if (m_live_data) {
            TLOG_DEBUG(MOD, "Auto-saving...");
            Save(*m_live_data);
        }
    }

    // Flush offline queue when online
    if (m_online.load() && m_account.is_logged_in && HasQueuedEvents()) {
        FlushQueue();
    }
}

// ============================================================
// HTTP HELPERS
// ============================================================
std::string SaveManager::HttpPost(const std::string& endpoint,
                                    const std::string& body,
                                    bool auth)
{
    std::string url = m_api_base + endpoint;
    std::string response;
    CURL* curl = curl_easy_init();
    if (!curl) return "";

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    if (auth && !m_account.jwt_token.empty()) {
        std::string auth_header = "Authorization: Bearer " + m_account.jwt_token;
        headers = curl_slist_append(headers, auth_header.c_str());
    }

    curl_easy_setopt(curl, CURLOPT_URL,           url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER,    headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS,    body.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       10L);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        m_online.store(false);
        TLOG_WARN(MOD, "HTTP failed: " + std::string(curl_easy_strerror(res)));
    } else {
        m_online.store(true);
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return response;
}

std::string SaveManager::HttpGet(const std::string& endpoint,
                                   bool auth)
{
    std::string url = m_api_base + endpoint;
    std::string response;
    CURL* curl = curl_easy_init();
    if (!curl) return "";

    struct curl_slist* headers = nullptr;
    if (auth && !m_account.jwt_token.empty()) {
        headers = curl_slist_append(headers,
            ("Authorization: Bearer " + m_account.jwt_token).c_str());
    }

    curl_easy_setopt(curl, CURLOPT_URL,           url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER,    headers);
    curl_easy_setopt(curl, CURLOPT_HTTPGET,       1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       10L);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) m_online.store(false);
    else                 m_online.store(true);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return response;
}

// ============================================================
// SERIALIZATION
// ============================================================
std::string SaveManager::SerializeSave(const GameSaveData& data) const {
    json j;
    j["world_seed"]       = data.world_seed;
    j["current_island"]   = data.current_island;
    j["game_time"]        = data.game_time;
    j["fragments_found"]  = data.fragments_found;
    j["corruption_level"] = data.corruption_level;
    j["player_level"]     = data.player_level;
    j["player_xp"]        = data.player_xp;
    j["player_health"]    = data.player_health;
    j["player_max_health"]= data.player_max_health;
    j["player_stamina"]   = data.player_stamina;
    j["is_kael"]          = data.is_kael;
    j["terra_coins"]      = data.terra_coins;
    j["story_flags"]      = data.story_flags;
    j["bosses_defeated"]  = data.bosses_defeated;

    json islands = json::object();
    for (const auto& [id, vis] : data.islands_visited)
        islands[std::to_string(id)] = vis;
    j["islands_visited"] = islands;

    json corruption = json::object();
    for (const auto& [id, c] : data.island_corruption)
        corruption[std::to_string(id)] = c;
    j["island_corruption"] = corruption;

    json inv = json::array();
    for (const auto& item : data.inventory) {
        inv.push_back({
            {"item_id",     item.item_id},
            {"quantity",    item.quantity},
            {"slot",        item.slot},
            {"is_equipped", item.is_equipped},
            {"metadata",    item.metadata}
        });
    }
    j["inventory"] = inv;

    json cos = json::array();
    for (const auto& c : data.cosmetics) {
        cos.push_back({
            {"cosmetic_id",  c.cosmetic_id},
            {"is_equipped",  c.is_equipped}
        });
    }
    j["cosmetics"] = cos;

    json wc = json::array();
    for (const auto& change : data.world_changes) {
        wc.push_back({
            {"change_type", change.change_type},
            {"island_id",   change.island_id},
            {"data",        change.data},
            {"timestamp",   change.timestamp}
        });
    }
    j["world_changes"] = wc;

    return j.dump();
}

bool SaveManager::DeserializeSave(const std::string& s,
                                    GameSaveData& out) const
{
    try {
        json j = json::parse(s);
        out.world_seed        = j.value("world_seed",       out.world_seed);
        out.current_island    = j.value("current_island",   out.current_island);
        out.game_time         = j.value("game_time",        out.game_time);
        out.fragments_found   = j.value("fragments_found",  out.fragments_found);
        out.corruption_level  = j.value("corruption_level", out.corruption_level);
        out.player_level      = j.value("player_level",     out.player_level);
        out.player_xp         = j.value("player_xp",        out.player_xp);
        out.player_health     = j.value("player_health",    out.player_health);
        out.player_max_health = j.value("player_max_health",out.player_max_health);
        out.player_stamina    = j.value("player_stamina",   out.player_stamina);
        out.is_kael           = j.value("is_kael",          out.is_kael);
        out.terra_coins       = j.value("terra_coins",      out.terra_coins);

        if (j.contains("story_flags"))
            out.story_flags = j["story_flags"].get<std::map<std::string,bool>>();
        if (j.contains("bosses_defeated"))
            out.bosses_defeated = j["bosses_defeated"].get<std::map<std::string,bool>>();

        return true;
    } catch (const std::exception& e) {
        TLOG_ERR(MOD, "DeserializeSave error: " + std::string(e.what()));
        return false;
    }
}

// ============================================================
// TOKEN PERSISTENCE
// ============================================================
void SaveManager::SaveTokenLocally(const std::string& token) {
    std::ofstream f(m_local_token_path);
    if (f.is_open()) f << token;
}

bool SaveManager::LoadTokenLocally() {
    std::ifstream f(m_local_token_path);
    if (!f.is_open()) return false;
    std::getline(f, m_account.jwt_token);
    return !m_account.jwt_token.empty();
}

// ============================================================
// ONLINE CHECK
// ============================================================
void SaveManager::CheckOnlineStatus() {
    JOBS.Submit([this]() {
        std::string resp = HttpGet("/ping", false);
        m_online.store(!resp.empty());
        TLOG_INFO(MOD, "Online: " + std::string(m_online.load() ? "yes" : "no"));
    }, "SaveManager::PingServer", JobPriority::LOW);
}

// ============================================================
// STATS
// ============================================================
void SaveManager::UpdateStats(bool success, double latency_ms) {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    if (success) m_stats.saves_completed++;
    else         m_stats.saves_failed++;
    m_stats.last_latency_ms = latency_ms;
}

SaveManager::Stats SaveManager::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}
