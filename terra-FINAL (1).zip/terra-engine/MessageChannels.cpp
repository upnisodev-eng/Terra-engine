// ============================================================
// TERRA ENGINE — MESSAGE CHANNELS IMPLEMENTATION
// MessageChannels.cpp — Version 1.0.0
// ============================================================

#include "MessageChannels.h"
#include <sstream>
#include <algorithm>
#include <cstring>
#include <fstream>
#include <cmath>

namespace TerraEngine {

// ============================================================
// STATICS
// ============================================================
const char* MessageRouter::MOD      = "MessageRouter";
const char* SimulationManager::MOD  = "SimulationManager";
const char* SpatialGrid::MOD        = "SpatialGrid";
const char* WorldSeedSystem::MOD    = "WorldSeedSystem";

// ============================================================
// MESSAGE ROUTER — CONSTRUCTOR
// ============================================================
MessageRouter::MessageRouter() {
    BuildEventChannelMap();
    TLOG_INFO(MOD, "MessageRouter created — " +
              std::to_string(CHANNEL_COUNT) + " channels");
}

void MessageRouter::BuildEventChannelMap() {
    // Combat channel events
    m_event_channel_map["combat_start"]      = Channel::COMBAT;
    m_event_channel_map["combat_end"]        = Channel::COMBAT;
    m_event_channel_map["player_low_health"] = Channel::COMBAT;
    m_event_channel_map["player_died"]       = Channel::COMBAT;
    m_event_channel_map["boss_awakened"]     = Channel::COMBAT;
    m_event_channel_map["boss_phase_change"] = Channel::COMBAT;
    m_event_channel_map["boss_defeated"]     = Channel::COMBAT;

    // AI channel events
    m_event_channel_map["npc_decision"]      = Channel::AI;
    m_event_channel_map["boss_strategy"]     = Channel::AI;
    m_event_channel_map["creature_ai"]       = Channel::AI;
    m_event_channel_map["player_bored"]      = Channel::AI;
    m_event_channel_map["player_overwhelmed"]= Channel::AI;

    // Weather channel events
    m_event_channel_map["storm_start"]       = Channel::WEATHER;
    m_event_channel_map["storm_end"]         = Channel::WEATHER;
    m_event_channel_map["night_fall"]        = Channel::WEATHER;
    m_event_channel_map["day_break"]         = Channel::WEATHER;
    m_event_channel_map["flood_warning"]     = Channel::WEATHER;

    // World state channel events
    m_event_channel_map["island_enter"]      = Channel::WORLD_STATE;
    m_event_channel_map["island_generate"]   = Channel::WORLD_STATE;
    m_event_channel_map["corruption_spread"] = Channel::WORLD_STATE;
    m_event_channel_map["fragment_found"]    = Channel::WORLD_STATE;
    m_event_channel_map["fragment_absorbed"] = Channel::WORLD_STATE;

    // NPC channel events
    m_event_channel_map["npc_hungry"]        = Channel::NPC;
    m_event_channel_map["npc_in_danger"]     = Channel::NPC;
    m_event_channel_map["village_attack"]    = Channel::NPC;
    m_event_channel_map["npc_job_change"]    = Channel::NPC;
    m_event_channel_map["village_placed"]    = Channel::NPC;

    // Physics channel events
    m_event_channel_map["collision"]         = Channel::PHYSICS;
    m_event_channel_map["water_level_change"]= Channel::PHYSICS;
    m_event_channel_map["terrain_modify"]    = Channel::PHYSICS;
}

// ============================================================
// POST — route to channel buffer
// ============================================================
bool MessageRouter::Post(Channel channel, const ChannelMessage& msg) {
    int ch = static_cast<int>(channel);
    if (ch < 0 || ch >= CHANNEL_COUNT) {
        TLOG_WARN(MOD, "Invalid channel index");
        return false;
    }

    bool ok = m_buffers[ch].Push(msg);
    {
        std::lock_guard<std::mutex> lock(m_stats_mutex);
        m_stats.total_posted++;
        m_stats.per_channel[ch]++;
        if (!ok) m_stats.total_dropped++;
    }
    return ok;
}

bool MessageRouter::Post(const std::string& event_type,
                          const std::string& data,
                          const std::string& from_agent,
                          int priority)
{
    Channel ch = GetChannelForEvent(event_type);
    ChannelMessage msg(
        event_type.c_str(),
        data.c_str(),
        from_agent.c_str(),
        priority
    );
    return Post(ch, msg);
}

// ============================================================
// POST IMMEDIATE — bypasses buffer for CRITICAL messages
// ============================================================
void MessageRouter::PostImmediate(Channel channel,
                                   const ChannelMessage& msg)
{
    int ch = static_cast<int>(channel);
    if (ch < 0 || ch >= CHANNEL_COUNT) return;

    std::lock_guard<std::mutex> lock(m_sub_mutex);
    for (auto& sub : m_subscribers[ch]) {
        if (sub.handler) {
            try {
                sub.handler(msg);
            } catch (const std::exception& e) {
                TLOG_ERR(MOD, std::string("Immediate handler threw: ") + e.what());
            }
        }
    }

    std::lock_guard<std::mutex> slock(m_stats_mutex);
    m_stats.total_delivered++;
}

// ============================================================
// SUBSCRIBE
// ============================================================
void MessageRouter::Subscribe(Channel channel,
                               const std::string& name,
                               ChannelHandler handler)
{
    int ch = static_cast<int>(channel);
    if (ch < 0 || ch >= CHANNEL_COUNT) return;

    std::lock_guard<std::mutex> lock(m_sub_mutex);
    // Remove existing subscription for same name on same channel
    auto& subs = m_subscribers[ch];
    subs.erase(
        std::remove_if(subs.begin(), subs.end(),
            [&](const Subscriber& s) { return s.name == name; }),
        subs.end()
    );
    subs.push_back({name, std::move(handler)});
    TLOG_DEBUG(MOD, name + " subscribed to channel " + std::to_string(ch));
}

void MessageRouter::Unsubscribe(Channel channel,
                                 const std::string& name)
{
    int ch = static_cast<int>(channel);
    if (ch < 0 || ch >= CHANNEL_COUNT) return;

    std::lock_guard<std::mutex> lock(m_sub_mutex);
    auto& subs = m_subscribers[ch];
    subs.erase(
        std::remove_if(subs.begin(), subs.end(),
            [&](const Subscriber& s) { return s.name == name; }),
        subs.end()
    );
}

// ============================================================
// TICK — swap buffers and dispatch all channels
// Called once per frame by SimulationManager
// ============================================================
void MessageRouter::Tick(uint64_t frame_id) {
    // Swap all channel buffers simultaneously
    for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
        m_buffers[ch].Swap();
    }

    // Dispatch each channel independently — no cross-channel lock
    for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
        DispatchChannel(static_cast<Channel>(ch), frame_id);
    }
}

void MessageRouter::DispatchChannel(Channel ch, uint64_t /*frame_id*/) {
    int idx = static_cast<int>(ch);

    if (m_buffers[idx].IsEmpty()) return;

    // Get snapshot of subscribers — minimise lock hold time
    std::vector<Subscriber> subs_snapshot;
    {
        std::lock_guard<std::mutex> lock(m_sub_mutex);
        subs_snapshot = m_subscribers[idx];
    }

    m_buffers[idx].ForEach([&](const ChannelMessage& msg) {
        for (auto& sub : subs_snapshot) {
            if (sub.handler) {
                try {
                    sub.handler(msg);
                    std::lock_guard<std::mutex> lock(m_stats_mutex);
                    m_stats.total_delivered++;
                } catch (const std::exception& e) {
                    TLOG_ERR(MOD, std::string("Handler threw: ") + e.what());
                }
            }
        }
    });
}

Channel MessageRouter::GetChannelForEvent(const std::string& event_type) const {
    auto it = m_event_channel_map.find(event_type);
    return (it != m_event_channel_map.end()) ? it->second : Channel::AI;
}

MessageRouter::Stats MessageRouter::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}

void MessageRouter::PrintStats() const {
    Stats s = GetStats();
    TLOG_INFO(MOD, "Posted:" + std::to_string(s.total_posted)
                 + " Delivered:" + std::to_string(s.total_delivered)
                 + " Dropped:" + std::to_string(s.total_dropped));
}

// ============================================================
// SIMULATION MANAGER — CONSTRUCTOR
// ============================================================
SimulationManager::SimulationManager()
    : m_frame_id(0)
    , m_sim_time(0.0f)
{
    TLOG_INFO(MOD, "SimulationManager created");
}

void SimulationManager::RegisterSystem(const std::string& name,
                                        std::function<void(float)> fn,
                                        float tick_rate_hz,
                                        int priority)
{
    std::lock_guard<std::mutex> lock(m_systems_mutex);

    // Remove if already registered
    m_systems.erase(
        std::remove_if(m_systems.begin(), m_systems.end(),
            [&](const SystemEntry& e) { return e.name == name; }),
        m_systems.end()
    );

    SystemEntry entry;
    entry.name         = name;
    entry.tick_fn      = std::move(fn);
    entry.tick_rate_hz = tick_rate_hz;
    entry.priority     = priority;
    entry.accumulator  = 0.0f;

    m_systems.push_back(entry);

    // Sort by priority — lower number ticks first
    std::sort(m_systems.begin(), m_systems.end(),
        [](const SystemEntry& a, const SystemEntry& b) {
            return a.priority < b.priority;
        });

    TLOG_DEBUG(MOD, "Registered: " + name + " @ "
                  + (tick_rate_hz > 0
                     ? std::to_string(static_cast<int>(tick_rate_hz)) + "Hz"
                     : "every frame")
                  + " priority:" + std::to_string(priority));
}

void SimulationManager::UnregisterSystem(const std::string& name) {
    std::lock_guard<std::mutex> lock(m_systems_mutex);
    m_systems.erase(
        std::remove_if(m_systems.begin(), m_systems.end(),
            [&](const SystemEntry& e) { return e.name == name; }),
        m_systems.end()
    );
}

// ============================================================
// SIMULATION TICK
// AUDIT FIX 5: deterministic ordered tick system
// Order: Input → Physics → AI → Gameplay → Environment → Render
// ============================================================
void SimulationManager::Tick(float delta_time) {
    uint64_t frame = m_frame_id.fetch_add(1);
    m_sim_time += delta_time;

    // Swap and dispatch all message channels first
    MessageRouter::Get().Tick(frame);

    std::vector<SystemEntry> snapshot;
    {
        std::lock_guard<std::mutex> lock(m_systems_mutex);
        snapshot = m_systems;
    }

    for (auto& entry : snapshot) {
        if (entry.tick_rate_hz <= 0.0f) {
            // Every frame system
            if (entry.tick_fn) entry.tick_fn(delta_time);
        } else {
            // Fixed-rate system — accumulate time
            float interval = 1.0f / entry.tick_rate_hz;
            entry.accumulator += delta_time;
            while (entry.accumulator >= interval) {
                if (entry.tick_fn) entry.tick_fn(interval);
                entry.accumulator -= interval;
            }
        }
    }

    // BUG 2 FIX: writeback by NAME not index position.
    // Old index-based writeback silently stamped wrong accumulator
    // on wrong system if RegisterSystem() fired during unlocked tick.
    // Name-match is O(n²) but n is always tiny (< 20 systems).
    {
        std::lock_guard<std::mutex> lock(m_systems_mutex);
        for (const auto& snap : snapshot) {
            for (auto& sys : m_systems) {
                if (sys.name == snap.name) {
                    sys.accumulator = snap.accumulator;
                    break;
                }
            }
        }
    }
}

// ============================================================
// SPATIAL GRID — CONSTRUCTOR
// ============================================================
SpatialGrid::SpatialGrid() {
    TLOG_DEBUG(MOD, "SpatialGrid created — cell size: "
                  + std::to_string(CELL_SIZE));
}

void SpatialGrid::Register(const std::string& id, float x, float z) {
    std::lock_guard<std::mutex> lock(m_mutex);
    int cx = static_cast<int>(x / CELL_SIZE);
    int cz = static_cast<int>(z / CELL_SIZE);

    EntityPos pos{x, z, cx, cz};
    m_entities[id] = pos;
    AddToCell(id, cx, cz);
}

void SpatialGrid::Unregister(const std::string& id) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_entities.find(id);
    if (it == m_entities.end()) return;
    RemoveFromCell(id, it->second.cell_x, it->second.cell_z);
    m_entities.erase(it);
}

void SpatialGrid::Move(const std::string& id, float x, float z) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_entities.find(id);
    if (it == m_entities.end()) return;

    EntityPos& pos = it->second;
    int new_cx = static_cast<int>(x / CELL_SIZE);
    int new_cz = static_cast<int>(z / CELL_SIZE);

    if (new_cx != pos.cell_x || new_cz != pos.cell_z) {
        RemoveFromCell(id, pos.cell_x, pos.cell_z);
        pos.cell_x = new_cx;
        pos.cell_z = new_cz;
        AddToCell(id, new_cx, new_cz);
    }
    pos.x = x;
    pos.z = z;
}

std::vector<std::string> SpatialGrid::GetNearby(float x, float z,
                                                   float radius) const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<std::string> result;

    int min_cx = static_cast<int>((x - radius) / CELL_SIZE);
    int max_cx = static_cast<int>((x + radius) / CELL_SIZE);
    int min_cz = static_cast<int>((z - radius) / CELL_SIZE);
    int max_cz = static_cast<int>((z + radius) / CELL_SIZE);

    float r2 = radius * radius;

    for (int cx = min_cx; cx <= max_cx; cx++) {
        for (int cz = min_cz; cz <= max_cz; cz++) {
            auto cell_it = m_cells.find(CellKey(cx, cz));
            if (cell_it == m_cells.end()) continue;
            for (const std::string& id : cell_it->second) {
                auto pos_it = m_entities.find(id);
                if (pos_it == m_entities.end()) continue;
                float dx = pos_it->second.x - x;
                float dz = pos_it->second.z - z;
                if (dx * dx + dz * dz <= r2) {
                    result.push_back(id);
                }
            }
        }
    }
    return result;
}

GridCell SpatialGrid::GetCell(float x, float z) const {
    GridCell cell;
    cell.x       = static_cast<int>(x / CELL_SIZE);
    cell.y       = static_cast<int>(z / CELL_SIZE);
    cell.world_x = static_cast<float>(cell.x * CELL_SIZE);
    cell.world_z = static_cast<float>(cell.y * CELL_SIZE);
    return cell;
}

bool SpatialGrid::AreNearby(const std::string& a,
                              const std::string& b) const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    auto ia = m_entities.find(a);
    auto ib = m_entities.find(b);
    if (ia == m_entities.end() || ib == m_entities.end()) return false;
    int dx = std::abs(ia->second.cell_x - ib->second.cell_x);
    int dz = std::abs(ia->second.cell_z - ib->second.cell_z);
    return dx <= 1 && dz <= 1;
}

void SpatialGrid::AddToCell(const std::string& id, int cx, int cz) {
    m_cells[CellKey(cx, cz)].push_back(id);
}

void SpatialGrid::RemoveFromCell(const std::string& id, int cx, int cz) {
    auto it = m_cells.find(CellKey(cx, cz));
    if (it == m_cells.end()) return;
    auto& v = it->second;
    v.erase(std::remove(v.begin(), v.end(), id), v.end());
    if (v.empty()) m_cells.erase(it);
}

// ============================================================
// WORLD SEED SYSTEM — CONSTRUCTOR
// ============================================================
WorldSeedSystem::WorldSeedSystem() {
    BuildIslandTemplates();
    TLOG_INFO(MOD, "WorldSeedSystem created — "
                 + std::to_string(m_island_templates.size())
                 + " island templates");
}

void WorldSeedSystem::SetSeed(uint64_t seed) {
    m_seed              = seed;
    m_world_state.seed  = seed;
    TLOG_INFO(MOD, "World seed set: " + std::to_string(seed));
}

// ============================================================
// BUILD ISLAND TEMPLATES
// These are FIXED — never AI-generated
// AI only generates CONTENT variation, not layout
// ============================================================
void WorldSeedSystem::BuildIslandTemplates() {
    // Island 1 — Terra Haven (Tutorial)
    {
        IslandTemplate t;
        t.island_id    = 1;
        t.name         = "Terra Haven";
        t.biome        = "grassland";
        t.size         = 2000.0f;
        t.region_count = 2;
        t.boss_count   = 0;
        t.anchors = {
            {"village",      200.0f,  300.0f},
            {"safe_zone_a",  0.0f,    0.0f},
            {"safe_zone_b",  800.0f,  600.0f},
            {"bridge_north", 1000.0f, 1900.0f},
            {"lake",         400.0f,  600.0f},
            {"waterfall",    700.0f,  1200.0f}
        };
        m_island_templates.push_back(t);
    }

    // Islands 2-8 — Story islands (fragment holders)
    const struct { const char* name; const char* biome; } island_data[] = {
        {"Ashwood Ridge",    "forest"},
        {"Sandveil",         "desert"},
        {"Ironhold",         "volcanic"},
        {"Crystalpeak",      "crystal"},
        {"The Deadmarsh",    "corrupted"},
        {"Glaciermourne",    "frozen"},
        {"Abysshollow",      "ocean"}
    };

    for (int i = 0; i < 7; i++) {
        IslandTemplate t;
        t.island_id    = i + 2;
        t.name         = island_data[i].name;
        t.biome        = island_data[i].biome;
        t.size         = 3000.0f;
        t.region_count = 4;
        t.boss_count   = 1;
        t.anchors = {
            {"village",       300.0f,  400.0f},
            {"boss_arena",    1500.0f, 1500.0f},
            {"fragment_vault",1500.0f, 1600.0f},
            {"bridge_south",  1500.0f, 100.0f},
            {"bridge_north",  1500.0f, 2900.0f},
            {"ruins",         800.0f,  2000.0f}
        };
        m_island_templates.push_back(t);
    }

    // Island 9 — Voidmargin
    {
        IslandTemplate t;
        t.island_id    = 9;
        t.name         = "Voidmargin";
        t.biome        = "void";
        t.size         = 4000.0f;
        t.region_count = 6;
        t.boss_count   = 1;
        t.anchors = {
            {"void_edge",    3800.0f, 2000.0f},
            {"boss_arena",   2000.0f, 2000.0f},
            {"bridge_south", 2000.0f, 100.0f}
        };
        m_island_templates.push_back(t);
    }

    // Island 10 — God Throne
    {
        IslandTemplate t;
        t.island_id    = 10;
        t.name         = "God Throne";
        t.biome        = "divine";
        t.size         = 5000.0f;
        t.region_count = 10;
        t.boss_count   = 1;
        t.anchors = {
            {"varek_throne",  2500.0f, 2500.0f},
            {"final_arena",   2500.0f, 2000.0f},
            {"bridge_south",  2500.0f, 100.0f}
        };
        m_island_templates.push_back(t);
    }
}

const IslandTemplate& WorldSeedSystem::GetIslandTemplate(int island_id) const {
    for (const auto& t : m_island_templates) {
        if (t.island_id == island_id) return t;
    }
    // Fallback to island 1 if not found
    return m_island_templates[0];
}

// ============================================================
// GENERATE ISLAND CONTENT
// This is what varies per seed — NOT the layout
// ============================================================
WorldSeedSystem::IslandContent
WorldSeedSystem::GenerateIslandContent(int island_id) const
{
    IslandContent content;

    // Use seed + island_id as deterministic random source
    uint64_t rng = m_seed ^ (static_cast<uint64_t>(island_id) * 0x9e3779b97f4a7c15ULL);

    auto next_rng = [&]() -> uint64_t {
        rng ^= rng << 13;
        rng ^= rng >> 7;
        rng ^= rng << 17;
        return rng;
    };

    // NPC name pools — vary per seed
    const char* first_names[] = {
        "Aldric","Mira","Thorn","Sera","Kael","Voss","Lyra","Dren",
        "Cass","Brom","Fira","Jax","Nora","Sable","Rook","Zara"
    };
    const char* jobs[] = {
        "blacksmith","farmer","guard","trader","healer","mage","hunter"
    };

    int npc_count = 5 + static_cast<int>(next_rng() % 6); // 5-10 NPCs
    for (int i = 0; i < npc_count; i++) {
        std::string name = first_names[next_rng() % 16];
        name += "_";
        name += jobs[next_rng() % 7];
        content.npc_name_pool.push_back(name);
    }

    // Boss variant — same boss, different skin/difficulty
    const char* variants[] = {"ancient","corrupted","frost","infernal","spectral"};
    content.boss_variant = variants[next_rng() % 5];

    // Weather tendency
    const char* weathers[] = {"stormy","clear","foggy","rainy","variable"};
    content.weather_tendency = weathers[next_rng() % 5];

    // Corruption start level
    content.corruption_start = (island_id >= 6)
        ? 0.1f + (next_rng() % 30) * 0.01f
        : 0.0f;

    // Resource multipliers (some islands richer in certain resources)
    const char* resources[] = {"wood","stone","iron","crystal","food"};
    for (const char* res : resources) {
        float mult = 0.5f + (next_rng() % 200) * 0.01f; // 0.5x to 2.5x
        content.resource_multipliers[res] = mult;
    }

    return content;
}

// ============================================================
// SAVE / LOAD WORLD STATE
// ============================================================
bool WorldSeedSystem::SaveWorldState(const std::string& filepath) const {
    std::ofstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        TLOG_ERR(MOD, "Cannot open save file: " + filepath);
        return false;
    }

    // Write header
    const uint32_t MAGIC   = 0x54455252; // "TERR"
    const uint32_t VERSION = 1;
    file.write(reinterpret_cast<const char*>(&MAGIC),   sizeof(MAGIC));
    file.write(reinterpret_cast<const char*>(&VERSION), sizeof(VERSION));

    // Write world state
    file.write(reinterpret_cast<const char*>(&m_world_state.seed),
               sizeof(m_world_state.seed));
    file.write(reinterpret_cast<const char*>(&m_world_state.current_island),
               sizeof(m_world_state.current_island));
    file.write(reinterpret_cast<const char*>(&m_world_state.corruption),
               sizeof(m_world_state.corruption));
    file.write(reinterpret_cast<const char*>(&m_world_state.fragments_found),
               sizeof(m_world_state.fragments_found));
    file.write(reinterpret_cast<const char*>(&m_world_state.game_time),
               sizeof(m_world_state.game_time));

    // Write island visited map
    uint32_t island_count = static_cast<uint32_t>(m_world_state.islands_visited.size());
    file.write(reinterpret_cast<const char*>(&island_count), sizeof(island_count));
    for (const auto& [id, visited] : m_world_state.islands_visited) {
        file.write(reinterpret_cast<const char*>(&id),      sizeof(id));
        uint8_t v = visited ? 1 : 0;
        file.write(reinterpret_cast<const char*>(&v),       sizeof(v));
    }

    // Write bosses defeated
    uint32_t boss_count = static_cast<uint32_t>(m_world_state.bosses_defeated.size());
    file.write(reinterpret_cast<const char*>(&boss_count), sizeof(boss_count));
    for (const auto& [id, defeated] : m_world_state.bosses_defeated) {
        file.write(reinterpret_cast<const char*>(&id),      sizeof(id));
        uint8_t d = defeated ? 1 : 0;
        file.write(reinterpret_cast<const char*>(&d),       sizeof(d));
    }

    TLOG_INFO(MOD, "World saved to: " + filepath);
    return true;
}

bool WorldSeedSystem::LoadWorldState(const std::string& filepath) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        TLOG_ERR(MOD, "Cannot open save file: " + filepath);
        return false;
    }

    uint32_t magic = 0, version = 0;
    file.read(reinterpret_cast<char*>(&magic),   sizeof(magic));
    file.read(reinterpret_cast<char*>(&version), sizeof(version));

    if (magic != 0x54455252) {
        TLOG_ERR(MOD, "Invalid save file magic");
        return false;
    }
    if (version != 1) {
        TLOG_ERR(MOD, "Unsupported save version: " + std::to_string(version));
        return false;
    }

    file.read(reinterpret_cast<char*>(&m_world_state.seed),           sizeof(m_world_state.seed));
    file.read(reinterpret_cast<char*>(&m_world_state.current_island), sizeof(m_world_state.current_island));
    file.read(reinterpret_cast<char*>(&m_world_state.corruption),     sizeof(m_world_state.corruption));
    file.read(reinterpret_cast<char*>(&m_world_state.fragments_found),sizeof(m_world_state.fragments_found));
    file.read(reinterpret_cast<char*>(&m_world_state.game_time),      sizeof(m_world_state.game_time));

    uint32_t island_count = 0;
    file.read(reinterpret_cast<char*>(&island_count), sizeof(island_count));
    for (uint32_t i = 0; i < island_count; i++) {
        int id; uint8_t v;
        file.read(reinterpret_cast<char*>(&id), sizeof(id));
        file.read(reinterpret_cast<char*>(&v),  sizeof(v));
        m_world_state.islands_visited[id] = (v == 1);
    }

    uint32_t boss_count = 0;
    file.read(reinterpret_cast<char*>(&boss_count), sizeof(boss_count));
    for (uint32_t i = 0; i < boss_count; i++) {
        int id; uint8_t d;
        file.read(reinterpret_cast<char*>(&id), sizeof(id));
        file.read(reinterpret_cast<char*>(&d),  sizeof(d));
        m_world_state.bosses_defeated[id] = (d == 1);
    }

    m_seed = m_world_state.seed;
    TLOG_INFO(MOD, "World loaded from: " + filepath
                 + " seed:" + std::to_string(m_seed)
                 + " island:" + std::to_string(m_world_state.current_island));
    return true;
}

} // namespace TerraEngine
