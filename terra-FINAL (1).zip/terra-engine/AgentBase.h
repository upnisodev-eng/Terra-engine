// ============================================================
// TERRA ENGINE — AGENT BASE HEADER
// AgentBase.h — Version 1.0.0
// ============================================================
// Base class all 5 Terra Engine agents inherit from.
// Every agent has:
//   - 4-6 transformers via TransformerPool
//   - Peer-to-peer messaging via AgentBus
//   - Long term memory store
//   - World state awareness
//   - Self healing on transformer failure
//   - Async processing support
// ============================================================

#pragma once

#include "TransformerBase.h"
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>
#include <functional>
#include <chrono>
#include <deque>

namespace TerraEngine {

// ============================================================
// AGENT STATE
// ============================================================
enum class AgentState {
    OFFLINE,    // Not yet started
    IDLE,       // Running, waiting for tasks
    THINKING,   // Processing a message/task
    BUSY,       // Handling high priority event
    DEGRADED,   // Some transformers failed but still running
    CRITICAL,   // Most transformers failed — basic function only
    FAILED      // All transformers failed — needs restart
};

// ============================================================
// MESSAGE PRIORITY
// ============================================================
enum class MessagePriority {
    CRITICAL  = 1,  // Boss awakened, player dying
    HIGH      = 2,  // Storm incoming, combat started
    NORMAL    = 5,  // Standard agent communication
    LOW       = 8,  // Background updates
    AMBIENT   = 10  // Passive world state updates
};

// ============================================================
// AGENT MESSAGE
// The core communication unit between agents
// ============================================================
struct AgentMessage {
    std::string     id;             // Unique message ID
    std::string     from_agent;     // Sender agent name
    std::string     to_agent;       // Recipient agent name
    std::string     type;           // e.g. "storm", "npc_hungry", "boss_phase"
    std::string     content;        // Message payload
    MessagePriority priority = MessagePriority::NORMAL;
    bool            requires_response = false;
    std::string     response_id;    // ID to respond to
    std::chrono::steady_clock::time_point timestamp;

    AgentMessage() : timestamp(std::chrono::steady_clock::now()) {}

    // Comparison for priority queue — higher priority = lower int value
    bool operator>(const AgentMessage& other) const {
        return static_cast<int>(priority) > static_cast<int>(other.priority);
    }
};

// ============================================================
// WORLD STATE SNAPSHOT
// Shared world context all agents read
// ============================================================
struct WorldState {
    int         current_island    = 1;
    std::string time_of_day       = "morning"; // morning/noon/evening/night
    std::string weather           = "clear";   // clear/rain/storm/snow/fog
    float       corruption_level  = 0.0f;      // 0.0 to 1.0
    int         player_health     = 100;
    int         player_level      = 1;
    bool        boss_active       = false;
    bool        player_in_combat  = false;
    float       player_hunger     = 1.0f;      // 0=starving 1=full
    float       player_thirst     = 1.0f;
    int         npc_count         = 0;
    int         enemy_count       = 0;
    float       day_cycle_progress = 0.0f;     // 0.0 to 1.0
    std::map<std::string, std::string> custom; // extensible
};

// ============================================================
// AGENT BASE CLASS
// ============================================================
class AgentBus; // forward declaration

class AgentBase {
public:
    // --------------------------------------------------------
    // Constructor / Destructor
    // name         — unique agent name e.g. "AgentNPC"
    // capabilities — what this agent handles
    // --------------------------------------------------------
    AgentBase(const std::string& name,
              const std::vector<std::string>& capabilities);

    virtual ~AgentBase();

    // --------------------------------------------------------
    // Lifecycle
    // --------------------------------------------------------
    virtual bool Start();                  // Called once at engine start
    virtual void Stop();                   // Called on engine shutdown
    virtual void Tick(float delta_time);   // Called every game frame

    // --------------------------------------------------------
    // Core intelligence — override in each agent
    // --------------------------------------------------------
    virtual void OnMessage (const AgentMessage& msg)   = 0;
    virtual void OnTick    (float delta_time)          = 0;
    virtual void OnWorldStateChanged(const WorldState& state) {}

    // --------------------------------------------------------
    // Messaging — send to other agents via AgentBus
    // --------------------------------------------------------
    void Send(const std::string& to_agent,
              const std::string& type,
              const std::string& content,
              MessagePriority priority = MessagePriority::NORMAL);

    void Broadcast(const std::string& type,
                   const std::string& content,
                   MessagePriority priority = MessagePriority::NORMAL);

    // Called by AgentBus to deliver a message
    void Receive(const AgentMessage& msg);

    // --------------------------------------------------------
    // Thinking — uses transformer pool
    // --------------------------------------------------------
    TransformerResult Think(const std::string& context,
                             const std::string& question,
                             int transformer_index = -1, // -1 = auto select
                             int priority = 5);

    // Async think — non-blocking
    void ThinkAsync(const std::string& context,
                    const std::string& question,
                    std::function<void(TransformerResult)> callback,
                    int priority = 5);

    // --------------------------------------------------------
    // Memory — long term persistent memory
    // --------------------------------------------------------
    void        Remember(const std::string& key, const std::string& value);
    std::string Recall  (const std::string& key) const;
    bool        Knows   (const std::string& key) const;
    void        Forget  (const std::string& key);
    void        ForgetAll();
    size_t      MemoryCount() const;

    // --------------------------------------------------------
    // World state access
    // --------------------------------------------------------
    void               UpdateWorldState(const WorldState& state);
    const WorldState&  GetWorldState()   const { return m_world_state; }

    // --------------------------------------------------------
    // Identity and health
    // --------------------------------------------------------
    const std::string&              GetName()         const { return m_name; }
    const std::vector<std::string>& GetCapabilities() const { return m_capabilities; }
    AgentState                      GetState()        const;
    bool                            IsHealthy()       const;
    bool                            IsRunning()       const { return m_running.load(); }

    // --------------------------------------------------------
    // Fault tolerance
    // --------------------------------------------------------
    void RecoverTransformers();
    int  HealthyTransformerCount() const;

    // --------------------------------------------------------
    // Bus registration — called by AgentBus
    // --------------------------------------------------------
    void SetBus(AgentBus* bus) { m_bus = bus; }
    AgentBus* GetBus() const   { return m_bus; }

    // --------------------------------------------------------
    // Stats report
    // --------------------------------------------------------
    struct Stats {
        int    messages_received  = 0;
        int    messages_sent      = 0;
        int    thinks_completed   = 0;
        int    thinks_failed      = 0;
        double avg_think_ms       = 0.0;
        int    transformer_failures = 0;
        std::chrono::steady_clock::time_point started_at;
    };
    Stats GetStats() const;

protected:
    // --------------------------------------------------------
    // Transformer pool — add in derived class constructors
    // --------------------------------------------------------
    TransformerPool m_transformers;

    // Add a transformer to this agent
    void AddTransformer(std::shared_ptr<TransformerBase> t);

    // --------------------------------------------------------
    // Helpers for derived classes
    // --------------------------------------------------------
    std::string GetWorldContext() const;  // Formatted world state string
    std::string GenerateTaskId() const;   // Unique task ID generator

    // Logger helper
    void Log(LogLevel level, const std::string& msg) const;

    std::string                  m_name;
    std::vector<std::string>     m_capabilities;
    WorldState                   m_world_state;

private:
    AgentBus*  m_bus = nullptr;
    std::atomic<bool>       m_running;
    std::atomic<AgentState> m_state;

    // Message queue — priority ordered
    using MsgQueue = std::priority_queue<
        AgentMessage,
        std::vector<AgentMessage>,
        std::greater<AgentMessage>
    >;
    MsgQueue           m_msg_queue;
    mutable std::mutex m_queue_mutex;

    // Memory store
    mutable std::mutex                       m_memory_mutex;
    std::map<std::string, std::string>       m_memory;
    std::deque<std::string>                  m_memory_order;
    static constexpr size_t MAX_MEMORY = 200;

    // Async think threads
    std::vector<std::thread> m_think_threads;
    std::mutex               m_thread_mutex;

    // Stats
    mutable std::mutex m_stats_mutex;
    Stats              m_stats;

    // Internal message processing loop
    void ProcessMessageQueue();
    void UpdateStats(bool think_success, double latency_ms);

    static const char* MOD;
    static std::atomic<uint64_t> s_id_counter;
};

} // namespace TerraEngine
