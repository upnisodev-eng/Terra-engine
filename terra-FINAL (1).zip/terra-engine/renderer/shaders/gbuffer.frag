// ============================================================
// TERRA ENGINE — GBUFFER FRAGMENT SHADER
// gbuffer.frag
// ============================================================
// Writes PBR material data to GBuffer.
// RT0: albedo.rgb + metallic.a
// RT1: normal.rgb + roughness.a
// RT2: emissive.rgb + ambient_occlusion.a
// ============================================================

#version 460

layout(location = 0) in vec3 in_world_pos;
layout(location = 1) in vec3 in_normal;
layout(location = 2) in vec2 in_uv;
layout(location = 3) in vec4 in_tangent;
layout(location = 4) in vec4 in_color;
layout(location = 5) in float in_depth;

layout(location = 0) out vec4 out_albedo_metallic;
layout(location = 1) out vec4 out_normal_roughness;
layout(location = 2) out vec4 out_emissive_ao;

// PBR textures
layout(set = 1, binding = 0) uniform sampler2D tex_albedo;
layout(set = 1, binding = 1) uniform sampler2D tex_normal_map;
layout(set = 1, binding = 2) uniform sampler2D tex_metallic_roughness;
layout(set = 1, binding = 3) uniform sampler2D tex_emissive;
layout(set = 1, binding = 4) uniform sampler2D tex_ao;

layout(push_constant) uniform PushConstants {
    mat4  model;
    mat4  view_proj;
    float time;
    float corruption;
} push;

layout(set = 0, binding = 0) uniform Material {
    vec4  albedo_factor;
    float metallic_factor;
    float roughness_factor;
    float emissive_intensity;
    float ao_strength;
    int   use_albedo_tex;
    int   use_normal_map;
    int   use_mr_tex;
    int   use_emissive_tex;
    int   use_ao_tex;          // FIX: was referenced in shader but not declared
} material;

// ============================================================
// Normal map — tangent to world space
// ============================================================
vec3 ApplyNormalMap(vec3 surface_normal, vec4 tangent, vec2 uv) {
    vec3 N = normalize(surface_normal);
    vec3 T = normalize(tangent.xyz);
    vec3 B = cross(N, T) * tangent.w;
    mat3 TBN = mat3(T, B, N);

    vec3 n = texture(tex_normal_map, uv).xyz * 2.0 - 1.0;
    return normalize(TBN * n);
}

// ============================================================
// Corruption effect — darkens and desaturates material
// ============================================================
vec3 ApplyCorruption(vec3 albedo, float corruption_level) {
    float grey       = dot(albedo, vec3(0.299, 0.587, 0.114));
    vec3  greyscale  = vec3(grey);
    vec3  corrupted  = mix(greyscale, vec3(0.2, 0.05, 0.3), 0.6); // purple tint
    return mix(albedo, corrupted, corruption_level);
}

void main() {
    // ── Albedo ──────────────────────────────────────────────
    vec4 albedo = material.albedo_factor * in_color;
    if (material.use_albedo_tex == 1) {
        vec4 tex = texture(tex_albedo, in_uv);
        if (tex.a < 0.1) discard;  // alpha cutout
        albedo *= tex;
    }

    // Apply corruption colour shift
    albedo.rgb = ApplyCorruption(albedo.rgb, push.corruption);

    // ── Metallic / Roughness ────────────────────────────────
    float metallic  = material.metallic_factor;
    float roughness = material.roughness_factor;
    if (material.use_mr_tex == 1) {
        vec2 mr  = texture(tex_metallic_roughness, in_uv).bg;
        metallic  *= mr.x;
        roughness *= mr.y;
    }

    // ── Normal ──────────────────────────────────────────────
    vec3 N = normalize(in_normal);
    if (material.use_normal_map == 1) {
        N = ApplyNormalMap(in_normal, in_tangent, in_uv);
    }

    // ── Emissive ────────────────────────────────────────────
    vec3 emissive = vec3(0.0);
    if (material.use_emissive_tex == 1) {
        emissive = texture(tex_emissive, in_uv).rgb
                 * material.emissive_intensity;

        // Corruption crystals pulse
        if (push.corruption > 0.3) {
            float pulse = 0.5 + 0.5 * sin(push.time * 3.0);
            emissive   *= 1.0 + push.corruption * pulse * 0.5;
        }
    }

    // ── Ambient Occlusion ───────────────────────────────────
    float ao = 1.0;
    if (material.use_ao_tex == 1) {  // Note: use_ao_tex needs adding to Material UBO
        ao = texture(tex_ao, in_uv).r;
        ao = 1.0 - (1.0 - ao) * material.ao_strength;
    }

    // ── Write GBuffer ───────────────────────────────────────
    out_albedo_metallic  = vec4(albedo.rgb, metallic);
    out_normal_roughness = vec4(N * 0.5 + 0.5, roughness); // pack normal to [0,1]
    out_emissive_ao      = vec4(emissive, ao);
}
