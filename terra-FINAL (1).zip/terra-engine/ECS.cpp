// ============================================================
// TERRA ENGINE — ECS IMPLEMENTATION
// ECS.cpp — Version 1.0.0
// ============================================================

#include "ECS.h"
#include <algorithm>
#include <stdexcept>

namespace TerraEngine {

const char* ECSWorld::MOD = "ECS";

// ============================================================
// ECS WORLD CONSTRUCTOR
// ============================================================
ECSWorld::ECSWorld() {
    m_versions.resize(MAX_ENTITIES, 0);
    m_free_list.reserve(1024);
    TLOG_INFO(MOD, "ECSWorld created — max entities: "
                 + std::to_string(MAX_ENTITIES));
}

// ============================================================
// ENTITY LIFECYCLE
// ============================================================
Entity ECSWorld::CreateEntity() {
    std::lock_guard<std::mutex> lock(m_mutex);

    Entity e;
    if (!m_free_list.empty()) {
        e = m_free_list.back();
        m_free_list.pop_back();
    } else {
        if (m_next_entity >= MAX_ENTITIES) {
            TLOG_ERR(MOD, "MAX_ENTITIES reached: " + std::to_string(MAX_ENTITIES));
            return NULL_ENTITY;
        }
        e = m_next_entity++;
    }

    m_masks[e].reset();
    return e;
}

void ECSWorld::DestroyEntity(Entity e) {
    if (e == NULL_ENTITY || e >= MAX_ENTITIES) return;

    std::lock_guard<std::mutex> lock(m_mutex);
    m_masks[e].reset();
    m_versions[e]++;
    m_free_list.push_back(e);
}

bool ECSWorld::IsAlive(Entity e) const {
    // BUG 14 FIX: old logic — !m_masks[e].none() || m_next_entity > e
    // A destroyed entity pushed to free_list still satisfies m_next_entity > e
    // so dead entities appeared alive. Fix: mask alone is the truth.
    // Mask is reset on DestroyEntity, set on AddComponent.
    if (e == NULL_ENTITY || e >= MAX_ENTITIES) return false;
    return !m_masks[e].none();
}

uint32_t ECSWorld::EntityCount() const {
    return m_next_entity - 1 - static_cast<uint32_t>(m_free_list.size());
}

ComponentMask ECSWorld::GetMask(Entity e) const {
    if (e >= MAX_ENTITIES) return ComponentMask{};
    return m_masks[e];
}

void ECSWorld::Clear() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_pools.clear();
    for (auto& mask : m_masks) mask.reset();
    m_free_list.clear();
    m_next_entity = 1;
    TLOG_INFO(MOD, "ECSWorld cleared");
}

// ============================================================
// SYSTEMS
// FIX 10: Data-oriented — iterate component arrays directly
// No virtual calls. No pointer chasing. Cache friendly.
// ============================================================
namespace Systems {

// ============================================================
// MOVEMENT SYSTEM
// Iterates TransformComponent + VelocityComponent arrays
// ============================================================
void MovementSystem(float delta_time) {
    ECS.ForEach<VelocityComponent, TransformComponent>(
        [&](Entity /*e*/, VelocityComponent& vel, TransformComponent& tr) {
            tr.x += vel.vx * delta_time;
            tr.y += vel.vy * delta_time;
            tr.z += vel.vz * delta_time;

            // Apply friction
            vel.vx *= 0.9f;
            vel.vz *= 0.9f;

            // Clamp speed
            float speed_sq = vel.vx * vel.vx + vel.vz * vel.vz;
            if (speed_sq > vel.max_speed * vel.max_speed) {
                float scale = vel.max_speed /
                    std::sqrt(speed_sq);
                vel.vx *= scale;
                vel.vz *= scale;
            }
        }
    );
}

// ============================================================
// AI SYSTEM
// Ticks AI state timers — actual decisions via AgentBrain
// ============================================================
void AISystem(float delta_time) {
    ECS.ForEach<AIStateComponent, TransformComponent>(
        [&](Entity e, AIStateComponent& ai, TransformComponent& /*tr*/) {
            ai.think_timer -= delta_time;
            if (ai.think_timer <= 0.0f) {
                ai.think_timer = ai.think_rate;
                // Post event to AI channel for this entity
                // Actual thinking handled by AgentNPC/AgentCreature
                ChannelMessage msg(
                    "ai_think",
                    std::to_string(e).c_str(),
                    ai.is_npc ? "AgentNPC" :
                    ai.is_boss ? "AgentBoss" : "AgentCreature"
                );
                ROUTER.Post(Channel::AI, msg);
            }
        }
    );
}

// ============================================================
// COMBAT SYSTEM
// ============================================================
void CombatSystem(float delta_time) {
    ECS.ForEach<CombatComponent, HealthComponent>(
        [&](Entity /*e*/, CombatComponent& combat, HealthComponent& /*health*/) {
            if (combat.cooldown_timer > 0.0f) {
                combat.cooldown_timer -= delta_time;
            }
        }
    );
}

// ============================================================
// HEALTH SYSTEM
// ============================================================
void HealthSystem(float delta_time) {
    ECS.ForEach<HealthComponent, TransformComponent>(
        [&](Entity e, HealthComponent& health, TransformComponent& /*tr*/) {
            if (!health.alive) return;

            // Regeneration
            if (health.regen_rate > 0.0f && health.hp < health.max_hp) {
                health.hp = std::min(health.max_hp,
                                     health.hp + health.regen_rate * delta_time);
            }

            // Death check
            if (health.hp <= 0.0f && health.alive) {
                health.alive = false;
                ChannelMessage msg("entity_died",
                                   std::to_string(e).c_str(),
                                   "HealthSystem");
                ROUTER.Post(Channel::COMBAT, msg);
            }
        }
    );
}

// ============================================================
// ANIMATION STATE SYSTEM
// ============================================================
void AnimationStateSystem(float delta_time) {
    ECS.ForEach<AnimationComponent, AIStateComponent>(
        [&](Entity /*e*/, AnimationComponent& anim, AIStateComponent& ai) {
            anim.anim_time += delta_time * anim.anim_speed;

            // Sync animation to AI behavior
            std::string target_anim;
            if      (ai.behavior == "idle")   target_anim = "idle";
            else if (ai.behavior == "walk")   target_anim = "walk";
            else if (ai.behavior == "run")    target_anim = "run";
            else if (ai.behavior == "attack") target_anim = "attack";
            else if (ai.behavior == "flee")   target_anim = "run";
            else if (ai.behavior == "sleep")  target_anim = "sleep";
            else if (ai.behavior == "work")   target_anim = "work";
            else                              target_anim = "idle";

            if (target_anim != anim.current_anim) {
                if (anim.blending) {
                    anim.blend_alpha += delta_time * 5.0f;
                    if (anim.blend_alpha >= 1.0f) {
                        anim.current_anim = anim.queued_anim;
                        anim.blend_alpha  = 0.0f;
                        anim.blending     = false;
                        anim.anim_time    = 0.0f;
                    }
                } else {
                    anim.queued_anim = target_anim;
                    anim.blending    = true;
                }
            }
        }
    );
}

// ============================================================
// PLAYER SYSTEM
// ============================================================
void PlayerSystem(float delta_time) {
    auto& pool = ECS.GetPool<PlayerComponent>();
    pool.ForEach([&](Entity e, PlayerComponent& player) {
        // Drain hunger and thirst
        player.hunger = std::max(0.0f, player.hunger - delta_time * 0.002f);
        player.thirst = std::max(0.0f, player.thirst - delta_time * 0.003f);

        // Stamina regen when not sprinting
        HealthComponent* health = ECS.GetComponent<HealthComponent>(e);
        if (health && health->alive) {
            if (player.stamina < player.max_stamina) {
                player.stamina = std::min(player.max_stamina,
                                          player.stamina + delta_time * 10.0f);
            }
        }

        // Low hunger/thirst hurts
        if (player.hunger < 0.1f || player.thirst < 0.1f) {
            if (health) {
                health->hp -= delta_time * 2.0f;
                if (health->hp < 20.0f) {
                    ChannelMessage msg("player_low_health",
                                       std::to_string(static_cast<int>(health->hp)).c_str(),
                                       "PlayerSystem", 2);
                    ROUTER.Post(Channel::COMBAT, msg);
                }
            }
        }

        // XP leveling
        if (player.xp >= player.xp_to_next) {
            player.xp -= player.xp_to_next;
            player.level++;
            player.xp_to_next *= 1.5f;
            player.max_stamina += 10.0f;
            if (health) health->max_hp += 20.0f;
            TLOG_INFO("PlayerSystem", "Level up: " + std::to_string(player.level));
        }
    });
}

// ============================================================
// PHYSICS SYSTEM
// ============================================================
void PhysicsSystem(float delta_time) {
    ECS.ForEach<PhysicsComponent, VelocityComponent, TransformComponent>(
        [&](Entity /*e*/,
            PhysicsComponent& phys,
            VelocityComponent& vel,
            TransformComponent& tr)
        {
            if (phys.is_kinematic) return;

            // Gravity
            if (phys.gravity && !phys.on_ground) {
                vel.vy -= 9.81f * phys.mass * delta_time;
            }

            // Ground detection (simplified — y=0 is ground)
            if (tr.y <= 0.0f && vel.vy < 0.0f) {
                tr.y       = 0.0f;
                vel.vy     = 0.0f;
                phys.on_ground = true;
            } else if (tr.y > 0.01f) {
                phys.on_ground = false;
            }

            // Friction on ground
            if (phys.on_ground) {
                vel.vx *= phys.friction;
                vel.vz *= phys.friction;
            }
        }
    );
}

} // namespace Systems

} // namespace TerraEngine
