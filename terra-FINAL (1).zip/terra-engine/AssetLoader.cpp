// ============================================================
// TERRA ENGINE — ASSET LOADER IMPLEMENTATION
// AssetLoader.cpp — Version 1.0.0
// ============================================================
// Depends on:
//   cgltf.h    — glTF/glb loader (MIT, single header)
//               https://github.com/jkuhlmann/cgltf
//   stb_image.h— image loader (MIT/Public domain)
//               https://github.com/nothings/stb
// Place these headers in project root.
// ============================================================
#include "AssetLoader.h"
#include <fstream>
#include <cstring>

// Uncomment when headers are present:
// #define CGLTF_IMPLEMENTATION
// #include "cgltf.h"
// #define STB_IMAGE_IMPLEMENTATION
// #include "stb_image.h"

namespace TerraEngine {
const char* AssetLoader::MOD = "AssetLoader";

// ============================================================
// INIT
// ============================================================
void AssetLoader::Init(int worker_threads) {
    m_shutdown.store(false);
    for (int i = 0; i < worker_threads; i++)
        m_workers.emplace_back([this] { WorkerLoop(); });
    TLOG_INFO(MOD, "Asset loader — " + std::to_string(worker_threads) + " workers");
}

void AssetLoader::Shutdown() {
    m_shutdown.store(true);
    m_queue_cv.notify_all();
    for (auto& t : m_workers) if (t.joinable()) t.join();
    m_workers.clear();
    TLOG_INFO(MOD, "Asset loader shutdown");
}

// ============================================================
// PATH RESOLUTION — all paths from Config, never hardcoded
// ============================================================
std::string AssetLoader::ResolvePath(const std::string& rel, AssetType type) const {
    switch (type) {
        case AssetType::MESH:
        case AssetType::DATA:    return TCONFIG.ModelDir()   + rel;
        case AssetType::TEXTURE: return TCONFIG.TextureDir() + rel;
        case AssetType::AUDIO:   return TCONFIG.AudioDir()   + rel;
        case AssetType::SHADER:  return TCONFIG.ShaderDir()  + rel;
    }
    return rel;
}

// ============================================================
// ASYNC WORKER LOOP
// ============================================================
void AssetLoader::WorkerLoop() {
    while (!m_shutdown.load()) {
        AsyncJob job;
        {
            std::unique_lock<std::mutex> lock(m_queue_mutex);
            m_queue_cv.wait(lock, [this] {
                return m_shutdown.load() || !m_job_queue.empty();
            });
            if (m_shutdown.load() && m_job_queue.empty()) return;
            job = std::move(m_job_queue.front());
            m_job_queue.pop();
        }

        m_current_asset = job.path;

        // Process job by type
        switch (job.type) {
            case AssetType::MESH: {
                auto data = DoLoadMesh(job.path);
                if (job.mesh_cb) job.mesh_cb(data);
                break;
            }
            case AssetType::TEXTURE: {
                auto data = DoLoadTexture(job.path, job.srgb);
                if (job.tex_cb) job.tex_cb(data);
                break;
            }
            case AssetType::DATA: {
                auto data = DoLoadModel(job.path);
                if (job.model_cb) job.model_cb(data);
                break;
            }
            default: break;
        }

        m_done_jobs.fetch_add(1);
    }
}

// ============================================================
// SYNC LOADERS
// ============================================================
std::shared_ptr<MeshData> AssetLoader::LoadMesh(const std::string& rel) {
    std::string path = ResolvePath(rel, AssetType::MESH);
    {
        std::lock_guard<std::mutex> lock(m_cache_mutex);
        auto it = m_mesh_cache.find(path);
        if (it != m_mesh_cache.end()) return it->second;
    }
    auto data = DoLoadMesh(path);
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    m_mesh_cache[path] = data;
    return data;
}

std::shared_ptr<TextureData> AssetLoader::LoadTexture(const std::string& rel, bool srgb) {
    std::string path = ResolvePath(rel, AssetType::TEXTURE);
    {
        std::lock_guard<std::mutex> lock(m_cache_mutex);
        auto it = m_tex_cache.find(path);
        if (it != m_tex_cache.end()) return it->second;
    }
    auto data = DoLoadTexture(path, srgb);
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    m_tex_cache[path] = data;
    return data;
}

std::shared_ptr<LoadedModel> AssetLoader::LoadModel(const std::string& rel) {
    std::string path = ResolvePath(rel, AssetType::MESH);
    {
        std::lock_guard<std::mutex> lock(m_cache_mutex);
        auto it = m_model_cache.find(path);
        if (it != m_model_cache.end()) return it->second;
    }
    auto data = DoLoadModel(path);
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    m_model_cache[path] = data;
    return data;
}

// ============================================================
// ASYNC LOADERS
// ============================================================
void AssetLoader::LoadMeshAsync(const std::string& path, MeshCB cb) {
    m_total_jobs.fetch_add(1);
    std::lock_guard<std::mutex> lock(m_queue_mutex);
    m_job_queue.push({ResolvePath(path, AssetType::MESH),
                      AssetType::MESH, true, cb, nullptr, nullptr});
    m_queue_cv.notify_one();
}

void AssetLoader::LoadTextureAsync(const std::string& path, TextureCB cb, bool srgb) {
    m_total_jobs.fetch_add(1);
    std::lock_guard<std::mutex> lock(m_queue_mutex);
    m_job_queue.push({ResolvePath(path, AssetType::TEXTURE),
                      AssetType::TEXTURE, srgb, nullptr, cb, nullptr});
    m_queue_cv.notify_one();
}

void AssetLoader::LoadModelAsync(const std::string& path, ModelCB cb) {
    m_total_jobs.fetch_add(1);
    std::lock_guard<std::mutex> lock(m_queue_mutex);
    m_job_queue.push({ResolvePath(path, AssetType::MESH),
                      AssetType::DATA, true, nullptr, nullptr, cb});
    m_queue_cv.notify_one();
}

// ============================================================
// DO LOAD — actual file parsing
// ============================================================
std::shared_ptr<MeshData> AssetLoader::DoLoadMesh(const std::string& path) {
    auto data = std::make_shared<MeshData>();
    data->name = path;

#ifdef CGLTF_IMPLEMENTATION
    cgltf_options opts = {};
    cgltf_data* gltf   = nullptr;
    cgltf_result r     = cgltf_parse_file(&opts, path.c_str(), &gltf);
    if (r != cgltf_result_success) {
        TLOG_ERR(MOD, "Failed to load mesh: " + path);
        return data;
    }
    cgltf_load_buffers(&opts, gltf, path.c_str());

    for (size_t m = 0; m < gltf->meshes_count; m++) {
        cgltf_mesh& mesh = gltf->meshes[m];
        for (size_t p = 0; p < mesh.primitives_count; p++) {
            cgltf_primitive& prim = mesh.primitives[p];
            // Read indices
            if (prim.indices) {
                data->indices.resize(prim.indices->count);
                for (size_t i = 0; i < prim.indices->count; i++)
                    data->indices[i] = (uint32_t)cgltf_accessor_read_index(prim.indices, i);
            }
            // Read attributes
            for (size_t a = 0; a < prim.attributes_count; a++) {
                cgltf_attribute& attr = prim.attributes[a];
                if (data->vertices.empty())
                    data->vertices.resize(attr.data->count);
                for (size_t v = 0; v < attr.data->count; v++) {
                    Vertex& vtx = data->vertices[v];
                    float tmp[4] = {};
                    cgltf_accessor_read_float(attr.data, v, tmp, 4);
                    if      (attr.type == cgltf_attribute_type_position)
                        memcpy(vtx.pos, tmp, 12);
                    else if (attr.type == cgltf_attribute_type_normal)
                        memcpy(vtx.normal, tmp, 12);
                    else if (attr.type == cgltf_attribute_type_texcoord)
                        memcpy(vtx.uv, tmp, 8);
                    else if (attr.type == cgltf_attribute_type_tangent)
                        memcpy(vtx.tangent, tmp, 16);
                    else if (attr.type == cgltf_attribute_type_color) {
                        memcpy(vtx.color, tmp, 16);
                    }
                }
            }
        }
    }
    cgltf_free(gltf);
    data->ready = true;
    TLOG_INFO(MOD, "Loaded mesh: " + path + " verts=" +
              std::to_string(data->vertices.size()));
#else
    TLOG_WARN(MOD, "cgltf not available — mesh not loaded: " + path);
    // Create a unit cube as placeholder until cgltf is added
    data->vertices = {
        {{-0.5f,-0.5f,-0.5f},{0,0,-1},{0,0},{0,0,0,1},{1,1,1,1}},
        {{ 0.5f,-0.5f,-0.5f},{0,0,-1},{1,0},{0,0,0,1},{1,1,1,1}},
        {{ 0.5f, 0.5f,-0.5f},{0,0,-1},{1,1},{0,0,0,1},{1,1,1,1}},
        {{-0.5f, 0.5f,-0.5f},{0,0,-1},{0,1},{0,0,0,1},{1,1,1,1}},
    };
    data->indices = {0,1,2, 2,3,0};
    data->ready   = true;
#endif
    return data;
}

std::shared_ptr<TextureData> AssetLoader::DoLoadTexture(const std::string& path, bool srgb) {
    auto data = std::make_shared<TextureData>();
    data->is_srgb = srgb;

#ifdef STB_IMAGE_IMPLEMENTATION
    int w, h, ch;
    uint8_t* px = stbi_load(path.c_str(), &w, &h, &ch, 4);
    if (!px) {
        TLOG_ERR(MOD, "Failed to load texture: " + path + " — " + stbi_failure_reason());
        return data;
    }
    data->width    = static_cast<uint32_t>(w);
    data->height   = static_cast<uint32_t>(h);
    data->channels = 4;
    data->pixels.assign(px, px + (w * h * 4));
    stbi_image_free(px);
    data->ready = true;
    TLOG_INFO(MOD, "Loaded texture: " + path + " " +
              std::to_string(w) + "x" + std::to_string(h));
#else
    TLOG_WARN(MOD, "stb_image not available — placeholder texture: " + path);
    // 4x4 magenta checkerboard placeholder
    data->width = data->height = 4;
    data->pixels.resize(4 * 4 * 4);
    for (int i = 0; i < 16; i++) {
        bool checker = ((i / 4 + i % 4) % 2 == 0);
        uint8_t* p = data->pixels.data() + i * 4;
        p[0] = checker ? 255 : 0;
        p[1] = 0;
        p[2] = checker ? 255 : 0;
        p[3] = 255;
    }
    data->ready = true;
#endif
    return data;
}

std::shared_ptr<LoadedModel> AssetLoader::DoLoadModel(const std::string& path) {
    auto model        = std::make_shared<LoadedModel>();
    model->path       = path;
    auto mesh         = DoLoadMesh(path);
    if (mesh) model->meshes.push_back(*mesh);
    model->ready = true;
    return model;
}

// ============================================================
// GPU UPLOAD
// ============================================================
bool AssetLoader::UploadMesh(const MeshData& data, RenderObject& out) {
    if (!data.ready || data.vertices.empty()) return false;
    return RENDERER.UploadMesh(out, data.vertices, data.indices);
}

bool AssetLoader::UploadTexture(const TextureData& data, GpuImage& out) {
    if (!data.ready || data.pixels.empty()) return false;
    return RENDERER.LoadTexture(out, data.pixels.data(),
                                data.width, data.height);
}

// ============================================================
// CACHE
// ============================================================
bool AssetLoader::IsLoaded(const std::string& path) const {
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    return m_mesh_cache.count(path) || m_tex_cache.count(path)
        || m_model_cache.count(path);
}

void AssetLoader::Evict(const std::string& path) {
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    m_mesh_cache.erase(path);
    m_tex_cache.erase(path);
    m_model_cache.erase(path);
}

void AssetLoader::EvictAll() {
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    m_mesh_cache.clear();
    m_tex_cache.clear();
    m_model_cache.clear();
}

size_t AssetLoader::CacheSize() const {
    size_t total = 0;
    std::lock_guard<std::mutex> lock(m_cache_mutex);
    for (auto& [k,v] : m_tex_cache)
        if (v) total += v->pixels.size();
    for (auto& [k,v] : m_mesh_cache)
        if (v) total += v->vertices.size() * sizeof(Vertex)
                      + v->indices.size() * sizeof(uint32_t);
    return total;
}

AssetLoader::LoadProgress AssetLoader::GetProgress() const {
    LoadProgress p;
    p.total        = m_total_jobs.load();
    p.loaded       = m_done_jobs.load();
    p.fraction     = p.total > 0 ? (float)p.loaded / p.total : 1.0f;
    p.current_asset= m_current_asset;
    return p;
}

void AssetLoader::PreloadIsland(int island_id) {
    std::string id = std::to_string(island_id);
    TLOG_INFO(MOD, "Preloading island " + id);
    LoadModelAsync("islands/island_" + id + "/terrain.glb",   nullptr);
    LoadModelAsync("islands/island_" + id + "/props.glb",     nullptr);
    LoadTextureAsync("islands/island_" + id + "/terrain.png", nullptr);
    LoadTextureAsync("islands/island_" + id + "/detail.png",  nullptr);
}

} // namespace TerraEngine
