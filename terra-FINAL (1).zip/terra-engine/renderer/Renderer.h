// ============================================================
// TERRA ENGINE — VULKAN RENDERER
// Renderer.h — Version 1.0.0
// ============================================================
// Full Vulkan deferred renderer.
// Three quality tiers: MEDIUM, HIGH, ULTRA.
// No LOW — minimum spec is medium.
//
// PIPELINE PER TIER:
//
// MEDIUM:
//   Deferred GBuffer + PBR lighting
//   Directional + point shadows (1024)
//   Basic bloom + tone mapping
//   TAA anti-aliasing
//   SSAO (8 samples)
//
// HIGH:
//   All MEDIUM +
//   Screen Space Reflections (SSR)
//   Volumetric light shafts
//   Shadow cascades (2048, 4 cascades)
//   SSAO (16 samples)
//   Depth of field
//   Subsurface scattering (vegetation)
//
// ULTRA:
//   All HIGH +
//   Volumetric clouds (raymarched)
//   GPU particle system (1M particles)
//   Ocean FFT simulation
//   Ray traced shadows (if GPU supports)
//   Motion blur
//   Chromatic aberration
//   Full volumetric fog
//   4K shadow maps
//   SSAO (32 samples)
//   Hair rendering (Kael / Sera)
// ============================================================

#pragma once

#include <vulkan/vulkan.h>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <map>
#include <mutex>
#include <atomic>

// Forward declarations to avoid heavy Vulkan includes in game layer
struct GLFWwindow;

namespace TerraEngine {

// ============================================================
// QUALITY TIER
// ============================================================
enum class QualityTier {
    MEDIUM,  // 1080p target, mid-range GPU
    HIGH,    // 1440p target, upper-mid GPU
    ULTRA    // 4K target, high-end GPU
};

// ============================================================
// QUALITY SETTINGS — all tunables in one struct
// ============================================================
struct QualitySettings {
    // Shadow settings
    int   shadow_map_size    = 2048;   // texel resolution
    int   shadow_cascades    = 2;      // cascade shadow maps
    bool  ray_traced_shadows = false;

    // SSAO
    int   ssao_samples       = 16;
    float ssao_radius        = 0.5f;

    // Bloom
    bool  bloom_enabled      = true;
    float bloom_threshold    = 1.0f;
    float bloom_intensity    = 0.04f;
    int   bloom_passes       = 5;

    // SSR
    bool  ssr_enabled        = false;
    int   ssr_steps          = 0;
    float ssr_thickness      = 0.1f;

    // Volumetrics
    bool  volumetric_clouds  = false;
    bool  volumetric_fog     = false;
    bool  volumetric_light   = false;
    int   cloud_march_steps  = 0;
    int   fog_march_steps    = 0;

    // Particles
    int   max_particles      = 100000;
    bool  gpu_particles      = false;

    // Anti-aliasing
    bool  taa_enabled        = true;
    bool  fxaa_enabled       = false;
    int   msaa_samples       = 1;

    // Post process
    bool  dof_enabled        = false;
    bool  motion_blur        = false;
    bool  chromatic_aberration = false;
    bool  subsurface_scatter = false;
    bool  hair_rendering     = false;

    // Ocean
    bool  fft_ocean          = false;
    int   ocean_fft_size     = 0;

    // Resolution scale
    float render_scale       = 1.0f;

    // Static factory methods
    static QualitySettings Medium();
    static QualitySettings High();
    static QualitySettings Ultra();
};

// ============================================================
// VERTEX LAYOUT
// ============================================================
struct Vertex {
    float pos[3];      // xyz
    float normal[3];   // xyz
    float uv[2];       // uv
    float tangent[4];  // xyzw (w = handedness)
    float color[4];    // rgba
};

// ============================================================
// GPU BUFFER
// ============================================================
struct GpuBuffer {
    VkBuffer       handle     = VK_NULL_HANDLE;
    VkDeviceMemory memory     = VK_NULL_HANDLE;
    VkDeviceSize   size       = 0;
    void*          mapped_ptr = nullptr; // for host-visible buffers
};

// ============================================================
// GPU IMAGE
// ============================================================
struct GpuImage {
    VkImage        handle      = VK_NULL_HANDLE;
    VkDeviceMemory memory      = VK_NULL_HANDLE;
    VkImageView    view        = VK_NULL_HANDLE;
    VkSampler      sampler     = VK_NULL_HANDLE;
    VkFormat       format      = VK_FORMAT_UNDEFINED;
    uint32_t       width       = 0;
    uint32_t       height      = 0;
    uint32_t       mip_levels  = 1;
};

// ============================================================
// GBUFFER — deferred rendering targets
// ============================================================
struct GBuffer {
    GpuImage albedo_metallic;   // RGB = albedo, A = metallic
    GpuImage normal_roughness;  // RGB = normal, A = roughness
    GpuImage emissive_ao;       // RGB = emissive, A = ambient occlusion
    GpuImage depth;             // depth/stencil
    VkRenderPass render_pass    = VK_NULL_HANDLE;
    VkFramebuffer framebuffer   = VK_NULL_HANDLE;
};

// ============================================================
// CAMERA
// ============================================================
struct Camera {
    float position[3]   = {0, 5, -10};
    float forward[3]    = {0, 0, 1};
    float up[3]         = {0, 1, 0};
    float fov_deg       = 75.0f;
    float near_plane    = 0.1f;
    float far_plane     = 2000.0f;
    float aspect        = 16.0f / 9.0f;
};

// ============================================================
// DIRECTIONAL LIGHT (sun / moon)
// ============================================================
struct DirectionalLight {
    float direction[3]  = {-0.5f, -1.0f, -0.5f};
    float color[3]      = {1.0f, 0.95f, 0.85f};
    float intensity     = 3.0f;
    bool  cast_shadows  = true;
};

// ============================================================
// POINT LIGHT (village lanterns, magic, fire)
// ============================================================
struct PointLight {
    float position[3]   = {0, 0, 0};
    float color[3]      = {1, 1, 1};
    float intensity     = 10.0f;
    float radius        = 15.0f;
    bool  cast_shadows  = false;
};

// ============================================================
// RENDER OBJECT — one mesh to render
// ============================================================
struct RenderObject {
    GpuBuffer vertex_buffer;
    GpuBuffer index_buffer;
    uint32_t  index_count   = 0;
    float     transform[16];     // 4x4 matrix column-major
    uint32_t  material_id   = 0;
    bool      cast_shadow   = true;
    bool      receive_shadow= true;
    bool      is_transparent= false;
    float     emissive_intensity = 0.0f;
};

// ============================================================
// RENDER FRAME — everything to render this frame
// ============================================================
struct RenderFrame {
    Camera                      camera;
    DirectionalLight            sun;
    std::vector<PointLight>     point_lights;
    std::vector<RenderObject*>  objects;
    std::vector<RenderObject*>  transparent_objects;
    float                       time        = 0.0f;
    float                       delta_time  = 0.0f;
    std::string                 weather     = "clear";
    float                       corruption  = 0.0f;
    bool                        is_night    = false;
};

// ============================================================
// RENDERER STATS
// ============================================================
struct RendererStats {
    uint64_t draw_calls         = 0;
    uint64_t triangles          = 0;
    uint64_t particles_rendered = 0;
    double   gpu_time_ms        = 0.0;
    double   cpu_time_ms        = 0.0;
    int      fps                = 0;
};

// ============================================================
// RENDERER — main class
// ============================================================
class Renderer {
public:
    static Renderer& Get() {
        static Renderer instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init / Shutdown
    // --------------------------------------------------------
    bool Init(void* window_handle,     // GLFWwindow*
              int   width,
              int   height,
              QualityTier tier = QualityTier::HIGH);

    void Shutdown();
    void OnResize(int width, int height);

    // --------------------------------------------------------
    // Per-frame rendering
    // --------------------------------------------------------
    void BeginFrame (const RenderFrame& frame);
    void EndFrame   ();

    // --------------------------------------------------------
    // Quality control
    // --------------------------------------------------------
    void            SetQuality(QualityTier tier);
    QualityTier     GetQuality()   const { return m_tier; }
    QualitySettings GetSettings()  const { return m_settings; }
    void            SetCustomSettings(const QualitySettings& s);

    // --------------------------------------------------------
    // Resource creation
    // --------------------------------------------------------
    bool CreateBuffer(GpuBuffer& buf,
                      VkDeviceSize size,
                      VkBufferUsageFlags usage,
                      bool host_visible = false);

    bool CreateImage (GpuImage& img,
                      uint32_t w, uint32_t h,
                      VkFormat format,
                      VkImageUsageFlags usage,
                      uint32_t mip_levels = 1);

    bool UploadMesh  (RenderObject& obj,
                      const std::vector<Vertex>& verts,
                      const std::vector<uint32_t>& indices);

    bool LoadTexture (GpuImage& img,
                      const std::string& filepath);

    bool LoadTexture (GpuImage& img,
                      const uint8_t* data,
                      uint32_t w, uint32_t h,
                      VkFormat format = VK_FORMAT_R8G8B8A8_SRGB);

    void DestroyBuffer(GpuBuffer& buf);
    void DestroyImage (GpuImage& img);
    void DestroyObject(RenderObject& obj);

    // --------------------------------------------------------
    // Shader management
    // --------------------------------------------------------
    VkShaderModule  LoadShader  (const std::string& spirv_path);
    VkPipeline      GetPipeline (const std::string& name);

    // --------------------------------------------------------
    // Debug
    // --------------------------------------------------------
    RendererStats GetStats()  const { return m_stats; }
    void          PrintStats()      const;
    bool          IsReady()   const { return m_ready.load(); }

private:
    Renderer() : m_ready(false) {}
    ~Renderer() { if (m_ready.load()) Shutdown(); }

    // --------------------------------------------------------
    // Vulkan core objects
    // --------------------------------------------------------
    VkInstance               m_instance        = VK_NULL_HANDLE;
    VkPhysicalDevice         m_gpu             = VK_NULL_HANDLE;
    VkDevice                 m_device          = VK_NULL_HANDLE;
    VkSurfaceKHR             m_surface         = VK_NULL_HANDLE;
    VkSwapchainKHR           m_swapchain       = VK_NULL_HANDLE;
    VkQueue                  m_graphics_queue  = VK_NULL_HANDLE;
    VkQueue                  m_present_queue   = VK_NULL_HANDLE;
    VkQueue                  m_compute_queue   = VK_NULL_HANDLE;
    VkCommandPool            m_cmd_pool        = VK_NULL_HANDLE;
    VkDescriptorPool         m_desc_pool       = VK_NULL_HANDLE;

    uint32_t m_graphics_family  = 0;
    uint32_t m_present_family   = 0;
    uint32_t m_compute_family   = 0;

    // --------------------------------------------------------
    // Swapchain
    // --------------------------------------------------------
    static constexpr int FRAMES_IN_FLIGHT = 2;

    struct SwapchainFrame {
        VkImage         image           = VK_NULL_HANDLE;
        VkImageView     view            = VK_NULL_HANDLE;
        VkFramebuffer   framebuffer     = VK_NULL_HANDLE;
        VkCommandBuffer cmd             = VK_NULL_HANDLE;
        VkSemaphore     image_ready     = VK_NULL_HANDLE;
        VkSemaphore     render_done     = VK_NULL_HANDLE;
        VkFence         in_flight       = VK_NULL_HANDLE;
    };

    std::vector<SwapchainFrame> m_frames;
    VkFormat                    m_swapchain_format  = VK_FORMAT_UNDEFINED;
    VkExtent2D                  m_swapchain_extent  = {0, 0};
    uint32_t                    m_frame_index       = 0;
    uint32_t                    m_image_index       = 0;

    // --------------------------------------------------------
    // Render passes and pipelines
    // --------------------------------------------------------
    GBuffer  m_gbuffer;
    GpuImage m_hdr_target;        // HDR lighting output
    GpuImage m_ssao_target;
    GpuImage m_shadow_map;
    GpuImage m_bloom_target;
    GpuImage m_cloud_target;      // ULTRA only
    GpuImage m_ssr_target;        // HIGH + ULTRA
    GpuImage m_taa_history;       // TAA accumulation buffer

    VkRenderPass  m_lighting_pass     = VK_NULL_HANDLE;
    VkRenderPass  m_post_process_pass = VK_NULL_HANDLE;
    VkRenderPass  m_shadow_pass       = VK_NULL_HANDLE;
    // BUG 4 FIX: Dedicated shadow framebuffer — must NOT use m_gbuffer.framebuffer
    VkFramebuffer m_shadow_framebuffer = VK_NULL_HANDLE;

    // Pipeline map — name → VkPipeline
    std::map<std::string, VkPipeline>       m_pipelines;
    std::map<std::string, VkPipelineLayout> m_pipe_layouts;
    std::map<std::string, VkShaderModule>   m_shaders;

    // --------------------------------------------------------
    // Quality
    // --------------------------------------------------------
    QualityTier     m_tier     = QualityTier::HIGH;
    QualitySettings m_settings;

    // --------------------------------------------------------
    // State
    // --------------------------------------------------------
    int               m_width  = 0;
    int               m_height = 0;
    std::atomic<bool> m_ready;
    mutable std::mutex m_mutex;
    RendererStats     m_stats;
    float             m_time   = 0.0f;

    // --------------------------------------------------------
    // Init steps
    // --------------------------------------------------------
    bool CreateInstance              ();
    bool SelectGPU                   ();
    bool CreateDevice                ();
    bool CreateSwapchain             (int w, int h);
    bool CreateCommandPools          ();
    bool CreateDescriptorPool        ();
    bool CreateRenderTargets         ();
    bool CreateRenderPasses          ();
    bool CreateFramebuffersAfterPasses(); // BUG 4+12 FIX: framebuffers require render passes to exist first
    bool CreatePipelines             ();
    bool CreateSyncObjects           ();

    // --------------------------------------------------------
    // Render passes
    // --------------------------------------------------------
    void PassShadow          (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassGBuffer         (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassSSAO            (VkCommandBuffer cmd);
    void PassLighting        (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassSSR             (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassVolumetricClouds(VkCommandBuffer cmd, const RenderFrame& frame);
    void PassVolumetricFog   (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassParticles       (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassBloom           (VkCommandBuffer cmd);
    void PassTAA             (VkCommandBuffer cmd);
    void PassPostProcess     (VkCommandBuffer cmd, const RenderFrame& frame);
    void PassUI              (VkCommandBuffer cmd);

    // --------------------------------------------------------
    // Helpers
    // --------------------------------------------------------
    uint32_t FindMemoryType  (uint32_t filter, VkMemoryPropertyFlags props);
    VkFormat FindDepthFormat ();
    bool     HasStencil      (VkFormat fmt);
    VkCommandBuffer BeginSingleCommand();
    void            EndSingleCommand  (VkCommandBuffer cmd);
    void TransitionImage(VkCommandBuffer cmd,
                         VkImage image,
                         VkImageLayout from,
                         VkImageLayout to);

    void RecreateSwapchain();
    void CleanupSwapchain ();

    static const char* MOD;
};

// ============================================================
// MACRO
// ============================================================
#define RENDERER Renderer::Get()

} // namespace TerraEngine
