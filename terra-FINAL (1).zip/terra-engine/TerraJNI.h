// ============================================================
// TERRA ENGINE — JNI BRIDGE
// TerraJNI.h — Version 1.0.0
// ============================================================
// Bridges C++ Terra Engine ↔ Java game layer.
// Used on Android (native activity) and desktop (JVM embed).
// Java calls C++ for: render, physics, AI, audio.
// C++ calls Java for: UI events, platform services.
//
// Convention: JNIEXPORT functions are called FROM Java.
//             CallJava* functions call INTO Java.
// ============================================================
#pragma once
#include <string>
#include <functional>
#include <map>
#include <mutex>

#ifdef __ANDROID__
  #include <jni.h>
  #include <android/log.h>
  #include <android/native_window.h>
  #include <android/native_window_jni.h>
#else
  // Desktop stub types when not on Android
  typedef void* JNIEnv;
  typedef void* jobject;
  typedef int   jint;
  typedef float jfloat;
  typedef bool  jboolean;
  typedef long  jlong;
  typedef const char* jstring;
  #define JNIEXPORT
  #define JNICALL
#endif

namespace TerraEngine {

// ============================================================
// JNI BRIDGE MANAGER
// ============================================================
class TerraJNI {
public:
    static TerraJNI& Get() {
        static TerraJNI instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init — call from JNI_OnLoad or MainActivity.onCreate
    // --------------------------------------------------------
    bool Init(JNIEnv* env, jobject activity);
    void Shutdown();

    // --------------------------------------------------------
    // Surface lifecycle (Android SurfaceView)
    // --------------------------------------------------------
    void OnSurfaceCreated  (JNIEnv* env, jobject surface, int w, int h);
    void OnSurfaceChanged  (int w, int h);
    void OnSurfaceDestroyed();

    // --------------------------------------------------------
    // Touch input from Java
    // --------------------------------------------------------
    void OnTouch(int pointer_id, int action, float x, float y);
    // action: 0=down 1=move 2=up

    // --------------------------------------------------------
    // Game events FROM Java → C++
    // --------------------------------------------------------
    void OnPause  ();
    void OnResume ();
    void OnBackKey();

    void SetPlayerChoice(int choice_id);      // god choice system
    void SetQualityTier(int tier);            // 0=med 1=high 2=ultra
    void SetLanguage(const std::string& lang);

    // --------------------------------------------------------
    // C++ → Java calls (engine notifies Java UI)
    // --------------------------------------------------------
    void CallJava_OnIslandEntered   (int island_id);
    void CallJava_OnGodEncountered  (const std::string& god_id);
    void CallJava_OnBossDefeated    (const std::string& god_id, int choice);
    void CallJava_OnPlayerDied      (int death_count);
    void CallJava_OnSaveComplete    (bool success);
    void CallJava_OnLoadingProgress (float fraction, const std::string& asset);
    void CallJava_ShowDialogue      (const std::string& npc_id,
                                    const std::string& text,
                                    const std::vector<std::string>& choices);
    void CallJava_UpdateHUD         (float health, float stamina,
                                    float corruption, int island);
    void CallJava_ShowNotification  (const std::string& title,
                                    const std::string& body);

    // --------------------------------------------------------
    // Event callbacks — game layer registers these
    // --------------------------------------------------------
    using VoidCB  = std::function<void()>;
    using IntCB   = std::function<void(int)>;
    using StrCB   = std::function<void(const std::string&)>;

    void OnPlayerChoiceCB (IntCB cb) { m_choice_cb  = cb; }
    void OnLanguageChangeCB(StrCB cb){ m_lang_cb    = cb; }

    // --------------------------------------------------------
    // Platform info
    // --------------------------------------------------------
    std::string GetDeviceModel()   const;
    std::string GetOSVersion()     const;
    bool        IsTablet()         const;
    float       GetScreenDPI()     const;
    bool        HasGamepad()       const;
    std::string GetLanguage()      const;

    // --------------------------------------------------------
    // Platform services
    // --------------------------------------------------------
    void OpenURL          (const std::string& url);
    void ShareText        (const std::string& text);
    void ShowRateDialog   ();
    void RequestPermission(const std::string& permission);

    bool IsAndroid() const {
#ifdef __ANDROID__
        return true;
#else
        return false;
#endif
    }

private:
    TerraJNI() : m_initialized(false) {}

    bool      m_initialized;
    // BUG 9 FIX: JNIEnv* is thread-local in Android JNI — storing it across threads causes crashes.
    // Store JavaVM* instead and call AttachCurrentThread() in each CallJava_* method.
    // JNIEnv*   m_env       = nullptr;  // REMOVED — was the bug
#ifdef __ANDROID__
    JavaVM*   m_jvm       = nullptr;   // Valid from any thread; use to get thread-local JNIEnv*
#else
    void*     m_jvm       = nullptr;   // Desktop stub — unused
#endif
    jobject   m_activity  = nullptr;

    // Cached Java method IDs (fast repeated calls)
    struct JavaMethods {
        // Fill with jmethodID on Android
        void* onIslandEntered    = nullptr;
        void* onGodEncountered   = nullptr;
        void* onBossDefeated     = nullptr;
        void* onPlayerDied       = nullptr;
        void* onSaveComplete     = nullptr;
        void* onLoadingProgress  = nullptr;
        void* showDialogue       = nullptr;
        void* updateHUD          = nullptr;
        void* showNotification   = nullptr;
    } m_methods;

    IntCB  m_choice_cb;
    StrCB  m_lang_cb;

    mutable std::mutex m_mutex;

    static const char* MOD;
};

#define JNI_BRIDGE TerraJNI::Get()

} // namespace TerraEngine

// ============================================================
// JNI EXPORTS — called from Java/Kotlin
// These are the public C API surface seen by the JVM
// ============================================================
extern "C" {
    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeInit
        (JNIEnv* env, jobject obj);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeSurfaceCreated
        (JNIEnv* env, jobject obj, jobject surface, jint width, jint height);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeSurfaceChanged
        (JNIEnv* env, jobject obj, jint width, jint height);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeSurfaceDestroyed
        (JNIEnv* env, jobject obj);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeOnTouch
        (JNIEnv* env, jobject obj, jint id, jint action, jfloat x, jfloat y);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeOnPause
        (JNIEnv* env, jobject obj);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeOnResume
        (JNIEnv* env, jobject obj);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeSetPlayerChoice
        (JNIEnv* env, jobject obj, jint choice_id);

    JNIEXPORT void JNICALL Java_com_upniso_terra_TerraEngine_nativeSetQuality
        (JNIEnv* env, jobject obj, jint tier);

    JNIEXPORT jfloat JNICALL Java_com_upniso_terra_TerraEngine_nativeGetFPS
        (JNIEnv* env, jobject obj);
}
