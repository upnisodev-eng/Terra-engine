// ============================================================
// TERRA ENGINE — ENGINE INFRASTRUCTURE
// TerraAssert.h — Version 1.0.0
// ============================================================
// FIX: Error/Assert system     (audit 3.4)
// FIX: RAII Thread wrapper     (audit 3.3)
// FIX: Agent registration race (audit 3.1)
// FIX: Frame pipeline wired    (audit 2.3)
// ============================================================

#pragma once

#include <string>
#include <functional>
#include <thread>
#include <atomic>
#include <mutex>
#include <vector>
#include <sstream>
#include <iostream>
#include <cstdlib>
#include <stdexcept>

namespace TerraEngine {

// ============================================================
// ERROR SEVERITY
// ============================================================
enum class ErrorSeverity {
    WARNING,    // Log and continue
    ERROR,      // Log and recover if possible
    FATAL       // Log and terminate
};

// ============================================================
// TERRA ASSERT + ERROR SYSTEM
// FIX 3.4: replaces bare logging with structured errors
// ============================================================
class TerraError {
public:
    static TerraError& Get() {
        static TerraError instance;
        return instance;
    }

    // Register a crash handler — called before FATAL exit
    using CrashHandler = std::function<void(const std::string& msg)>;
    void SetCrashHandler(CrashHandler handler) {
        m_crash_handler = std::move(handler);
    }

    // Report an error
    void Report(ErrorSeverity severity,
                const std::string& module,
                const std::string& message,
                const char* file   = "",
                int         line   = 0)
    {
        std::ostringstream ss;
        ss << "[" << SeverityStr(severity) << "] "
           << "[" << module << "] "
           << message;
        if (file && line > 0)
            ss << " (" << file << ":" << line << ")";

        std::string full = ss.str();

        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_error_log.push_back(full);
            if (severity >= ErrorSeverity::ERROR) m_error_count++;
        }

        std::cerr << full << "\n";

        if (severity == ErrorSeverity::FATAL) {
            if (m_crash_handler) m_crash_handler(full);
            std::terminate();
        }
    }

    int  ErrorCount() const {
        std::lock_guard<std::mutex> lock(m_mutex);
        return m_error_count;
    }

    const std::vector<std::string>& GetLog() const {
        std::lock_guard<std::mutex> lock(m_mutex);
        return m_error_log;
    }

    void Clear() {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_error_log.clear();
        m_error_count = 0;
    }

private:
    TerraError() : m_error_count(0) {}
    mutable std::mutex       m_mutex;
    std::vector<std::string> m_error_log;
    int                      m_error_count;
    CrashHandler             m_crash_handler;

    static const char* SeverityStr(ErrorSeverity s) {
        switch (s) {
            case ErrorSeverity::WARNING: return "WARN ";
            case ErrorSeverity::ERROR:   return "ERROR";
            case ErrorSeverity::FATAL:   return "FATAL";
            default:                     return "?????";
        }
    }
};

// ============================================================
// ASSERT MACROS — production grade
// ============================================================
#define TERRA_ASSERT(expr, msg) \
    do { \
        if (!(expr)) { \
            TerraEngine::TerraError::Get().Report( \
                TerraEngine::ErrorSeverity::FATAL, \
                "Assert", \
                "ASSERT FAILED: " #expr " — " msg, \
                __FILE__, __LINE__); \
        } \
    } while(0)

#define TERRA_CHECK(expr, msg) \
    do { \
        if (!(expr)) { \
            TerraEngine::TerraError::Get().Report( \
                TerraEngine::ErrorSeverity::ERROR, \
                "Check", \
                "CHECK FAILED: " #expr " — " msg, \
                __FILE__, __LINE__); \
            return; \
        } \
    } while(0)

#define TERRA_CHECK_RET(expr, msg, ret) \
    do { \
        if (!(expr)) { \
            TerraEngine::TerraError::Get().Report( \
                TerraEngine::ErrorSeverity::ERROR, \
                "Check", \
                "CHECK FAILED: " #expr " — " msg, \
                __FILE__, __LINE__); \
            return ret; \
        } \
    } while(0)

#define TERRA_WARN(msg) \
    TerraEngine::TerraError::Get().Report( \
        TerraEngine::ErrorSeverity::WARNING, \
        "Engine", msg, __FILE__, __LINE__)

#define TERRA_ERROR(msg) \
    TerraEngine::TerraError::Get().Report( \
        TerraEngine::ErrorSeverity::ERROR, \
        "Engine", msg, __FILE__, __LINE__)

#define TERRA_FATAL(msg) \
    TerraEngine::TerraError::Get().Report( \
        TerraEngine::ErrorSeverity::FATAL, \
        "Engine", msg, __FILE__, __LINE__)

// ============================================================
// RAII THREAD WRAPPER
// FIX 3.3: safe thread lifecycle — joins on destruction
// Replaces raw std::thread usage across engine
// ============================================================
class TerraThread {
public:
    TerraThread() = default;

    // Start thread with a callable
    template<typename Fn, typename... Args>
    void Start(const std::string& name, Fn&& fn, Args&&... args) {
        TERRA_ASSERT(!m_thread.joinable(),
                     "TerraThread already running — stop first");
        m_name    = name;
        m_running.store(true);
        m_thread  = std::thread(std::forward<Fn>(fn),
                                std::forward<Args>(args)...);
    }

    // Signal stop — thread must check ShouldStop()
    void RequestStop() { m_running.store(false); }

    // Wait for thread to finish — RAII safe
    void Join() {
        if (m_thread.joinable()) {
            m_thread.join();
        }
    }

    // Destructor always joins — no dangling threads
    ~TerraThread() {
        RequestStop();
        Join();
    }

    // Thread function should call this to check for stop
    bool ShouldStop() const { return !m_running.load(); }

    bool        IsRunning()  const { return m_thread.joinable() && m_running.load(); }
    std::string GetName()    const { return m_name; }

    // No copy — threads are unique
    TerraThread(const TerraThread&)            = delete;
    TerraThread& operator=(const TerraThread&) = delete;

    // Move is OK
    TerraThread(TerraThread&&)            = default;
    TerraThread& operator=(TerraThread&&) = default;

private:
    std::thread        m_thread;
    std::atomic<bool>  m_running{false};
    std::string        m_name;
};

// ============================================================
// ENGINE INIT GUARD
// FIX 3.1: prevents agent registration race condition
// Enforces: ALL agents created THEN simulation starts
// ============================================================
class EngineInitGuard {
public:
    enum class Phase {
        UNINITIALIZED,
        CREATING_AGENTS,    // agents being registered — NO messages
        AGENTS_READY,       // all agents registered — OK to send
        SIMULATION_RUNNING, // full operation
        SHUTTING_DOWN
    };

    static EngineInitGuard& Get() {
        static EngineInitGuard instance;
        return instance;
    }

    void SetPhase(Phase p) {
        m_phase.store(static_cast<int>(p));
        TLOG_INFO("EngineInit", "Phase → " + PhaseStr(p));
    }

    Phase GetPhase() const {
        return static_cast<Phase>(m_phase.load());
    }

    // Call before sending any message — returns false if not ready
    bool CanSendMessages() const {
        Phase p = GetPhase();
        return p == Phase::AGENTS_READY ||
               p == Phase::SIMULATION_RUNNING;
    }

    // Call before creating entities — returns false if not ready
    bool CanCreateEntities() const {
        return GetPhase() >= Phase::AGENTS_READY;
    }

    bool IsRunning() const {
        return GetPhase() == Phase::SIMULATION_RUNNING;
    }

    bool IsShuttingDown() const {
        return GetPhase() == Phase::SHUTTING_DOWN;
    }

    static std::string PhaseStr(Phase p) {
        switch (p) {
            case Phase::UNINITIALIZED:    return "UNINITIALIZED";
            case Phase::CREATING_AGENTS:  return "CREATING_AGENTS";
            case Phase::AGENTS_READY:     return "AGENTS_READY";
            case Phase::SIMULATION_RUNNING: return "SIMULATION_RUNNING";
            case Phase::SHUTTING_DOWN:    return "SHUTTING_DOWN";
            default:                      return "UNKNOWN";
        }
    }

private:
    EngineInitGuard() : m_phase(static_cast<int>(Phase::UNINITIALIZED)) {}
    std::atomic<int> m_phase;
};

// ============================================================
// FRAME PIPELINE
// FIX 2.3: deterministic ordered frame execution
// Replaces while(true) message loop with proper frame boundary
// ============================================================
struct FrameStats {
    uint64_t frame_id        = 0;
    float    delta_time      = 0.0f;
    double   input_ms        = 0.0;
    double   ai_ms           = 0.0;
    double   physics_ms      = 0.0;
    double   gameplay_ms     = 0.0;
    double   environment_ms  = 0.0;
    double   total_ms        = 0.0;
};

class FramePipeline {
public:
    static FramePipeline& Get() {
        static FramePipeline instance;
        return instance;
    }

    // Register a stage function
    // Stages run in ORDER of priority (lower = first)
    struct Stage {
        std::string            name;
        std::function<void(float)> fn;
        int                    order;     // 0=first 100=last
        bool                   enabled = true;
    };

    void RegisterStage(const std::string& name,
                       std::function<void(float)> fn,
                       int order)
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        // Remove existing
        m_stages.erase(
            std::remove_if(m_stages.begin(), m_stages.end(),
                [&](const Stage& s) { return s.name == name; }),
            m_stages.end()
        );
        m_stages.push_back({name, std::move(fn), order, true});
        // Sort by order
        std::sort(m_stages.begin(), m_stages.end(),
            [](const Stage& a, const Stage& b) { return a.order < b.order; });
    }

    void EnableStage (const std::string& name) { SetEnabled(name, true);  }
    void DisableStage(const std::string& name) { SetEnabled(name, false); }

    // Execute one complete frame
    // This is THE game loop tick
    FrameStats ExecuteFrame(float delta_time) {
        FrameStats stats;
        stats.frame_id   = m_frame_id.fetch_add(1);
        stats.delta_time = delta_time;

        auto t_frame_start = now();

        std::vector<Stage> stages_snap;
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            stages_snap = m_stages;
        }

        for (const Stage& stage : stages_snap) {
            if (!stage.enabled) continue;
            auto t_stage = now();
            try {
                stage.fn(delta_time);
            } catch (const std::exception& e) {
                TERRA_ERROR("Stage " + stage.name + " threw: " + e.what());
            }
            double ms = elapsed_ms(t_stage);

            // Store per-stage timing in stats
            if      (stage.name == "Input")       stats.input_ms       = ms;
            else if (stage.name == "AI")          stats.ai_ms          = ms;
            else if (stage.name == "Physics")     stats.physics_ms     = ms;
            else if (stage.name == "Gameplay")    stats.gameplay_ms    = ms;
            else if (stage.name == "Environment") stats.environment_ms = ms;
        }

        stats.total_ms = elapsed_ms(t_frame_start);
        m_last_stats   = stats;
        return stats;
    }

    // Setup default game stages — call during Init
    void SetupDefaultStages();

    FrameStats GetLastStats() const { return m_last_stats; }
    uint64_t   GetFrameId()   const { return m_frame_id.load(); }

private:
    FramePipeline() : m_frame_id(0) {}

    std::vector<Stage>     m_stages;
    mutable std::mutex     m_mutex;
    std::atomic<uint64_t>  m_frame_id;
    FrameStats             m_last_stats;

    void SetEnabled(const std::string& name, bool v) {
        std::lock_guard<std::mutex> lock(m_mutex);
        for (auto& s : m_stages) if (s.name == name) s.enabled = v;
    }

    using TimePoint = std::chrono::high_resolution_clock::time_point;
    static TimePoint now() {
        return std::chrono::high_resolution_clock::now();
    }
    static double elapsed_ms(const TimePoint& start) {
        return std::chrono::duration<double, std::milli>(
            std::chrono::high_resolution_clock::now() - start).count();
    }
};

// ============================================================
// MACROS
// ============================================================
#define ENGINE_GUARD  EngineInitGuard::Get()
#define FRAME_PIPELINE FramePipeline::Get()
#define TERRA_ERRORS  TerraError::Get()

} // namespace TerraEngine
