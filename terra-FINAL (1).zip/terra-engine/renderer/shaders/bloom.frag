// ============================================================
// TERRA ENGINE — BLOOM SHADER (DUAL KAWASE)
// bloom.frag
// ============================================================
// Dual Kawase blur — faster than Gaussian, same visual result.
// Two passes alternate: downsample + upsample.
// Passes: 4 (MEDIUM) | 6 (HIGH) | 8 (ULTRA)
// Threshold: 1.2 | 1.0 | 0.8
//
// What glows in Legends of Terra:
//   - Sera's magic rings (bright purple-cyan)
//   - Kael's gauntlet lava cracks (orange)
//   - Corruption crystals (purple pulse)
//   - Village lanterns (warm yellow)
//   - Dragon lava veins (hot orange)
//   - Aurora bands (cool green-cyan)
//   - Waterfall foam (white)
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;
layout(location = 0) out vec4 out_colour;

layout(set = 0, binding = 0) uniform sampler2D input_tex;

layout(push_constant) uniform BloomData {
    vec2  texel_size;     // 1.0 / resolution
    float threshold;      // only bright pixels bloom
    float intensity;
    int   pass;           // 0=threshold extract, 1=downsample, 2=upsample
    float filter_radius;  // upsample spread radius
} bloom;

// ============================================================
// LUMINANCE
// ============================================================
float Luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// ============================================================
// THRESHOLD EXTRACT — first pass, isolates bright areas
// ============================================================
vec3 ThresholdExtract(vec2 uv) {
    vec3  colour  = texture(input_tex, uv).rgb;
    float lum     = Luminance(colour);

    // Soft knee curve — avoids hard cutoff artifacts
    float knee    = bloom.threshold * 0.5;
    float rq      = clamp(lum - bloom.threshold + knee, 0.0, 2.0 * knee);
    rq            = (rq * rq) / (4.0 * knee + 0.00001);
    float weight  = max(rq, lum - bloom.threshold) / max(lum, 0.00001);

    return colour * weight * bloom.intensity;
}

// ============================================================
// DUAL KAWASE DOWNSAMPLE
// ============================================================
vec3 Downsample(vec2 uv) {
    vec2 t = bloom.texel_size;

    // 13-tap filter — high quality downsample
    // Centre + 4 corners + 4 edges (weighted)
    vec3 a = texture(input_tex, uv + vec2(-2.0, -2.0) * t).rgb;
    vec3 b = texture(input_tex, uv + vec2( 0.0, -2.0) * t).rgb;
    vec3 c = texture(input_tex, uv + vec2( 2.0, -2.0) * t).rgb;
    vec3 d = texture(input_tex, uv + vec2(-1.0, -1.0) * t).rgb;
    vec3 e = texture(input_tex, uv + vec2( 1.0, -1.0) * t).rgb;
    vec3 f = texture(input_tex, uv + vec2(-2.0,  0.0) * t).rgb;
    vec3 g = texture(input_tex, uv                        ).rgb;
    vec3 h = texture(input_tex, uv + vec2( 2.0,  0.0) * t).rgb;
    vec3 i = texture(input_tex, uv + vec2(-1.0,  1.0) * t).rgb;
    vec3 j = texture(input_tex, uv + vec2( 1.0,  1.0) * t).rgb;
    vec3 k = texture(input_tex, uv + vec2(-2.0,  2.0) * t).rgb;
    vec3 l = texture(input_tex, uv + vec2( 0.0,  2.0) * t).rgb;
    vec3 m = texture(input_tex, uv + vec2( 2.0,  2.0) * t).rgb;

    // Weighted sum — inner samples have higher weight
    return (d + e + i + j) * 0.5   * 0.125
         + (a + b + g + f) * 0.125 * 0.125
         + (b + c + h + g) * 0.125 * 0.125
         + (f + g + l + k) * 0.125 * 0.125
         + (g + h + m + l) * 0.125 * 0.125
         + g               * 0.25;
}

// ============================================================
// DUAL KAWASE UPSAMPLE
// ============================================================
vec3 Upsample(vec2 uv) {
    vec2 t = bloom.texel_size * bloom.filter_radius;

    // 9-tap tent filter
    vec3 accum = vec3(0.0);
    accum += texture(input_tex, uv + vec2(-t.x, -t.y)).rgb * 1.0;
    accum += texture(input_tex, uv + vec2( 0.0, -t.y)).rgb * 2.0;
    accum += texture(input_tex, uv + vec2( t.x, -t.y)).rgb * 1.0;
    accum += texture(input_tex, uv + vec2(-t.x,  0.0)).rgb * 2.0;
    accum += texture(input_tex, uv                    ).rgb * 4.0;
    accum += texture(input_tex, uv + vec2( t.x,  0.0)).rgb * 2.0;
    accum += texture(input_tex, uv + vec2(-t.x,  t.y)).rgb * 1.0;
    accum += texture(input_tex, uv + vec2( 0.0,  t.y)).rgb * 2.0;
    accum += texture(input_tex, uv + vec2( t.x,  t.y)).rgb * 1.0;
    return accum / 16.0;
}

void main() {
    vec3 result;
    if      (bloom.pass == 0) result = ThresholdExtract(in_uv);
    else if (bloom.pass == 1) result = Downsample(in_uv);
    else                      result = Upsample(in_uv);
    out_colour = vec4(result, 1.0);
}
