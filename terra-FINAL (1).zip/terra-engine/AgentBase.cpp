// ============================================================
// TERRA ENGINE — AGENT BASE IMPLEMENTATION
// AgentBase.cpp — Version 1.0.0
// ============================================================

#include "AgentBase.h"
#include "AgentBus.h"
#include <sstream>
#include <iomanip>
#include <chrono>
#include <algorithm>

namespace TerraEngine {

// ============================================================
// STATICS
// ============================================================
const char*                AgentBase::MOD = "AgentBase";
std::atomic<uint64_t>      AgentBase::s_id_counter{0};

// ============================================================
// CONSTRUCTOR
// ============================================================
AgentBase::AgentBase(const std::string& name,
                     const std::vector<std::string>& capabilities)
    : m_transformers(name)
    , m_name(name)
    , m_capabilities(capabilities)
    , m_running(false)
    , m_state(AgentState::OFFLINE)
{
    m_stats.started_at = std::chrono::steady_clock::now();
    Log(LogLevel::INFO, "Agent created — capabilities: "
                       + std::to_string(capabilities.size()));
}

// ============================================================
// DESTRUCTOR
// ============================================================
AgentBase::~AgentBase() {
    Stop();
    // Join any pending think threads
    std::lock_guard<std::mutex> lock(m_thread_mutex);
    for (auto& t : m_think_threads) {
        if (t.joinable()) t.join();
    }
}

// ============================================================
// START
// ============================================================
bool AgentBase::Start() {
    if (m_running.load()) {
        Log(LogLevel::WARNING, "Already running");
        return true;
    }

    if (!m_transformers.HasHealthy()) {
        Log(LogLevel::ERR, "Cannot start — no healthy transformers");
        m_state.store(AgentState::FAILED);
        return false;
    }

    m_running.store(true);
    m_state.store(AgentState::IDLE);
    Log(LogLevel::INFO, "Started — "
                       + std::to_string(m_transformers.HealthyCount())
                       + " transformers online");
    return true;
}

// ============================================================
// STOP
// ============================================================
void AgentBase::Stop() {
    if (!m_running.load()) return;
    m_running.store(false);
    m_state.store(AgentState::OFFLINE);
    Log(LogLevel::INFO, "Stopped");
}

// ============================================================
// TICK — called every game frame
// ============================================================
void AgentBase::Tick(float delta_time) {
    if (!m_running.load()) return;

    // Process pending messages
    ProcessMessageQueue();

    // Self heal — try to recover failed transformers
    int healthy = m_transformers.HealthyCount();
    if (healthy == 0) {
        m_state.store(AgentState::CRITICAL);
        RecoverTransformers();
    } else if (healthy < 4) {
        m_state.store(AgentState::DEGRADED);
    } else {
        if (m_state.load() != AgentState::BUSY) {
            m_state.store(AgentState::IDLE);
        }
    }

    // Agent-specific tick
    OnTick(delta_time);
}

// ============================================================
// RECEIVE — called by AgentBus
// ============================================================
void AgentBase::Receive(const AgentMessage& msg) {
    {
        std::lock_guard<std::mutex> lock(m_queue_mutex);
        m_msg_queue.push(msg);
    }

    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.messages_received++;
}

// ============================================================
// PROCESS MESSAGE QUEUE
// ============================================================
void AgentBase::ProcessMessageQueue() {
    std::unique_lock<std::mutex> lock(m_queue_mutex);

    // Process up to 10 messages per tick to avoid blocking
    int processed = 0;
    while (!m_msg_queue.empty() && processed < 10) {
        AgentMessage msg = m_msg_queue.top();
        m_msg_queue.pop();
        lock.unlock();

        m_state.store(AgentState::THINKING);
        try {
            OnMessage(msg);
        } catch (const std::exception& e) {
            Log(LogLevel::ERR, "OnMessage threw: " + std::string(e.what()));
        } catch (...) {
            Log(LogLevel::ERR, "OnMessage threw unknown exception");
        }
        m_state.store(AgentState::IDLE);

        processed++;
        lock.lock();
    }
}

// ============================================================
// SEND MESSAGE
// ============================================================
void AgentBase::Send(const std::string& to_agent,
                      const std::string& type,
                      const std::string& content,
                      MessagePriority priority)
{
    if (!m_bus) {
        Log(LogLevel::WARNING, "No bus — cannot send to " + to_agent);
        return;
    }

    AgentMessage msg;
    msg.id          = GenerateTaskId();
    msg.from_agent  = m_name;
    msg.to_agent    = to_agent;
    msg.type        = type;
    msg.content     = content;
    msg.priority    = priority;

    m_bus->Route(msg);

    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.messages_sent++;
}

// ============================================================
// BROADCAST
// ============================================================
void AgentBase::Broadcast(const std::string& type,
                           const std::string& content,
                           MessagePriority priority)
{
    if (!m_bus) {
        Log(LogLevel::WARNING, "No bus — cannot broadcast");
        return;
    }

    AgentMessage msg;
    msg.id         = GenerateTaskId();
    msg.from_agent = m_name;
    msg.to_agent   = "ALL";
    msg.type       = type;
    msg.content    = content;
    msg.priority   = priority;

    m_bus->Broadcast(msg, m_name);

    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.messages_sent++;
}

// ============================================================
// THINK — synchronous
// ============================================================
TransformerResult AgentBase::Think(const std::string& context,
                                    const std::string& question,
                                    int transformer_index,
                                    int priority)
{
    auto t_start = std::chrono::high_resolution_clock::now();

    TransformerTask task;
    task.id       = GenerateTaskId();
    task.context  = context.empty() ? GetWorldContext() : context;
    task.question = question;
    task.priority = priority;

    TransformerResult result;
    if (transformer_index >= 0) {
        result = m_transformers.ProcessOn(transformer_index, task);
    } else {
        result = m_transformers.Process(task);
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double latency = std::chrono::duration<double, std::milli>(t_end - t_start).count();

    UpdateStats(result.success, latency);

    if (!result.success) {
        Log(LogLevel::WARNING, "Think failed: " + result.error);
    }

    return result;
}

// ============================================================
// THINK ASYNC
// ============================================================
void AgentBase::ThinkAsync(const std::string& context,
                             const std::string& question,
                             std::function<void(TransformerResult)> callback,
                             int priority)
{
    std::string ctx = context.empty() ? GetWorldContext() : context;
    std::string q   = question;
    int         p   = priority;

    std::thread t([this, ctx, q, p, callback]() {
        TransformerResult result = Think(ctx, q, -1, p);
        if (callback) callback(result);
    });

    std::lock_guard<std::mutex> lock(m_thread_mutex);
    // Clean finished threads before adding new one
    m_think_threads.erase(
        std::remove_if(m_think_threads.begin(), m_think_threads.end(),
            [](std::thread& th) { return !th.joinable(); }),
        m_think_threads.end()
    );
    m_think_threads.push_back(std::move(t));
}

// ============================================================
// MEMORY
// ============================================================
void AgentBase::Remember(const std::string& key, const std::string& value) {
    std::lock_guard<std::mutex> lock(m_memory_mutex);

    if (m_memory.size() >= MAX_MEMORY && !m_memory_order.empty()) {
        m_memory.erase(m_memory_order.front());
        m_memory_order.pop_front();
    }

    bool exists = m_memory.count(key) > 0;
    m_memory[key] = value;
    if (!exists) m_memory_order.push_back(key);
}

std::string AgentBase::Recall(const std::string& key) const {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    auto it = m_memory.find(key);
    return (it != m_memory.end()) ? it->second : "";
}

bool AgentBase::Knows(const std::string& key) const {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    return m_memory.count(key) > 0;
}

void AgentBase::Forget(const std::string& key) {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    m_memory.erase(key);
    m_memory_order.erase(
        std::remove(m_memory_order.begin(), m_memory_order.end(), key),
        m_memory_order.end()
    );
}

void AgentBase::ForgetAll() {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    m_memory.clear();
    m_memory_order.clear();
}

size_t AgentBase::MemoryCount() const {
    std::lock_guard<std::mutex> lock(m_memory_mutex);
    return m_memory.size();
}

// ============================================================
// WORLD STATE
// ============================================================
void AgentBase::UpdateWorldState(const WorldState& state) {
    m_world_state = state;
    OnWorldStateChanged(state);
}

// ============================================================
// AGENT STATE
// ============================================================
AgentState AgentBase::GetState() const {
    return m_state.load();
}

bool AgentBase::IsHealthy() const {
    AgentState s = m_state.load();
    return s != AgentState::FAILED && s != AgentState::OFFLINE;
}

// ============================================================
// FAULT TOLERANCE
// ============================================================
void AgentBase::RecoverTransformers() {
    Log(LogLevel::WARNING, "Attempting transformer recovery");
    m_transformers.ResetAll();

    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.transformer_failures++;
}

int AgentBase::HealthyTransformerCount() const {
    return m_transformers.HealthyCount();
}

// ============================================================
// ADD TRANSFORMER
// ============================================================
void AgentBase::AddTransformer(std::shared_ptr<TransformerBase> t) {
    m_transformers.AddTransformer(std::move(t));
}

// ============================================================
// HELPERS
// ============================================================
std::string AgentBase::GetWorldContext() const {
    std::ostringstream ss;
    ss << "Island:"    << m_world_state.current_island
       << " Time:"     << m_world_state.time_of_day
       << " Weather:"  << m_world_state.weather
       << " Corrupt:"  << std::fixed << std::setprecision(2) << m_world_state.corruption_level
       << " PHealth:"  << m_world_state.player_health
       << " PLvl:"     << m_world_state.player_level
       << " Boss:"     << (m_world_state.boss_active ? "yes" : "no")
       << " Combat:"   << (m_world_state.player_in_combat ? "yes" : "no");
    return ss.str();
}

std::string AgentBase::GenerateTaskId() const {
    uint64_t id = s_id_counter.fetch_add(1);
    return m_name + "_" + std::to_string(id);
}

void AgentBase::Log(LogLevel level, const std::string& msg) const {
    Logger::Get().Log(level, m_name, msg);
}

AgentBase::Stats AgentBase::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}

void AgentBase::UpdateStats(bool success, double latency_ms) {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.thinks_completed++;
    if (!success) m_stats.thinks_failed++;
    double delta = latency_ms - m_stats.avg_think_ms;
    m_stats.avg_think_ms += delta / m_stats.thinks_completed;
}

} // namespace TerraEngine
