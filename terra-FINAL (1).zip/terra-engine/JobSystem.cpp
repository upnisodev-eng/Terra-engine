// ============================================================
// TERRA ENGINE — JOB SYSTEM IMPLEMENTATION
// JobSystem.cpp — Version 1.0.0
// ============================================================

#include "JobSystem.h"
#include "MessageChannels.h"
#include <chrono>
#include <sstream>
#include <fstream>
#include <cstring>

namespace TerraEngine {

const char* JobSystem::MOD         = "JobSystem";
const char* AsyncAIPipeline::MOD   = "AsyncAIPipeline";
const char* DeterministicSim::MOD  = "DeterministicSim";

// ============================================================
// JOB SYSTEM
// ============================================================
void JobSystem::Init(int thread_count) {
    if (m_running.load()) return;

    int cores = (thread_count <= 0)
        ? static_cast<int>(std::thread::hardware_concurrency())
        : thread_count;
    cores = std::max(2, std::min(cores, 16));

    m_running.store(true);
    m_active.store(0);

    for (int i = 0; i < cores; i++) {
        m_workers.emplace_back(&JobSystem::WorkerLoop, this);
    }

    TLOG_INFO(MOD, "Started with " + std::to_string(cores) + " worker threads");
}

void JobSystem::Shutdown() {
    if (!m_running.load()) return;
    m_running.store(false);
    m_cv.notify_all();
    for (auto& w : m_workers) {
        if (w.joinable()) w.join();
    }
    m_workers.clear();
    TLOG_INFO(MOD, "Shutdown — completed: " + std::to_string(m_completed.load()));
}

void JobSystem::Submit(Job job) {
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_queue.push(std::move(job));
    }
    m_cv.notify_one();
}

void JobSystem::Submit(std::function<void()> fn,
                        const std::string& name,
                        JobPriority priority)
{
    Job j;
    j.work     = std::move(fn);
    j.name     = name;
    j.priority = priority;
    Submit(std::move(j));
}

void JobSystem::WorkerLoop() {
    while (m_running.load()) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(m_mutex);
            m_cv.wait(lock, [this] {
                return !m_queue.empty() || !m_running.load();
            });
            if (!m_running.load() && m_queue.empty()) break;
            if (m_queue.empty()) continue;
            job = m_queue.top();
            m_queue.pop();
        }
        m_active.fetch_add(1);
        try {
            if (job.work) job.work();
        } catch (const std::exception& e) {
            TLOG_ERR(MOD, "Job threw: " + std::string(e.what())
                        + " job:" + job.name);
        } catch (...) {
            TLOG_ERR(MOD, "Job threw unknown exception: " + job.name);
        }
        m_active.fetch_sub(1);
        m_completed.fetch_add(1);
    }
}

void JobSystem::WaitAll() {
    while (true) {
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_queue.empty() && m_active.load() == 0) break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

int JobSystem::PendingJobs() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return static_cast<int>(m_queue.size());
}

// ============================================================
// ASYNC AI PIPELINE
// ============================================================
uint64_t AsyncAIPipeline::RequestDecision(const AIDecisionRequest& req) {
    uint64_t id = m_next_id.fetch_add(1);
    m_pending.fetch_add(1);

    AIDecisionRequest req_copy = req;
    req_copy.request_id = id;

    // Submit to job system — AI runs on background thread
    // Gameplay thread never blocks
    JOBS.Submit([this, req_copy]() {
        ProcessRequest(req_copy);
    }, "AI:" + req_copy.agent_name, JobPriority::NORMAL);

    return id;
}

void AsyncAIPipeline::ProcessRequest(AIDecisionRequest req) {
    auto t_start = std::chrono::high_resolution_clock::now();

    AIRequest ai_req;
    ai_req.model      = req.model;
    ai_req.prompt     = req.context + "\nTask: " + req.question;
    ai_req.max_tokens = 200;

    // Fallback chain
    std::vector<Model> fallbacks = {
        Model::GQ_LLAMA_FAST,
        Model::HF_MISTRAL,
        Model::HF_PHI3
    };

    // BUG 13 FIX: was AIConnector() — a temporary object that calls
    // curl_global_init/cleanup on every single AI request, concurrently.
    // libcurl docs: these must be called exactly once per process.
    // Fix: use the shared singleton — curl init happens once in constructor.
    AIResponse response = GetGlobalAI().CallWithFallback(ai_req, fallbacks);

    auto t_end = std::chrono::high_resolution_clock::now();
    double ms  = std::chrono::duration<double, std::milli>(t_end - t_start).count();

    AIDecisionResult result;
    result.request_id  = req.request_id;
    result.agent_name  = req.agent_name;
    result.output      = response.text;
    result.success     = response.success;
    result.latency_ms  = ms;

    {
        std::lock_guard<std::mutex> lock(m_results_mutex);
        m_results[req.request_id] = result;
    }
    m_pending.fetch_sub(1);
}

const AIDecisionResult* AsyncAIPipeline::PollResult(uint64_t request_id) {
    std::lock_guard<std::mutex> lock(m_results_mutex);
    auto it = m_results.find(request_id);
    if (it == m_results.end()) return nullptr;
    return &it->second;
}

AIDecisionResult AsyncAIPipeline::WaitResult(uint64_t request_id,
                                               float timeout_seconds)
{
    auto deadline = std::chrono::steady_clock::now()
                  + std::chrono::duration<float>(timeout_seconds);

    while (std::chrono::steady_clock::now() < deadline) {
        const AIDecisionResult* r = PollResult(request_id);
        if (r) return *r;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    AIDecisionResult timeout_result;
    timeout_result.request_id = request_id;
    timeout_result.success    = false;
    timeout_result.output     = "timeout";
    return timeout_result;
}

bool AsyncAIPipeline::HasPendingResults() const {
    std::lock_guard<std::mutex> lock(m_results_mutex);
    return !m_results.empty();
}

std::vector<AIDecisionResult> AsyncAIPipeline::DrainResults() {
    std::lock_guard<std::mutex> lock(m_results_mutex);
    std::vector<AIDecisionResult> out;
    out.reserve(m_results.size());
    for (auto& [id, r] : m_results) out.push_back(r);
    m_results.clear();
    return out;
}

void AsyncAIPipeline::Tick() {
    // Process ready results — route to correct agent via message channel
    auto results = DrainResults();
    for (const auto& r : results) {
        if (!r.success) continue;
        ChannelMessage msg(
            "ai_decision_ready",
            r.output.substr(0, 127).c_str(),
            r.agent_name.c_str(),
            3
        );
        ROUTER.Post(Channel::AI, msg);
    }
}

// ============================================================
// DETERMINISTIC SIM
// ============================================================
void DeterministicSim::Tick(float real_delta_time) {
    m_sim_time      += real_delta_time;
    m_physics_acc   += real_delta_time;
    m_ai_acc        += real_delta_time;
    m_eco_acc       += real_delta_time;

    // Fixed physics steps — up to 4 catch-up steps
    int physics_steps = 0;
    while (m_physics_acc >= PHYSICS_DT && physics_steps < 4) {
        // Physics systems
        Systems::PhysicsSystem(PHYSICS_DT);
        Systems::MovementSystem(PHYSICS_DT);
        Systems::HealthSystem(PHYSICS_DT);
        Systems::CombatSystem(PHYSICS_DT);
        m_physics_acc -= PHYSICS_DT;
        m_frame.fetch_add(1);
        physics_steps++;
    }

    // Fixed AI steps — 20Hz
    while (m_ai_acc >= AI_DT) {
        Systems::AISystem(AI_DT);
        Systems::PlayerSystem(AI_DT);
        Systems::AnimationStateSystem(AI_DT);
        AIPIPE.Tick();
        m_ai_acc -= AI_DT;
    }

    // Fixed ecosystem steps — 1Hz
    while (m_eco_acc >= ECOSYSTEM_DT) {
        // Ecosystem tick fires via message channel
        ChannelMessage msg("ecosystem_tick",
                           std::to_string(static_cast<int>(m_sim_time)).c_str(),
                           "DeterministicSim");
        ROUTER.Post(Channel::WORLD_STATE, msg);
        m_eco_acc -= ECOSYSTEM_DT;
    }

    // Record frame for replay
    if (m_recording) {
        ReplayFrame rf;
        rf.frame_id   = m_frame.load();
        rf.state_hash = ComputeStateHash();
        rf.sim_time   = m_sim_time;
        m_replay.push_back(rf);
    }
}

uint64_t DeterministicSim::ComputeStateHash() const {
    // FNV-1a hash over key entity states
    uint64_t hash = 14695981039346656037ULL;
    auto mix = [&](uint64_t v) {
        hash ^= v;
        hash *= 1099511628211ULL;
    };

    mix(m_frame.load());
    mix(static_cast<uint64_t>(m_sim_time * 1000.0f));

    // Hash player positions
    auto players = ECS.Query<PlayerComponent>();
    for (Entity e : players) {
        TransformComponent* tr = ECS.GetComponent<TransformComponent>(e);
        HealthComponent*    hp = ECS.GetComponent<HealthComponent>(e);
        if (tr) {
            mix(static_cast<uint64_t>(tr->x * 100));
            mix(static_cast<uint64_t>(tr->z * 100));
        }
        if (hp) mix(static_cast<uint64_t>(hp->hp * 10));
    }

    return hash;
}

void DeterministicSim::StartRecording() {
    m_replay.clear();
    m_recording = true;
    TLOG_INFO(MOD, "Replay recording started");
}

void DeterministicSim::StopRecording() {
    m_recording = false;
    TLOG_INFO(MOD, "Replay recording stopped — frames: "
                 + std::to_string(m_replay.size()));
}

bool DeterministicSim::SaveReplay(const std::string& filepath) const {
    std::ofstream f(filepath, std::ios::binary);
    if (!f.is_open()) return false;
    uint32_t count = static_cast<uint32_t>(m_replay.size());
    f.write(reinterpret_cast<const char*>(&count), sizeof(count));
    for (const auto& rf : m_replay) {
        f.write(reinterpret_cast<const char*>(&rf), sizeof(rf));
    }
    return true;
}

bool DeterministicSim::LoadReplay(const std::string& filepath) {
    std::ifstream f(filepath, std::ios::binary);
    if (!f.is_open()) return false;
    uint32_t count = 0;
    f.read(reinterpret_cast<char*>(&count), sizeof(count));
    m_replay.resize(count);
    for (auto& rf : m_replay) {
        f.read(reinterpret_cast<char*>(&rf), sizeof(rf));
    }
    m_playback_idx = 0;
    return true;
}

void DeterministicSim::PlaybackTick() {
    if (m_playback_idx >= m_replay.size()) return;
    const ReplayFrame& rf = m_replay[m_playback_idx++];
    m_sim_time = rf.sim_time;
}

} // namespace TerraEngine
