// ============================================================
// TERRA ENGINE — AGENT BUS IMPLEMENTATION
// AgentBus.cpp — Version 1.0.0
// ============================================================

#include "AgentBus.h"
#include <sstream>
#include <algorithm>
#include <chrono>

namespace TerraEngine {

// ============================================================
// STATIC
// ============================================================
const char* AgentBus::MOD = "AgentBus";

// ============================================================
// CONSTRUCTOR / DESTRUCTOR
// ============================================================
AgentBus::AgentBus()
    : m_processing(false)
{
    TLOG_INFO(MOD, "AgentBus created");
}

AgentBus::~AgentBus() {
    StopProcessingLoop();
    TLOG_INFO(MOD, "AgentBus destroyed");
}

// ============================================================
// REGISTER AGENT
// ============================================================
void AgentBus::Register(AgentBase* agent) {
    if (!agent) {
        TLOG_ERR(MOD, "Register called with null agent");
        return;
    }

    std::lock_guard<std::mutex> lock(m_agents_mutex);
    const std::string& name = agent->GetName();

    if (m_agents.count(name)) {
        TLOG_WARN(MOD, name + " already registered — replacing");
    }

    m_agents[name] = agent;
    agent->SetBus(this);
    UpdateCapabilityIndex(agent);

    TLOG_INFO(MOD, "Registered: " + name
                 + " — total agents: " + std::to_string(m_agents.size()));
}

// ============================================================
// UNREGISTER AGENT
// ============================================================
void AgentBus::Unregister(const std::string& name) {
    std::lock_guard<std::mutex> lock(m_agents_mutex);
    auto it = m_agents.find(name);
    if (it == m_agents.end()) {
        TLOG_WARN(MOD, "Cannot unregister " + name + " — not found");
        return;
    }
    if (it->second) it->second->SetBus(nullptr);
    m_agents.erase(it);

    // Remove from capability index — O(1) with unordered_set
    for (auto& [cap, agents] : m_capability_index) {
        agents.erase(name);
    }

    TLOG_INFO(MOD, "Unregistered: " + name);
}

bool AgentBus::IsRegistered(const std::string& name) const {
    std::lock_guard<std::mutex> lock(m_agents_mutex);
    return m_agents.count(name) > 0;
}

int AgentBus::AgentCount() const {
    std::lock_guard<std::mutex> lock(m_agents_mutex);
    return static_cast<int>(m_agents.size());
}

AgentBase* AgentBus::GetAgent(const std::string& name) const {
    std::lock_guard<std::mutex> lock(m_agents_mutex);
    auto it = m_agents.find(name);
    return (it != m_agents.end()) ? it->second : nullptr;
}

// ============================================================
// ROUTE — send to specific agent
// ============================================================
bool AgentBus::Route(const AgentMessage& msg) {
    // If async mode — queue the message
    if (m_processing.load()) {
        std::lock_guard<std::mutex> lock(m_queue_mutex);
        m_queue.push(msg);
        return true;
    }

    // Synchronous delivery
    DeliverMessage(msg);
    return true;
}

// ============================================================
// BROADCAST — send to all agents except sender
// BUG 12 FIX: ABBA deadlock eliminated.
// Old code held m_agents_mutex then acquired m_queue_mutex.
// Flush() holds m_queue_mutex then calls DeliverMessage which
// needs m_agents_mutex → classic ABBA deadlock.
// Fix: collect messages under agents_mutex, release it,
// then acquire queue_mutex separately. Zero lock overlap.
// ============================================================
void AgentBus::Broadcast(const AgentMessage& msg,
                          const std::string& exclude_sender)
{
    // Step 1: collect copies under agents_mutex — then release
    std::vector<AgentMessage> to_queue;
    std::vector<AgentMessage> to_deliver;
    {
        std::lock_guard<std::mutex> lock(m_agents_mutex);
        for (auto& [name, agent] : m_agents) {
            if (name == exclude_sender) continue;
            if (!agent || !agent->IsHealthy()) continue;
            AgentMessage copy = msg;
            copy.to_agent = name;
            if (m_processing.load()) to_queue.push_back(copy);
            else                     to_deliver.push_back(copy);
        }
    } // m_agents_mutex released here — no longer held

    // Step 2: queue messages — safe, agents_mutex NOT held
    if (!to_queue.empty()) {
        std::lock_guard<std::mutex> qlock(m_queue_mutex);
        for (auto& m : to_queue) m_queue.push(m);
    }

    // Step 3: deliver synchronously — agents_mutex NOT held
    for (auto& m : to_deliver) DeliverMessage(m);

    std::lock_guard<std::mutex> slock(m_stats_mutex);
    m_stats.broadcasts_sent++;
}

// ============================================================
// BROADCAST TO CAPABLE — only agents with specific capability
// FIX: was holding m_agents_mutex then calling DeliverMessage
// which tries to re-acquire m_agents_mutex = self-deadlock.
// Fix: collect agent pointers, release lock, then deliver.
// ============================================================
void AgentBus::BroadcastToCapable(const AgentMessage& msg,
                                   const std::string& capability,
                                   const std::string& exclude)
{
    // Step 1: collect targets under lock
    std::vector<std::pair<std::string, AgentBase*>> targets;
    {
        std::lock_guard<std::mutex> lock(m_agents_mutex);
        auto it = m_capability_index.find(capability);
        if (it == m_capability_index.end()) {
            TLOG_DEBUG(MOD, "No agents with capability: " + capability);
            return;
        }
        for (const std::string& name : it->second) {
            if (name == exclude) continue;
            auto agent_it = m_agents.find(name);
            if (agent_it == m_agents.end()) continue;
            if (!agent_it->second || !agent_it->second->IsHealthy()) continue;
            targets.push_back({name, agent_it->second});
        }
    } // m_agents_mutex released

    // Step 2: deliver — NO lock held
    for (auto& [name, agent] : targets) {
        AgentMessage copy = msg;
        copy.to_agent = name;
        if (m_processing.load()) {
            std::lock_guard<std::mutex> qlock(m_queue_mutex);
            m_queue.push(copy);
        } else {
            DeliverMessage(copy);
        }
    }
}

// ============================================================
// DELIVER MESSAGE — internal
// BUG D FIX: Was holding m_subs_mutex then grabbing m_agents_mutex
// inside the loop while Receive() could call Unsubscribe() = deadlock.
// Fix: snapshot both maps under their own locks, release BOTH,
// then call Receive() with zero locks held.
// ============================================================
void AgentBus::DeliverMessage(const AgentMessage& msg) {
    auto t_start = std::chrono::high_resolution_clock::now();
    bool delivered = false;

    // Step 1: find primary recipient under agents_mutex — then release
    AgentBase* primary = nullptr;
    {
        std::lock_guard<std::mutex> lock(m_agents_mutex);
        auto it = m_agents.find(msg.to_agent);
        if (it != m_agents.end() && it->second && it->second->IsHealthy())
            primary = it->second;
        else if (it == m_agents.end())
            TLOG_WARN(MOD, "Agent not found: " + msg.to_agent);
        else if (!it->second)
            TLOG_ERR(MOD, "Agent pointer null: " + msg.to_agent);
        else
            TLOG_WARN(MOD, "Agent not healthy: " + msg.to_agent + " — dropped");
    } // m_agents_mutex released

    // Step 2: deliver to primary — NO locks held
    if (primary) {
        try {
            primary->Receive(msg);
            delivered = true;
        } catch (const std::exception& e) {
            TLOG_ERR(MOD, "Delivery to " + msg.to_agent + " threw: " + e.what());
        } catch (...) {
            TLOG_ERR(MOD, "Delivery to " + msg.to_agent + " threw unknown");
        }
    }

    // Step 3: PERF FIX — two separate lock windows instead of both held together.
    // Old: held subs_mutex + agents_mutex simultaneously → serialised all delivery.
    // Fix: get filter names under subs_mutex, release it, then resolve pointers
    // under agents_mutex, release it. Two short lock windows instead of one long one.

    // Step 3a: get matching subscriber names — only subs_mutex held
    std::vector<std::string> sub_names;
    {
        std::lock_guard<std::mutex> slock(m_subs_mutex);
        for (const auto& filter : m_subscriptions) {
            if (filter.agent_name == msg.to_agent) continue;
            if (!MatchesFilter(msg, filter)) continue;
            sub_names.push_back(filter.agent_name);
        }
    } // subs_mutex released

    // Step 3b: resolve names to pointers — only agents_mutex held
    struct SubTarget { AgentBase* agent; };
    std::vector<SubTarget> targets;
    {
        std::lock_guard<std::mutex> alock(m_agents_mutex);
        for (const auto& name : sub_names) {
            auto it = m_agents.find(name);
            if (it != m_agents.end() && it->second && it->second->IsHealthy())
                targets.push_back({it->second});
        }
    } // agents_mutex released

    // Step 4: deliver to subscribers — NO locks held
    for (auto& t : targets) {
        try {
            t.agent->Receive(msg);
        } catch (const std::exception& e) {
            TLOG_ERR(MOD, "Sub delivery threw: " + std::string(e.what()));
        }
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double latency = std::chrono::duration<double, std::milli>(t_end - t_start).count();

    LogEvent(msg, delivered, latency);
    UpdateStats(delivered, latency);
}

// ============================================================
// SUBSCRIPTIONS
// ============================================================
void AgentBus::Subscribe(const MessageFilter& filter) {
    std::lock_guard<std::mutex> lock(m_subs_mutex);
    // Remove existing subscription for same agent+type
    m_subscriptions.erase(
        std::remove_if(m_subscriptions.begin(), m_subscriptions.end(),
            [&](const MessageFilter& f) {
                return f.agent_name == filter.agent_name
                    && f.type_pattern == filter.type_pattern;
            }),
        m_subscriptions.end()
    );
    m_subscriptions.push_back(filter);
    TLOG_DEBUG(MOD, filter.agent_name + " subscribed to: "
                  + (filter.type_pattern.empty() ? "ALL" : filter.type_pattern));
}

void AgentBus::Unsubscribe(const std::string& agent_name,
                             const std::string& type_pattern)
{
    std::lock_guard<std::mutex> lock(m_subs_mutex);
    m_subscriptions.erase(
        std::remove_if(m_subscriptions.begin(), m_subscriptions.end(),
            [&](const MessageFilter& f) {
                if (f.agent_name != agent_name) return false;
                if (type_pattern.empty())       return true;  // remove all
                return f.type_pattern == type_pattern;
            }),
        m_subscriptions.end()
    );
}

bool AgentBus::MatchesFilter(const AgentMessage& msg,
                               const MessageFilter& filter) const
{
    if (!filter.type_pattern.empty() && filter.type_pattern != msg.type) return false;
    if (!filter.from_filter.empty()  && filter.from_filter  != msg.from_agent) return false;
    if (static_cast<int>(msg.priority) > static_cast<int>(filter.min_priority)) return false;
    return true;
}

// ============================================================
// ASYNC PROCESSING LOOP
// ============================================================
void AgentBus::StartProcessingLoop() {
    if (m_processing.load()) {
        TLOG_WARN(MOD, "Processing loop already running");
        return;
    }
    m_processing.store(true);
    m_processing_thread = std::thread(&AgentBus::ProcessingLoop, this);
    TLOG_INFO(MOD, "Async processing loop started");
}

void AgentBus::StopProcessingLoop() {
    if (!m_processing.load()) return;
    m_processing.store(false);
    if (m_processing_thread.joinable()) {
        m_processing_thread.join();
    }
    TLOG_INFO(MOD, "Async processing loop stopped");
}

void AgentBus::ProcessingLoop() {
    TLOG_INFO(MOD, "Processing thread running");

    while (m_processing.load()) {
        Flush();
        std::this_thread::sleep_for(std::chrono::milliseconds(16)); // ~60fps
    }

    // Final flush on exit
    Flush();
    TLOG_INFO(MOD, "Processing thread exited");
}

// ============================================================
// FLUSH — process all queued messages synchronously
// ============================================================
void AgentBus::Flush() {
    std::unique_lock<std::mutex> lock(m_queue_mutex);

    // Drain the queue
    while (!m_queue.empty()) {
        AgentMessage msg = m_queue.top();
        m_queue.pop();
        lock.unlock();

        DeliverMessage(msg);

        lock.lock();
    }
}

// ============================================================
// WORLD STATE PROPAGATION
// ============================================================
void AgentBus::PropagateWorldState(const WorldState& state) {
    std::lock_guard<std::mutex> lock(m_agents_mutex);
    for (auto& [name, agent] : m_agents) {
        if (agent && agent->IsHealthy()) {
            try {
                agent->UpdateWorldState(state);
            } catch (const std::exception& e) {
                TLOG_ERR(MOD, "WorldState update to " + name
                             + " threw: " + std::string(e.what()));
            }
        }
    }
}

// ============================================================
// CAPABILITY INDEX
// ============================================================
void AgentBus::UpdateCapabilityIndex(AgentBase* agent) {
    if (!agent) return;
    for (const auto& cap : agent->GetCapabilities()) {
        m_capability_index[cap].insert(agent->GetName()); // unordered_set::insert ignores duplicates
    }
}

// ============================================================
// EVENT LOG
// ============================================================
void AgentBus::LogEvent(const AgentMessage& msg,
                         bool delivered,
                         double latency_ms)
{
    std::lock_guard<std::mutex> lock(m_log_mutex);

    if (m_event_log.size() >= MAX_LOG) {
        m_event_log.pop_front();
    }

    BusEvent event;
    event.message_id  = msg.id;
    event.from_agent  = msg.from_agent;
    event.to_agent    = msg.to_agent;
    event.type        = msg.type;
    event.delivered   = delivered;
    event.latency_ms  = latency_ms;
    event.timestamp   = std::chrono::steady_clock::now();

    m_event_log.push_back(event);
}

std::vector<BusEvent> AgentBus::GetEventLog(size_t count) const {
    std::lock_guard<std::mutex> lock(m_log_mutex);
    size_t n = std::min(count, m_event_log.size());
    return std::vector<BusEvent>(
        m_event_log.end() - n,
        m_event_log.end()
    );
}

// ============================================================
// STATS
// ============================================================
void AgentBus::UpdateStats(bool delivered, double latency_ms) {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.messages_routed++;
    if (!delivered) {
        m_stats.messages_dropped++;
        m_stats.delivery_failures++;
    }
    // Welford online average
    double delta = latency_ms - m_stats.avg_latency_ms;
    m_stats.avg_latency_ms += delta / static_cast<double>(m_stats.messages_routed);
}

AgentBus::Stats AgentBus::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}

void AgentBus::PrintStats() const {
    Stats s = GetStats();
    TLOG_INFO(MOD, "--- AgentBus Stats ---");
    TLOG_INFO(MOD, "Messages routed:   " + std::to_string(s.messages_routed));
    TLOG_INFO(MOD, "Messages dropped:  " + std::to_string(s.messages_dropped));
    TLOG_INFO(MOD, "Broadcasts:        " + std::to_string(s.broadcasts_sent));
    TLOG_INFO(MOD, "Failures:          " + std::to_string(s.delivery_failures));
    TLOG_INFO(MOD, "Avg latency:       "
                 + std::to_string(static_cast<int>(s.avg_latency_ms)) + "ms");
}

void AgentBus::PrintRegisteredAgents() const {
    std::lock_guard<std::mutex> lock(m_agents_mutex);
    TLOG_INFO(MOD, "--- Registered Agents (" + std::to_string(m_agents.size()) + ") ---");
    for (const auto& [name, agent] : m_agents) {
        std::string status = (agent && agent->IsHealthy()) ? "healthy" : "unhealthy";
        TLOG_INFO(MOD, "  " + name + " — " + status);
    }
}

} // namespace TerraEngine
