// ============================================================
// TERRA ENGINE — PBR DEFERRED LIGHTING SHADER
// lighting.frag
// ============================================================
// Full PBR deferred lighting pass.
// Reads GBuffer, applies directional + point lights.
// Cook-Torrance BRDF. Cascade shadow mapping.
// Image-Based Lighting (IBL) for environment reflections.
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;

layout(location = 0) out vec4 out_hdr;

// ── GBuffer Inputs ──────────────────────────────────────────
layout(set = 0, binding = 0) uniform sampler2D gbuf_albedo_metallic;
layout(set = 0, binding = 1) uniform sampler2D gbuf_normal_roughness;
layout(set = 0, binding = 2) uniform sampler2D gbuf_emissive_ao;
layout(set = 0, binding = 3) uniform sampler2D gbuf_depth;

// ── Shadow Maps ─────────────────────────────────────────────
layout(set = 0, binding = 4) uniform sampler2DArray shadow_cascades;

// ── IBL ─────────────────────────────────────────────────────
layout(set = 0, binding = 5) uniform samplerCube env_irradiance;   // diffuse IBL
layout(set = 0, binding = 6) uniform samplerCube env_prefiltered;  // specular IBL
layout(set = 0, binding = 7) uniform sampler2D   brdf_lut;         // BRDF lookup

// ── SSAO ────────────────────────────────────────────────────
layout(set = 0, binding = 8) uniform sampler2D ssao_map;

// ── UBOs ────────────────────────────────────────────────────
layout(set = 1, binding = 0) uniform CameraData {
    mat4  view;
    mat4  projection;
    mat4  inv_view_proj;
    vec3  position;
    float near_plane;
    float far_plane;
} camera;

layout(set = 1, binding = 1) uniform LightData {
    vec3  direction;
    float intensity;
    vec3  color;
    float _pad;
    mat4  cascade_matrices[6];
    float cascade_splits[6];
    int   cascade_count;
} sun;

struct PointLight {
    vec3  position;
    float intensity;
    vec3  color;
    float radius;
};

layout(set = 1, binding = 2) buffer PointLights {
    PointLight lights[];
    int count;
} point_lights;

layout(set = 1, binding = 3) uniform SceneData {
    float time;
    float corruption;
    float is_night;
    float fog_density;
} scene;

// ============================================================
// PBR FUNCTIONS
// ============================================================
const float PI = 3.14159265359;

// Normal Distribution Function — GGX/Trowbridge-Reitz
float D_GGX(float NdotH, float roughness) {
    float a     = roughness * roughness;
    float a2    = a * a;
    float denom = NdotH * NdotH * (a2 - 1.0) + 1.0;
    return a2 / (PI * denom * denom);
}

// Geometry Function — Smith's Schlick-GGX
float G_Smith(float NdotV, float NdotL, float roughness) {
    float r  = roughness + 1.0;
    float k  = (r * r) / 8.0;
    float g1 = NdotV / (NdotV * (1.0 - k) + k);
    float g2 = NdotL / (NdotL * (1.0 - k) + k);
    return g1 * g2;
}

// Fresnel — Schlick approximation
vec3 F_Schlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

vec3 F_SchlickRoughness(float cosTheta, vec3 F0, float roughness) {
    return F0 + (max(vec3(1.0 - roughness), F0) - F0)
              * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

// Cook-Torrance BRDF
vec3 CookTorrance(vec3 N, vec3 V, vec3 L,
                  vec3 albedo, float metallic, float roughness)
{
    vec3 H     = normalize(V + L);
    float NdotV = max(dot(N, V), 0.001);
    float NdotL = max(dot(N, L), 0.0);
    float NdotH = max(dot(N, H), 0.0);
    float HdotV = max(dot(H, V), 0.0);

    vec3 F0 = mix(vec3(0.04), albedo, metallic); // 0.04 = typical dielectric

    float D = D_GGX    (NdotH, roughness);
    float G = G_Smith  (NdotV, NdotL, roughness);
    vec3  F = F_Schlick(HdotV, F0);

    vec3  numerator   = D * G * F;
    float denominator = 4.0 * NdotV * NdotL + 0.0001;
    vec3  specular    = numerator / denominator;

    vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);
    return (kD * albedo / PI + specular) * NdotL;
}

// ============================================================
// SHADOW SAMPLING — PCF soft shadows
// ============================================================
float SampleShadow(vec3 world_pos, int cascade) {
    vec4 shadow_coord = sun.cascade_matrices[cascade] * vec4(world_pos, 1.0);
    shadow_coord.xyz /= shadow_coord.w;
    shadow_coord.xy   = shadow_coord.xy * 0.5 + 0.5;

    if (shadow_coord.z > 1.0) return 1.0; // outside far plane = lit

    // PCF — 3x3 kernel
    float shadow   = 0.0;
    vec2  texel    = 1.0 / vec2(textureSize(shadow_cascades, 0));
    float ref_depth = shadow_coord.z - 0.002; // bias

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 offset = vec2(x, y) * texel;
            float depth = texture(shadow_cascades,
                vec3(shadow_coord.xy + offset, float(cascade))).r;
            shadow += (depth < ref_depth) ? 0.0 : 1.0;
        }
    }
    return shadow / 9.0;
}

int SelectCascade(float depth) {
    for (int i = 0; i < sun.cascade_count - 1; i++) {
        if (depth < sun.cascade_splits[i]) return i;
    }
    return sun.cascade_count - 1;
}

// ============================================================
// WORLD POSITION RECONSTRUCTION FROM DEPTH
// ============================================================
vec3 ReconstructPosition(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth, 1.0);
    vec4 world = camera.inv_view_proj * clip;
    return world.xyz / world.w;
}

// ============================================================
// MAIN
// ============================================================
void main() {
    // Sample GBuffer
    vec4 albedo_metal  = texture(gbuf_albedo_metallic,  in_uv);
    vec4 normal_rough  = texture(gbuf_normal_roughness, in_uv);
    vec4 emissive_ao   = texture(gbuf_emissive_ao,      in_uv);
    float depth        = texture(gbuf_depth, in_uv).r;
    float ssao         = texture(ssao_map,   in_uv / 2.0).r;

    // Skip skybox pixels (depth = 1.0)
    if (depth >= 0.9999) {
        out_hdr = vec4(0.0, 0.0, 0.0, 1.0); // sky handled separately
        return;
    }

    // Unpack GBuffer
    vec3  albedo    = albedo_metal.rgb;
    float metallic  = albedo_metal.a;
    vec3  N         = normalize(normal_rough.rgb * 2.0 - 1.0);
    float roughness = normal_rough.a;
    vec3  emissive  = emissive_ao.rgb;
    float ao        = emissive_ao.a * ssao;

    // Reconstruct world position
    vec3 world_pos = ReconstructPosition(in_uv, depth);
    vec3 V         = normalize(camera.position - world_pos);

    // ── Directional Light (Sun / Moon) ──────────────────────
    vec3 L        = normalize(-sun.direction);
    float view_depth = (camera.view * vec4(world_pos, 1.0)).z;
    int   cascade    = SelectCascade(abs(view_depth));
    float shadow     = SampleShadow(world_pos, cascade);

    vec3 Lo = CookTorrance(N, V, L, albedo, metallic, roughness)
             * sun.color * sun.intensity * shadow;

    // ── Point Lights ────────────────────────────────────────
    for (int i = 0; i < point_lights.count; i++) {
        PointLight pl  = point_lights.lights[i];
        vec3  L_p      = normalize(pl.position - world_pos);
        float dist     = length(pl.position - world_pos);
        float atten    = 1.0 / (1.0 + 0.09 * dist + 0.032 * dist * dist);

        // Radius falloff
        float radius_att = clamp(1.0 - pow(dist / pl.radius, 4.0), 0.0, 1.0);
        radius_att       = radius_att * radius_att;

        Lo += CookTorrance(N, V, L_p, albedo, metallic, roughness)
             * pl.color * pl.intensity * atten * radius_att;
    }

    // ── IBL — Ambient (diffuse + specular) ──────────────────
    vec3  F0       = mix(vec3(0.04), albedo, metallic);
    vec3  F_amb    = F_SchlickRoughness(max(dot(N, V), 0.0), F0, roughness);
    vec3  kD_amb   = (1.0 - F_amb) * (1.0 - metallic);

    vec3  irradiance = texture(env_irradiance, N).rgb;
    vec3  diffuse_ibl = irradiance * albedo;

    float max_lod    = 9.0; // matches prefiltered env mip count
    vec3  R          = reflect(-V, N);
    vec3  prefiltered = textureLod(env_prefiltered, R,
                                   roughness * max_lod).rgb;
    vec2  brdf        = texture(brdf_lut,
                                vec2(max(dot(N, V), 0.0), roughness)).rg;
    vec3  specular_ibl = prefiltered * (F_amb * brdf.x + brdf.y);

    vec3  ambient = (kD_amb * diffuse_ibl + specular_ibl) * ao;

    // ── Night adjustment ─────────────────────────────────────
    if (scene.is_night > 0.5) {
        ambient *= 0.3; // much darker at night
        Lo      *= 0.2; // minimal sun at night (moon only)
        // Moon is a dim cool blue directional light — add it
        vec3 moon_dir    = normalize(vec3(0.3, 0.8, -0.2));
        float moon_NdotL = max(dot(N, moon_dir), 0.0);
        Lo += albedo * vec3(0.4, 0.5, 0.8) * 0.3 * moon_NdotL;
    }

    // ── Final colour ─────────────────────────────────────────
    vec3 colour = ambient + Lo + emissive;

    out_hdr = vec4(colour, 1.0);
}
