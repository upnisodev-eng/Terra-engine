// ============================================================
// TERRA ENGINE — ECOSYSTEM + WORLD STREAMING
// WorldSystems.h — Version 1.0.0
// ============================================================
// FIX 8  — Ecosystem simulation: food chains, population,
//           plant growth, water flow, climate
// FIX 12 — World chunk streaming: load/unload on demand,
//           background loading, only nearby chunks active
// ============================================================

#pragma once

#include "AIConnector.h"
#include "ECS.h"
#include <string>
#include <map>
#include <vector>
#include <set>
#include <mutex>
#include <atomic>
#include <memory>
#include <functional>

namespace TerraEngine {

// ============================================================
// FIX 8 — ECOSYSTEM SIMULATION
// ============================================================

struct PlantCell {
    float growth    = 0.0f;  // 0=dead 1=full
    float water     = 0.5f;
    float fertility = 0.7f;
    bool  on_fire   = false;
    bool  corrupted = false;
    std::string type = "grass"; // grass/flower/tree/crop
};

struct AnimalPopulation {
    std::string species;
    int         count           = 0;
    int         max_capacity    = 100;
    float       birth_rate      = 0.05f;
    float       death_rate      = 0.02f;
    std::string prey_species;    // what this species eats
    std::string predator_species;
    bool        is_nocturnal    = false;
    int         island_id       = 1;
};

struct WaterBody {
    std::string id;
    float       level           = 1.0f;  // 0=dry 1=full
    float       flow_rate       = 0.1f;
    bool        is_flooded      = false;
    bool        is_frozen       = false;
    bool        is_polluted     = false;
    int         island_id       = 1;
    std::vector<std::string> connected_to; // IDs of downstream bodies
};

class EcosystemSimulation {
public:
    static EcosystemSimulation& Get() {
        static EcosystemSimulation instance;
        return instance;
    }

    void Init(int island_id);

    // Called at 1Hz by DeterministicSim
    void Tick(float delta_time, const std::string& weather,
               const std::string& time_of_day, float corruption);

    // Plant operations
    void GrowPlants     (float delta_time, float rainfall);
    void BurnPlants     (const std::string& sector);
    void CorruptPlants  (const std::string& sector, float amount);
    void RegrowAfterBurn(const std::string& sector);
    float GetVegetationDensity(int cell_x, int cell_z) const;

    // Animal population
    void   AddPopulation(const AnimalPopulation& pop);
    void   UpdatePopulations(float delta_time);
    int    GetPopulation(const std::string& species) const;
    float  GetFoodAvailability(const std::string& species) const;
    void   ApplyPredation(const std::string& predator,
                          const std::string& prey);

    // Water system
    void  AddWaterBody(const WaterBody& wb);
    void  UpdateWaterFlow(float delta_time, float rainfall);
    void  FreezeWater(const std::string& water_id);
    void  ThawWater  (const std::string& water_id);
    float GetWaterLevel(const std::string& water_id) const;
    bool  IsFlooded(int cell_x, int cell_z) const;

    // Climate
    float GetTemperature() const { return m_temperature; }
    float GetHumidity()    const { return m_humidity; }
    void  UpdateClimate(const std::string& weather,
                        float corruption, float time_progress);

    // Queries
    struct EcosystemState {
        float vegetation_health  = 1.0f;
        float animal_diversity   = 1.0f;
        float water_availability = 1.0f;
        float corruption_spread  = 0.0f;
        bool  ecosystem_healthy  = true;
    };
    EcosystemState GetState() const;

private:
    EcosystemSimulation() : m_temperature(20.0f), m_humidity(0.6f),
                             m_island_id(1) {}

    int                                         m_island_id;
    std::map<int, PlantCell>                    m_plants;   // cell_key -> plant
    std::map<std::string, AnimalPopulation>     m_populations;
    std::map<std::string, WaterBody>            m_water_bodies;
    float                                       m_temperature;
    float                                       m_humidity;

    mutable std::mutex m_mutex;

    int CellKey(int x, int z) const { return x * 1000 + z; }
    void CheckPopulationCollapse();
    void TriggerFamineEvent(const std::string& species);

    static const char* MOD;
};

// ============================================================
// FIX 12 — WORLD CHUNK STREAMING
// ============================================================

static constexpr int CHUNK_SIZE      = 256;  // world units per chunk
static constexpr int LOAD_RADIUS     = 3;    // chunks to keep loaded
static constexpr int PRELOAD_RADIUS  = 5;    // chunks to preload

struct ChunkCoord {
    int x = 0;
    int z = 0;
    bool operator==(const ChunkCoord& o) const { return x==o.x && z==o.z; }
    bool operator< (const ChunkCoord& o) const {
        return x < o.x || (x == o.x && z < o.z);
    }
};

enum class ChunkState {
    UNLOADED,
    QUEUED,     // waiting to load
    LOADING,    // loading in background
    LOADED,     // fully loaded and active
    UNLOADING   // being unloaded
};

struct Chunk {
    ChunkCoord  coord;
    ChunkState  state       = ChunkState::UNLOADED;
    int         island_id   = 1;
    bool        has_village = false;
    bool        has_boss_arena = false;

    // Entity IDs living in this chunk
    std::vector<Entity> entities;

    // Terrain data (height map)
    std::array<float, CHUNK_SIZE * CHUNK_SIZE> heightmap = {};
    std::array<uint8_t, CHUNK_SIZE * CHUNK_SIZE> biome_map = {};

    // Compressed state when unloaded
    bool        dirty = false;  // needs save before unload

    float LoadProgress() const {
        return state == ChunkState::LOADED ? 1.0f : 0.0f;
    }
};

class WorldChunkStreamer {
public:
    static WorldChunkStreamer& Get() {
        static WorldChunkStreamer instance;
        return instance;
    }

    void Init(int island_id);

    // Call each frame with player world position
    void UpdateStreamingPosition(float player_x, float player_z);

    // Called by SimulationManager tick
    void Tick(float delta_time);

    // Check if a world position is in a loaded chunk
    bool IsLoaded(float x, float z) const;

    // Get chunk at world position
    Chunk* GetChunk(float x, float z);
    Chunk* GetChunk(const ChunkCoord& coord);

    // Get all loaded chunks
    std::vector<Chunk*> GetLoadedChunks();

    // Force load a chunk (blocking — use sparingly)
    bool ForceLoad(const ChunkCoord& coord);

    // Generate chunk terrain
    void GenerateChunk(Chunk& chunk);

    // Callbacks
    void OnChunkLoaded  (std::function<void(Chunk&)> cb) { m_on_loaded   = cb; }
    void OnChunkUnloaded(std::function<void(Chunk&)> cb) { m_on_unloaded = cb; }

    // Stats
    int LoadedCount()   const;
    int PendingCount()  const;

private:
    WorldChunkStreamer()
        : m_island_id(1), m_player_chunk{0,0} {}

    int         m_island_id;
    ChunkCoord  m_player_chunk;

    mutable std::mutex                      m_mutex;
    std::map<ChunkCoord, std::shared_ptr<Chunk>> m_chunks;
    std::set<ChunkCoord>                    m_load_queue;
    std::set<ChunkCoord>                    m_unload_queue;

    std::function<void(Chunk&)> m_on_loaded;
    std::function<void(Chunk&)> m_on_unloaded;

    ChunkCoord WorldToChunk(float x, float z) const;
    float      ChunkDistance(const ChunkCoord& a, const ChunkCoord& b) const;
    void       ProcessLoadQueue();
    void       ProcessUnloadQueue();
    void       LoadChunkAsync(ChunkCoord coord);
    void       UnloadChunk(ChunkCoord coord);
    void       DetermineChunksToLoad();

    static const char* MOD;
};

// ============================================================
// FIX 13 — NAVMESH PATHFINDING
// ============================================================

struct NavNode {
    int         id    = 0;
    float       x     = 0.0f;
    float       z     = 0.0f;
    bool        walkable = true;
    float       cost  = 1.0f;       // traversal cost
    std::vector<int> neighbors;
};

struct NavPath {
    std::vector<NavNode> nodes;
    float                total_cost = 0.0f;
    bool                 valid      = false;
};

class NavMesh {
public:
    static NavMesh& Get() {
        static NavMesh instance;
        return instance;
    }

    // Build navmesh from chunk terrain
    void BuildFromChunk(const Chunk& chunk);
    void RebuildArea(float x, float z, float radius);
    void MarkBlocked(float x, float z, float radius);
    void MarkWalkable(float x, float z, float radius);

    // Pathfinding — A* algorithm
    NavPath FindPath(float from_x, float from_z,
                     float to_x,   float to_z);

    // Flow field — for crowd simulation
    std::vector<std::pair<float,float>> GetFlowField(
        float target_x, float target_z, float radius);

    // Check if position is reachable
    bool IsReachable(float from_x, float from_z,
                     float to_x,   float to_z) const;

    // Find nearest walkable position
    std::pair<float,float> NearestWalkable(float x, float z) const;

    int  NodeCount()   const;
    void Clear();

private:
    NavMesh() {}

    std::vector<NavNode>     m_nodes;
    std::map<int, int>       m_grid;  // grid_key -> node_id
    mutable std::mutex       m_mutex;

    static constexpr float NAV_CELL = 2.0f; // 2 world units per nav cell

    int   GridKey(int gx, int gz) const { return gx * 100000 + gz; }
    int   WorldToGrid(float x) const {
        return static_cast<int>(x / NAV_CELL);
    }
    float Heuristic(const NavNode& a, const NavNode& b) const;
    void  ReconstructPath(const std::map<int,int>& came_from,
                          int start_id, int end_id,
                          NavPath& path) const;

    static const char* MOD;
};

// ============================================================
// MACROS
// ============================================================
// BUG 15 FIX: WorldSystems is a filename, not a namespace
// EcosystemSimulation lives directly in TerraEngine namespace
#define ECOSYSTEM EcosystemSimulation::Get()
#define STREAMER  WorldChunkStreamer::Get()
#define NAVMESH   NavMesh::Get()

} // namespace TerraEngine
