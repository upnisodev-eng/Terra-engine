// ============================================================
// TERRA ENGINE — TRANSFORMER BASE HEADER
// TransformerBase.h — Version 1.0.0
// ============================================================
// Every agent contains 4 transformers.
// Each transformer handles one domain of the agent's logic.
// If one transformer fails the other 3 compensate.
// This file defines the base class all transformers inherit.
// ============================================================

#pragma once

#include "AIConnector.h"
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <chrono>
#include <deque>
#include <atomic>

namespace TerraEngine {

// ============================================================
// TRANSFORMER STATE
// ============================================================
enum class TransformerState {
    IDLE,       // Waiting for input
    THINKING,   // Processing a task
    RESPONDING, // Returning a result
    FAILED,     // Encountered an error
    RECOVERING  // Recovering from failure
};

// ============================================================
// TRANSFORMER TASK
// Represents one unit of work sent to a transformer
// ============================================================
struct TransformerTask {
    std::string id;           // Unique task ID
    std::string context;      // World context
    std::string question;     // What to decide
    int         priority = 5; // 1=highest 10=lowest
    float       timeout  = 5.0f; // seconds
    std::chrono::steady_clock::time_point created_at;

    TransformerTask() : created_at(std::chrono::steady_clock::now()) {}
};

// ============================================================
// TRANSFORMER RESULT
// ============================================================
struct TransformerResult {
    bool        success      = false;
    std::string output;
    std::string error;
    std::string task_id;
    int         transformer_index = -1;
    float       confidence   = 0.0f; // 0.0 to 1.0
    double      latency_ms   = 0.0;
};

// ============================================================
// TRANSFORMER BASE CLASS
// ============================================================
class TransformerBase {
public:
    // --------------------------------------------------------
    // Constructor
    // index     — which of the 4 transformers this is (0-3)
    // domain    — what this transformer specialises in
    // agent_name— name of parent agent (for logging)
    // model     — which AI model this transformer uses
    // --------------------------------------------------------
    TransformerBase(int index,
                    const std::string& domain,
                    const std::string& agent_name,
                    Model model = Model::HF_PHI3);

    virtual ~TransformerBase() = default;

    // --------------------------------------------------------
    // Core processing — override in specialised transformers
    // --------------------------------------------------------
    virtual TransformerResult Process(const TransformerTask& task);

    // --------------------------------------------------------
    // Health and fault tolerance
    // --------------------------------------------------------
    bool               IsHealthy()    const;
    TransformerState   GetState()     const;
    int                GetIndex()     const { return m_index; }
    const std::string& GetDomain()    const { return m_domain; }
    int                GetFailCount() const { return m_fail_count; }

    // --------------------------------------------------------
    // Fault recovery — called by agent when transformer fails
    // --------------------------------------------------------
    void Reset();
    void MarkFailed(const std::string& reason);

    // --------------------------------------------------------
    // Memory — each transformer remembers recent decisions
    // --------------------------------------------------------
    void        AddMemory(const std::string& key,
                          const std::string& value);
    std::string GetMemory(const std::string& key) const;
    void        ClearMemory();
    size_t      MemorySize() const;

    // --------------------------------------------------------
    // Stats
    // --------------------------------------------------------
    struct Stats {
        int    tasks_processed = 0;
        int    tasks_failed    = 0;
        double avg_latency_ms  = 0.0;
        int    recovery_count  = 0;
    };
    Stats GetStats() const;

protected:
    // Called inside Process() — builds the AI prompt
    virtual std::string BuildPrompt(const TransformerTask& task) const;

    // Called after AI responds — parse and validate output
    virtual TransformerResult ParseResponse(const AIResponse& response,
                                             const TransformerTask& task) const;

    // Access to AI connector — shared across all transformers
    static AIConnector& GetAI();

    // Logger helper
    void Log(LogLevel level, const std::string& msg) const;

    int         m_index;
    std::string m_domain;
    std::string m_agent_name;
    Model       m_model;

private:
    std::atomic<TransformerState>   m_state;
    std::atomic<int>                m_fail_count;
    std::string                     m_last_error;

    // Memory store — thread safe
    mutable std::mutex                       m_memory_mutex;
    std::map<std::string, std::string>       m_memory;
    std::deque<std::pair<std::string,std::string>> m_memory_order;
    static constexpr size_t MAX_MEMORY = 50;

    // Stats — thread safe
    mutable std::mutex m_stats_mutex;
    Stats              m_stats;

    void UpdateStats(bool success, double latency_ms);
};

// ============================================================
// TRANSFORMER POOL
// BUG 11 FIX: cap raised from 4 → 8
// AgentEnvironment needs 6, AgentCreature needs 6
// With cap=4, T4 and T5 were silently dropped every time
// ============================================================
class TransformerPool {
public:
    explicit TransformerPool(const std::string& agent_name);
    ~TransformerPool() = default;

    // Add a transformer to the pool (max 8)
    void AddTransformer(std::shared_ptr<TransformerBase> transformer);

    // Process a task — tries transformers in priority order
    // If primary fails, delegates to next healthy transformer
    TransformerResult Process(const TransformerTask& task);

    // Process on specific transformer by index
    TransformerResult ProcessOn(int index, const TransformerTask& task);

    // Health check
    int  HealthyCount()  const;
    bool HasHealthy()    const;
    void ResetAll();

    // Get specific transformer
    std::shared_ptr<TransformerBase> Get(int index);
    std::shared_ptr<TransformerBase> GetHealthy(int preferred_index = 0);

    // Status
    void PrintStatus() const;

private:
    std::string m_agent_name;
    std::vector<std::shared_ptr<TransformerBase>> m_transformers;
    mutable std::mutex m_mutex;

    static const char* MOD;
};

} // namespace TerraEngine
