// ============================================================
// TERRA ENGINE — JNI BRIDGE IMPLEMENTATION
// TerraJNI.cpp — Version 1.0.0
// ============================================================
#include "TerraJNI.h"
#include "TerraCore.h"
#include "InputSystem.h"
#include "AudioSystem.h"
#include "renderer/Renderer.h"
#include "Config.h"

namespace TerraEngine {
const char* TerraJNI::MOD = "TerraJNI";

bool TerraJNI::Init(JNIEnv* env, jobject activity) {
    std::lock_guard<std::mutex> lock(m_mutex);
    // BUG 9 FIX: Store JavaVM* (thread-safe), NOT JNIEnv* (thread-local only).
    // JNIEnv* from this thread is invalid on any other thread (game, audio, save threads).
#ifdef __ANDROID__
    env->GetJavaVM(reinterpret_cast<JavaVM**>(&m_jvm));
#endif
    m_activity = activity;

#ifdef __ANDROID__
    // Cache Java method IDs for fast repeated calls
    jclass clazz = env->GetObjectClass(activity);
    // m_methods.onIslandEntered = env->GetMethodID(clazz, "onIslandEntered", "(I)V");
    // etc — fill all method IDs
    env->DeleteLocalRef(clazz);
    TLOG_INFO(MOD, "JNI bridge initialised — Android");
#else
    TLOG_INFO(MOD, "JNI bridge initialised — Desktop stub");
#endif

    m_initialized = true;
    return true;
}

void TerraJNI::Shutdown() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_jvm       = nullptr; // BUG 9 FIX: was m_env = nullptr
    m_activity  = nullptr;
    m_initialized = false;
    TLOG_INFO(MOD, "JNI bridge shutdown");
}

// ============================================================
// SURFACE LIFECYCLE
// ============================================================
void TerraJNI::OnSurfaceCreated(JNIEnv* env, jobject surface, int w, int h) {
    TLOG_INFO(MOD, "Surface created: " + std::to_string(w) + "x" + std::to_string(h));
    auto tier = static_cast<QualityTier>(TCONFIG.QualityTier());

#ifdef __ANDROID__
    ANativeWindow* window = ANativeWindow_fromSurface(env, surface);
    RENDERER.Init(window, w, h, tier);
#else
    // Desktop: window handle passed directly
    RENDERER.Init(nullptr, w, h, tier);
#endif
}

void TerraJNI::OnSurfaceChanged(int w, int h) {
    RENDERER.OnResize(w, h);
}

void TerraJNI::OnSurfaceDestroyed() {
    RENDERER.Shutdown();
}

// ============================================================
// TOUCH INPUT
// ============================================================
void TerraJNI::OnTouch(int id, int action, float x, float y) {
    // Forward to InputSystem touch buffer
    // action: 0=down 1=move 2=up
    (void)id; (void)action; (void)x; (void)y;
    // INPUT.ProcessTouchEvent(id, action, x, y);
}

// ============================================================
// LIFECYCLE
// ============================================================
void TerraJNI::OnPause() {
    AUDIO.SetBusVolume(AudioBus::MASTER, 0.0f, 1.0f);
    TERRA.OnPause();
    TLOG_INFO(MOD, "Engine paused");
}

void TerraJNI::OnResume() {
    AUDIO.SetBusVolume(AudioBus::MASTER, 1.0f, 0.5f);
    TERRA.OnResume();
    TLOG_INFO(MOD, "Engine resumed");
}

void TerraJNI::OnBackKey() {
    TERRA.FireEvent("ui_back", "", "");
}

// ============================================================
// PLAYER EVENTS → C++
// ============================================================
void TerraJNI::SetPlayerChoice(int choice_id) {
    TERRA.FireEvent("player_choice", std::to_string(choice_id), "");
    if (m_choice_cb) m_choice_cb(choice_id);
}

void TerraJNI::SetQualityTier(int tier) {
    TCONFIG.Set("gfx.quality", tier);
    RENDERER.SetQuality(static_cast<QualityTier>(tier));
}

void TerraJNI::SetLanguage(const std::string& lang) {
    TCONFIG.Set("game.language", lang);
    if (m_lang_cb) m_lang_cb(lang);
}

// ============================================================
// C++ → JAVA CALLS
// ============================================================
void TerraJNI::CallJava_OnIslandEntered(int island_id) {
    TLOG_INFO(MOD, "-> Java: onIslandEntered(" + std::to_string(island_id) + ")");
#ifdef __ANDROID__
    // BUG 9 FIX: Get thread-local JNIEnv* via JavaVM — never use cached m_env across threads
    if (!m_jvm || !m_activity || !m_methods.onIslandEntered) { AUDIO.OnEnterSafeZone(island_id); return; }
    JNIEnv* env = nullptr;
    m_jvm->AttachCurrentThread(&env, nullptr);
    if (env) {
        // env->CallVoidMethod(m_activity, (jmethodID)m_methods.onIslandEntered, island_id);
        m_jvm->DetachCurrentThread();
    }
#endif
    AUDIO.OnEnterSafeZone(island_id);
}

void TerraJNI::CallJava_OnGodEncountered(const std::string& god_id) {
    TLOG_INFO(MOD, "-> Java: onGodEncountered(" + god_id + ")");
#ifdef __ANDROID__
    // BUG 9 FIX: Attach thread to get valid JNIEnv* — cached env is thread-local, this is cross-thread
    if (!m_jvm || !m_activity) { AUDIO.OnBossFightStart(god_id); return; }
    JNIEnv* env = nullptr;
    m_jvm->AttachCurrentThread(&env, nullptr);
    if (env) {
        // jstring jid = env->NewStringUTF(god_id.c_str());
        // env->CallVoidMethod(m_activity, (jmethodID)m_methods.onGodEncountered, jid);
        // env->DeleteLocalRef(jid);
        m_jvm->DetachCurrentThread();
    }
#endif
    AUDIO.OnBossFightStart(god_id);
}

void TerraJNI::CallJava_OnBossDefeated(const std::string& god_id, int choice) {
    TLOG_INFO(MOD, "-> Java: onBossDefeated(" + god_id +
              ", choice=" + std::to_string(choice) + ")");
    AUDIO.OnBossFightEnd();
}

void TerraJNI::CallJava_OnPlayerDied(int deaths) {
    TLOG_INFO(MOD, "-> Java: onPlayerDied(count=" + std::to_string(deaths) + ")");
}

void TerraJNI::CallJava_OnSaveComplete(bool success) {
    TLOG_INFO(MOD, "-> Java: onSaveComplete(" + std::string(success?"OK":"FAIL") + ")");
}

void TerraJNI::CallJava_OnLoadingProgress(float fraction, const std::string& asset) {
    // High-frequency call — only log at milestones
    if (static_cast<int>(fraction * 10) % 2 == 0)
        TLOG_DEBUG(MOD, "Loading: " + std::to_string((int)(fraction*100)) + "% " + asset);
}

void TerraJNI::CallJava_ShowDialogue(const std::string& npc_id,
                                      const std::string& text,
                                      const std::vector<std::string>& choices)
{
    TLOG_INFO(MOD, "-> Java: showDialogue(npc=" + npc_id + ")");
}

void TerraJNI::CallJava_UpdateHUD(float health, float stamina,
                                    float corruption, int island)
{
    // Called every frame — no log
    (void)health; (void)stamina; (void)corruption; (void)island;
}

void TerraJNI::CallJava_ShowNotification(const std::string& title,
                                          const std::string& body)
{
    TLOG_INFO(MOD, "Notification: " + title + " — " + body);
}

// ============================================================
// PLATFORM INFO
// ============================================================
std::string TerraJNI::GetDeviceModel() const {
#ifdef __ANDROID__
    return "Android Device";
#else
    return "Desktop";
#endif
}
std::string TerraJNI::GetOSVersion()  const { return "Unknown"; }
bool        TerraJNI::IsTablet()      const { return false; }
float       TerraJNI::GetScreenDPI()  const { return 160.0f; }
bool        TerraJNI::HasGamepad()    const { return false; }
std::string TerraJNI::GetLanguage()   const { return TCONFIG.Language(); }

void TerraJNI::OpenURL(const std::string& url)       { TLOG_INFO(MOD, "OpenURL: " + url); }
void TerraJNI::ShareText(const std::string& text)    { TLOG_INFO(MOD, "Share: " + text); }
void TerraJNI::ShowRateDialog()                      { TLOG_INFO(MOD, "RateDialog"); }
void TerraJNI::RequestPermission(const std::string& p){ TLOG_INFO(MOD, "Permission: " + p); }

} // namespace TerraEngine

// ============================================================
// JNI EXPORTS
// ============================================================
extern "C" {

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeInit(JNIEnv* env, jobject obj) {
    TerraEngine::TCONFIG.Load();
    TerraEngine::JNI_BRIDGE.Init(env, obj);
    TERRA.Init(TerraEngine::TCONFIG.EnvFile());
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeSurfaceCreated(
    JNIEnv* env, jobject obj, jobject surface, jint w, jint h)
{
    TerraEngine::JNI_BRIDGE.OnSurfaceCreated(env, surface, w, h);
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeSurfaceChanged(
    JNIEnv* env, jobject obj, jint w, jint h)
{
    TerraEngine::JNI_BRIDGE.OnSurfaceChanged(w, h);
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeSurfaceDestroyed(JNIEnv* env, jobject obj) {
    TerraEngine::JNI_BRIDGE.OnSurfaceDestroyed();
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeOnTouch(
    JNIEnv* env, jobject obj, jint id, jint action, jfloat x, jfloat y)
{
    TerraEngine::JNI_BRIDGE.OnTouch(id, action, x, y);
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeOnPause(JNIEnv* env, jobject obj) {
    TerraEngine::JNI_BRIDGE.OnPause();
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeOnResume(JNIEnv* env, jobject obj) {
    TerraEngine::JNI_BRIDGE.OnResume();
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeSetPlayerChoice(
    JNIEnv* env, jobject obj, jint choice_id)
{
    TerraEngine::JNI_BRIDGE.SetPlayerChoice(choice_id);
}

JNIEXPORT void JNICALL
Java_com_upniso_terra_TerraEngine_nativeSetQuality(
    JNIEnv* env, jobject obj, jint tier)
{
    TerraEngine::JNI_BRIDGE.SetQualityTier(tier);
}

JNIEXPORT jfloat JNICALL
Java_com_upniso_terra_TerraEngine_nativeGetFPS(JNIEnv* env, jobject obj) {
    return static_cast<jfloat>(RENDERER.GetStats().fps);
}

} // extern "C"
