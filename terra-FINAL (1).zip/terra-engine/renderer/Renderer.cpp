// ============================================================
// TERRA ENGINE — VULKAN RENDERER IMPLEMENTATION
// Renderer.cpp — Version 1.0.0
// ============================================================

#include "Renderer.h"
#include "ShaderManager.h"
#include "../AIConnector.h"
#include "../Config.h"
#include <GLFW/glfw3.h>
#include <algorithm>
#include <fstream>
#include <stdexcept>
#include <set>
#include <cstring>
#include <chrono>
#include <cmath>

namespace TerraEngine {

const char* Renderer::MOD = "Renderer";

// ============================================================
// QUALITY SETTINGS FACTORIES
// ============================================================
QualitySettings QualitySettings::Medium() {
    QualitySettings s;
    s.shadow_map_size       = 1024;
    s.shadow_cascades       = 2;
    s.ray_traced_shadows    = false;
    s.ssao_samples          = 8;
    s.ssao_radius           = 0.4f;
    s.bloom_enabled         = true;
    s.bloom_threshold       = 1.2f;
    s.bloom_intensity       = 0.03f;
    s.bloom_passes          = 4;
    s.ssr_enabled           = false;
    s.ssr_steps             = 0;
    s.volumetric_clouds     = false;
    s.volumetric_fog        = false;
    s.volumetric_light      = false;
    s.cloud_march_steps     = 0;
    s.fog_march_steps       = 0;
    s.max_particles         = 50000;
    s.gpu_particles         = false;
    s.taa_enabled           = true;
    s.msaa_samples          = 1;
    s.dof_enabled           = false;
    s.motion_blur           = false;
    s.chromatic_aberration  = false;
    s.subsurface_scatter    = false;
    s.hair_rendering        = false;
    s.fft_ocean             = false;
    s.ocean_fft_size        = 0;
    s.render_scale          = 1.0f;
    return s;
}

QualitySettings QualitySettings::High() {
    QualitySettings s       = Medium(); // inherits medium base
    s.shadow_map_size       = 2048;
    s.shadow_cascades       = 4;
    s.ssao_samples          = 16;
    s.ssao_radius           = 0.5f;
    s.bloom_threshold       = 1.0f;
    s.bloom_intensity       = 0.04f;
    s.bloom_passes          = 6;
    s.ssr_enabled           = true;
    s.ssr_steps             = 32;
    s.ssr_thickness         = 0.1f;
    s.volumetric_light      = true;
    s.fog_march_steps       = 32;
    s.max_particles         = 250000;
    s.gpu_particles         = true;
    s.dof_enabled           = true;
    s.subsurface_scatter    = true;
    s.fft_ocean             = true;
    s.ocean_fft_size        = 256;
    s.render_scale          = 1.0f;
    return s;
}

QualitySettings QualitySettings::Ultra() {
    QualitySettings s       = High(); // inherits high base
    s.shadow_map_size       = 4096;
    s.shadow_cascades       = 6;
    s.ray_traced_shadows    = true;  // if GPU supports VK_KHR_ray_tracing
    s.ssao_samples          = 32;
    s.ssao_radius           = 0.6f;
    s.bloom_threshold       = 0.8f;
    s.bloom_intensity       = 0.06f;
    s.bloom_passes          = 8;
    s.ssr_steps             = 64;
    s.volumetric_clouds     = true;
    s.volumetric_fog        = true;
    s.cloud_march_steps     = 128;
    s.fog_march_steps       = 64;
    s.max_particles         = 1000000; // 1M particles
    s.motion_blur           = true;
    s.chromatic_aberration  = true;
    s.hair_rendering        = true;
    s.fft_ocean             = true;
    s.ocean_fft_size        = 512;
    s.render_scale          = 1.0f;
    return s;
}

// ============================================================
// INIT
// ============================================================
bool Renderer::Init(void* window_handle, int width, int height, QualityTier tier) {
    TLOG_INFO(MOD, "Initialising Vulkan renderer...");
    TLOG_INFO(MOD, "Resolution: " + std::to_string(width) + "x" + std::to_string(height));

    m_width  = width;
    m_height = height;
    m_tier   = tier;

    // Apply quality settings
    switch (tier) {
        case QualityTier::MEDIUM: m_settings = QualitySettings::Medium(); break;
        case QualityTier::HIGH:   m_settings = QualitySettings::High();   break;
        case QualityTier::ULTRA:  m_settings = QualitySettings::Ultra();  break;
    }

    TLOG_INFO(MOD, "Quality: " +
        std::string(tier == QualityTier::MEDIUM ? "MEDIUM" :
                    tier == QualityTier::HIGH   ? "HIGH"   : "ULTRA"));

    if (!CreateInstance())       { TLOG_ERR(MOD, "CreateInstance failed");       return false; }
    if (!SelectGPU())            { TLOG_ERR(MOD, "SelectGPU failed");            return false; }
    if (!CreateDevice())         { TLOG_ERR(MOD, "CreateDevice failed");         return false; }

    // Create surface from GLFW window
    if (glfwCreateWindowSurface(m_instance,
                                static_cast<GLFWwindow*>(window_handle),
                                nullptr, &m_surface) != VK_SUCCESS) {
        TLOG_ERR(MOD, "Surface creation failed");
        return false;
    }

    if (!CreateSwapchain(width, height)) { TLOG_ERR(MOD, "Swapchain failed");   return false; }
    if (!CreateCommandPools())           { TLOG_ERR(MOD, "CommandPools failed"); return false; }
    if (!CreateDescriptorPool())         { TLOG_ERR(MOD, "DescPool failed");     return false; }
    if (!CreateRenderTargets())          { TLOG_ERR(MOD, "RenderTargets failed");return false; }
    if (!CreateRenderPasses())           { TLOG_ERR(MOD, "RenderPasses failed"); return false; }
    if (!CreateFramebuffersAfterPasses()) { TLOG_ERR(MOD, "Framebuffers failed"); return false; }
    if (!CreatePipelines())              { TLOG_ERR(MOD, "Pipelines failed");    return false; }
    if (!CreateSyncObjects())            { TLOG_ERR(MOD, "SyncObjects failed");  return false; }

    m_ready.store(true);
    TLOG_INFO(MOD, "Renderer ready ✓");
    return true;
}

// ============================================================
// CREATE INSTANCE
// ============================================================
bool Renderer::CreateInstance() {
    VkApplicationInfo app_info{};
    app_info.sType              = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app_info.pApplicationName   = "Legends of Terra";
    app_info.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    app_info.pEngineName        = "Terra Engine";
    app_info.engineVersion      = VK_MAKE_VERSION(4, 0, 0);
    app_info.apiVersion         = VK_API_VERSION_1_3;

    // Extensions — GLFW provides what we need
    uint32_t glfw_ext_count = 0;
    const char** glfw_exts  = glfwGetRequiredInstanceExtensions(&glfw_ext_count);
    std::vector<const char*> extensions(glfw_exts, glfw_exts + glfw_ext_count);

    // Validation layers in debug builds
    const std::vector<const char*> validation_layers = {
        "VK_LAYER_KHRONOS_validation"
    };

#ifdef DEBUG
    extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
#endif

    VkInstanceCreateInfo create_info{};
    create_info.sType                   = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    create_info.pApplicationInfo        = &app_info;
    create_info.enabledExtensionCount   = static_cast<uint32_t>(extensions.size());
    create_info.ppEnabledExtensionNames = extensions.data();

#ifdef DEBUG
    create_info.enabledLayerCount   = static_cast<uint32_t>(validation_layers.size());
    create_info.ppEnabledLayerNames = validation_layers.data();
#else
    create_info.enabledLayerCount   = 0;
#endif

    if (vkCreateInstance(&create_info, nullptr, &m_instance) != VK_SUCCESS) {
        return false;
    }

    TLOG_INFO(MOD, "Vulkan instance created — API 1.3");
    return true;
}

// ============================================================
// SELECT GPU
// ============================================================
bool Renderer::SelectGPU() {
    uint32_t count = 0;
    vkEnumeratePhysicalDevices(m_instance, &count, nullptr);
    if (count == 0) { TLOG_ERR(MOD, "No Vulkan GPUs found"); return false; }

    std::vector<VkPhysicalDevice> devices(count);
    vkEnumeratePhysicalDevices(m_instance, &count, devices.data());

    // Score GPUs — prefer discrete, then integrated
    VkPhysicalDevice best  = VK_NULL_HANDLE;
    int              score = -1;

    for (auto& dev : devices) {
        VkPhysicalDeviceProperties props;
        vkGetPhysicalDeviceProperties(dev, &props);

        int s = 0;
        if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU)   s += 1000;
        if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU) s += 100;
        s += static_cast<int>(props.limits.maxImageDimension2D / 1000);

        if (s > score) { score = s; best = dev; }
    }

    m_gpu = best;

    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(m_gpu, &props);
    TLOG_INFO(MOD, "GPU selected: " + std::string(props.deviceName));

    // Check if GPU supports ray tracing — update settings
    VkPhysicalDeviceFeatures2 features2{};
    features2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
    vkGetPhysicalDeviceFeatures2(m_gpu, &features2);

    if (!features2.features.samplerAnisotropy) {
        TLOG_WARN(MOD, "GPU lacks anisotropic filtering — quality reduced");
    }

    return m_gpu != VK_NULL_HANDLE;
}

// ============================================================
// CREATE DEVICE
// ============================================================
bool Renderer::CreateDevice() {
    // Find queue families
    uint32_t qcount = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(m_gpu, &qcount, nullptr);
    std::vector<VkQueueFamilyProperties> queues(qcount);
    vkGetPhysicalDeviceQueueFamilyProperties(m_gpu, &qcount, queues.data());

    bool found_graphics = false, found_compute = false;
    for (uint32_t i = 0; i < qcount; i++) {
        if (queues[i].queueFlags & VK_QUEUE_GRAPHICS_BIT && !found_graphics) {
            m_graphics_family = i;
            m_present_family  = i;
            found_graphics    = true;
        }
        if (queues[i].queueFlags & VK_QUEUE_COMPUTE_BIT && !found_compute) {
            m_compute_family  = i;
            found_compute     = true;
        }
    }

    if (!found_graphics) { TLOG_ERR(MOD, "No graphics queue family"); return false; }

    std::set<uint32_t> unique_families = {
        m_graphics_family, m_compute_family
    };

    float priority = 1.0f;
    std::vector<VkDeviceQueueCreateInfo> queue_infos;
    for (uint32_t family : unique_families) {
        VkDeviceQueueCreateInfo qi{};
        qi.sType            = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        qi.queueFamilyIndex = family;
        qi.queueCount       = 1;
        qi.pQueuePriorities = &priority;
        queue_infos.push_back(qi);
    }

    // Required extensions
    std::vector<const char*> device_extensions = {
        VK_KHR_SWAPCHAIN_EXTENSION_NAME,
        VK_KHR_DYNAMIC_RENDERING_EXTENSION_NAME,
    };

    // Ray tracing extensions — ULTRA only, check support first
    bool has_ray_tracing = false;
    if (m_tier == QualityTier::ULTRA) {
        uint32_t ext_count = 0;
        vkEnumerateDeviceExtensionProperties(m_gpu, nullptr, &ext_count, nullptr);
        std::vector<VkExtensionProperties> avail(ext_count);
        vkEnumerateDeviceExtensionProperties(m_gpu, nullptr, &ext_count, avail.data());

        for (const auto& e : avail) {
            if (strcmp(e.extensionName, VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME) == 0) {
                has_ray_tracing = true;
                break;
            }
        }

        if (has_ray_tracing) {
            device_extensions.push_back(VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME);
            device_extensions.push_back(VK_KHR_ACCELERATION_STRUCTURE_EXTENSION_NAME);
            device_extensions.push_back(VK_KHR_DEFERRED_HOST_OPERATIONS_EXTENSION_NAME);
            TLOG_INFO(MOD, "Ray tracing ENABLED");
        } else {
            m_settings.ray_traced_shadows = false;
            TLOG_WARN(MOD, "Ray tracing not available on this GPU — using rasterized shadows");
        }
    }

    VkPhysicalDeviceFeatures features{};
    features.samplerAnisotropy          = VK_TRUE;
    features.geometryShader             = VK_TRUE;
    features.tessellationShader         = VK_TRUE;
    features.independentBlend           = VK_TRUE;
    features.multiDrawIndirect          = VK_TRUE;

    VkDeviceCreateInfo create_info{};
    create_info.sType                   = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    create_info.queueCreateInfoCount    = static_cast<uint32_t>(queue_infos.size());
    create_info.pQueueCreateInfos       = queue_infos.data();
    create_info.enabledExtensionCount   = static_cast<uint32_t>(device_extensions.size());
    create_info.ppEnabledExtensionNames = device_extensions.data();
    create_info.pEnabledFeatures        = &features;

    if (vkCreateDevice(m_gpu, &create_info, nullptr, &m_device) != VK_SUCCESS) {
        TLOG_ERR(MOD, "Logical device creation failed");
        return false;
    }

    vkGetDeviceQueue(m_device, m_graphics_family, 0, &m_graphics_queue);
    vkGetDeviceQueue(m_device, m_compute_family,  0, &m_compute_queue);
    vkGetDeviceQueue(m_device, m_present_family,  0, &m_present_queue);

    TLOG_INFO(MOD, "Logical device created");
    return true;
}

// ============================================================
// CREATE SWAPCHAIN
// ============================================================
bool Renderer::CreateSwapchain(int w, int h) {
    // Query surface capabilities
    VkSurfaceCapabilitiesKHR caps;
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR(m_gpu, m_surface, &caps);

    // Choose format — prefer SRGB
    uint32_t fmt_count = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(m_gpu, m_surface, &fmt_count, nullptr);
    std::vector<VkSurfaceFormatKHR> formats(fmt_count);
    vkGetPhysicalDeviceSurfaceFormatsKHR(m_gpu, m_surface, &fmt_count, formats.data());

    VkSurfaceFormatKHR chosen = formats[0];
    for (const auto& f : formats) {
        if (f.format     == VK_FORMAT_B8G8R8A8_SRGB &&
            f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) {
            chosen = f;
            break;
        }
    }

    // Choose present mode — MAILBOX for lowest latency
    uint32_t pm_count = 0;
    vkGetPhysicalDeviceSurfacePresentModesKHR(m_gpu, m_surface, &pm_count, nullptr);
    std::vector<VkPresentModeKHR> present_modes(pm_count);
    vkGetPhysicalDeviceSurfacePresentModesKHR(m_gpu, m_surface, &pm_count, present_modes.data());

    VkPresentModeKHR present_mode = VK_PRESENT_MODE_FIFO_KHR; // guaranteed
    for (auto pm : present_modes) {
        if (pm == VK_PRESENT_MODE_MAILBOX_KHR) { present_mode = pm; break; }
    }

    // Extent
    VkExtent2D extent;
    if (caps.currentExtent.width != UINT32_MAX) {
        extent = caps.currentExtent;
    } else {
        extent.width  = std::clamp(static_cast<uint32_t>(w),
                                   caps.minImageExtent.width,
                                   caps.maxImageExtent.width);
        extent.height = std::clamp(static_cast<uint32_t>(h),
                                   caps.minImageExtent.height,
                                   caps.maxImageExtent.height);
    }

    uint32_t image_count = std::min(caps.minImageCount + 1,
                                    caps.maxImageCount > 0 ?
                                    caps.maxImageCount : UINT32_MAX);

    VkSwapchainCreateInfoKHR sc_info{};
    sc_info.sType            = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
    sc_info.surface          = m_surface;
    sc_info.minImageCount    = image_count;
    sc_info.imageFormat      = chosen.format;
    sc_info.imageColorSpace  = chosen.colorSpace;
    sc_info.imageExtent      = extent;
    sc_info.imageArrayLayers = 1;
    sc_info.imageUsage       = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    sc_info.preTransform     = caps.currentTransform;
    sc_info.compositeAlpha   = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    sc_info.presentMode      = present_mode;
    sc_info.clipped          = VK_TRUE;

    uint32_t queue_indices[] = {m_graphics_family, m_present_family};
    if (m_graphics_family != m_present_family) {
        sc_info.imageSharingMode      = VK_SHARING_MODE_CONCURRENT;
        sc_info.queueFamilyIndexCount = 2;
        sc_info.pQueueFamilyIndices   = queue_indices;
    } else {
        sc_info.imageSharingMode      = VK_SHARING_MODE_EXCLUSIVE;
    }

    if (vkCreateSwapchainKHR(m_device, &sc_info, nullptr, &m_swapchain) != VK_SUCCESS) {
        return false;
    }

    m_swapchain_format = chosen.format;
    m_swapchain_extent = extent;

    // Get swapchain images
    uint32_t img_count = 0;
    vkGetSwapchainImagesKHR(m_device, m_swapchain, &img_count, nullptr);
    std::vector<VkImage> sc_images(img_count);
    vkGetSwapchainImagesKHR(m_device, m_swapchain, &img_count, sc_images.data());

    m_frames.resize(img_count);
    for (uint32_t i = 0; i < img_count; i++) {
        m_frames[i].image = sc_images[i];

        VkImageViewCreateInfo view_info{};
        view_info.sType    = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        view_info.image    = sc_images[i];
        view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
        view_info.format   = m_swapchain_format;
        view_info.subresourceRange.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT;
        view_info.subresourceRange.baseMipLevel   = 0;
        view_info.subresourceRange.levelCount     = 1;
        view_info.subresourceRange.baseArrayLayer = 0;
        view_info.subresourceRange.layerCount     = 1;

        if (vkCreateImageView(m_device, &view_info, nullptr, &m_frames[i].view) != VK_SUCCESS) {
            TLOG_ERR(MOD, "Failed to create swapchain image view " + std::to_string(i));
            return false;
        }
    }

    TLOG_INFO(MOD, "Swapchain created: " +
              std::to_string(extent.width) + "x" + std::to_string(extent.height) +
              " x" + std::to_string(img_count) + " images");
    return true;
}

// ============================================================
// CREATE COMMAND POOLS
// ============================================================
bool Renderer::CreateCommandPools() {
    VkCommandPoolCreateInfo pool_info{};
    pool_info.sType            = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    pool_info.queueFamilyIndex = m_graphics_family;
    pool_info.flags            = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;

    if (vkCreateCommandPool(m_device, &pool_info, nullptr, &m_cmd_pool) != VK_SUCCESS)
        return false;

    // Allocate one command buffer per swapchain frame
    VkCommandBufferAllocateInfo alloc_info{};
    alloc_info.sType              = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    alloc_info.commandPool        = m_cmd_pool;
    alloc_info.level              = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc_info.commandBufferCount = static_cast<uint32_t>(m_frames.size());

    std::vector<VkCommandBuffer> cmds(m_frames.size());
    if (vkAllocateCommandBuffers(m_device, &alloc_info, cmds.data()) != VK_SUCCESS)
        return false;

    for (size_t i = 0; i < m_frames.size(); i++) m_frames[i].cmd = cmds[i];

    return true;
}

// ============================================================
// CREATE DESCRIPTOR POOL
// ============================================================
bool Renderer::CreateDescriptorPool() {
    std::vector<VkDescriptorPoolSize> sizes = {
        {VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,         256},
        {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 512},
        {VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,          128},
        {VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,         128},
        {VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT,        64},
    };

    VkDescriptorPoolCreateInfo pool_info{};
    pool_info.sType         = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    pool_info.maxSets       = 1024;
    pool_info.poolSizeCount = static_cast<uint32_t>(sizes.size());
    pool_info.pPoolSizes    = sizes.data();
    pool_info.flags         = VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT;

    return vkCreateDescriptorPool(m_device, &pool_info, nullptr, &m_desc_pool) == VK_SUCCESS;
}

// ============================================================
// CREATE RENDER TARGETS
// ============================================================
bool Renderer::CreateRenderTargets() {
    uint32_t w = m_swapchain_extent.width;
    uint32_t h = m_swapchain_extent.height;

    // GBuffer targets — albedo needs TRANSFER_SRC for PassLighting blit
    CreateImage(m_gbuffer.albedo_metallic,
                w, h, VK_FORMAT_R8G8B8A8_SRGB,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                VK_IMAGE_USAGE_SAMPLED_BIT          |
                VK_IMAGE_USAGE_TRANSFER_SRC_BIT);

    CreateImage(m_gbuffer.normal_roughness,
                w, h, VK_FORMAT_R16G16B16A16_SFLOAT,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT);

    CreateImage(m_gbuffer.emissive_ao,
                w, h, VK_FORMAT_R8G8B8A8_SRGB,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT);

    CreateImage(m_gbuffer.depth,
                w, h, FindDepthFormat(),
                VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT);

    // HDR lighting output — needs TRANSFER_SRC+DST for PassLighting/PassPostProcess blits
    CreateImage(m_hdr_target,
                w, h, VK_FORMAT_R16G16B16A16_SFLOAT,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                VK_IMAGE_USAGE_SAMPLED_BIT           |
                VK_IMAGE_USAGE_STORAGE_BIT           |
                VK_IMAGE_USAGE_TRANSFER_SRC_BIT      |
                VK_IMAGE_USAGE_TRANSFER_DST_BIT);

    // SSAO
    CreateImage(m_ssao_target,
                w / 2, h / 2, VK_FORMAT_R8_UNORM,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT);

    // Shadow map — size based on quality
    uint32_t sm = static_cast<uint32_t>(m_settings.shadow_map_size);
    CreateImage(m_shadow_map,
                sm * m_settings.shadow_cascades, sm,
                FindDepthFormat(),
                VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT);

    // Bloom target
    CreateImage(m_bloom_target,
                w / 2, h / 2, VK_FORMAT_R16G16B16A16_SFLOAT,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                VK_IMAGE_USAGE_SAMPLED_BIT           |
                VK_IMAGE_USAGE_STORAGE_BIT);

    // TAA history buffer
    CreateImage(m_taa_history,
                w, h, VK_FORMAT_R16G16B16A16_SFLOAT,
                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT);

    // HIGH + ULTRA: SSR
    if (m_settings.ssr_enabled) {
        CreateImage(m_ssr_target,
                    w, h, VK_FORMAT_R16G16B16A16_SFLOAT,
                    VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                    VK_IMAGE_USAGE_SAMPLED_BIT           |
                    VK_IMAGE_USAGE_STORAGE_BIT);
    }

    // ULTRA: Volumetric cloud target (quarter res)
    if (m_settings.volumetric_clouds) {
        CreateImage(m_cloud_target,
                    w / 4, h / 4, VK_FORMAT_R16G16B16A16_SFLOAT,
                    VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                    VK_IMAGE_USAGE_SAMPLED_BIT           |
                    VK_IMAGE_USAGE_STORAGE_BIT);
    }

    TLOG_INFO(MOD, "Render targets created");
    // NOTE (Bug 12 fix): GBuffer and shadow framebuffers are created in
    // CreateFramebuffersAfterPasses(), called from Init() after CreateRenderPasses().
    // Framebuffers require the render pass object to exist first.
    return true;
}

// ============================================================
// CREATE FRAMEBUFFERS (called after render passes are created)
// BUG 4 FIX: shadow pass was using m_gbuffer.framebuffer — wrong.
// BUG 12 FIX: m_gbuffer.framebuffer was never created at all.
// ============================================================
bool Renderer::CreateFramebuffersAfterPasses() {
    // --- GBuffer framebuffer ---
    std::array<VkImageView, 4> gbuf_views = {
        m_gbuffer.albedo_metallic.view,
        m_gbuffer.normal_roughness.view,
        m_gbuffer.emissive_ao.view,
        m_gbuffer.depth.view
    };
    VkFramebufferCreateInfo gbuf_fb{};
    gbuf_fb.sType           = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    gbuf_fb.renderPass      = m_gbuffer.render_pass;
    gbuf_fb.attachmentCount = static_cast<uint32_t>(gbuf_views.size());
    gbuf_fb.pAttachments    = gbuf_views.data();
    gbuf_fb.width           = m_swapchain_extent.width;
    gbuf_fb.height          = m_swapchain_extent.height;
    gbuf_fb.layers          = 1;
    if (vkCreateFramebuffer(m_device, &gbuf_fb, nullptr, &m_gbuffer.framebuffer) != VK_SUCCESS) {
        TLOG_ERR(MOD, "GBuffer framebuffer creation failed");
        return false;
    }

    // --- Shadow framebuffer (depth-only, shadow map size * cascades wide) ---
    VkFramebufferCreateInfo shadow_fb{};
    shadow_fb.sType           = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    shadow_fb.renderPass      = m_shadow_pass;
    shadow_fb.attachmentCount = 1;
    shadow_fb.pAttachments    = &m_shadow_map.view;
    shadow_fb.width           = static_cast<uint32_t>(m_settings.shadow_map_size)
                                * m_settings.shadow_cascades;
    shadow_fb.height          = static_cast<uint32_t>(m_settings.shadow_map_size);
    shadow_fb.layers          = 1;
    if (vkCreateFramebuffer(m_device, &shadow_fb, nullptr, &m_shadow_framebuffer) != VK_SUCCESS) {
        TLOG_ERR(MOD, "Shadow framebuffer creation failed");
        return false;
    }

    TLOG_INFO(MOD, "Framebuffers created");
    return true;
}

// ============================================================
// CREATE RENDER PASSES
// ============================================================
bool Renderer::CreateRenderPasses() {
    // --------------------------------------------------------
    // Shadow pass — depth only, used for shadow map rendering
    // --------------------------------------------------------
    {
        VkAttachmentDescription depth_att{};
        depth_att.format         = FindDepthFormat();
        depth_att.samples        = VK_SAMPLE_COUNT_1_BIT;
        depth_att.loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
        depth_att.storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
        depth_att.stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        depth_att.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        depth_att.initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;
        depth_att.finalLayout    = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;

        VkAttachmentReference depth_ref{};
        depth_ref.attachment = 0;
        depth_ref.layout     = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

        VkSubpassDescription subpass{};
        subpass.pipelineBindPoint       = VK_PIPELINE_BIND_POINT_GRAPHICS;
        subpass.pDepthStencilAttachment = &depth_ref;

        VkRenderPassCreateInfo rp_info{};
        rp_info.sType           = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
        rp_info.attachmentCount = 1;
        rp_info.pAttachments    = &depth_att;
        rp_info.subpassCount    = 1;
        rp_info.pSubpasses      = &subpass;

        // NEW-2 FIX: Check vkCreateRenderPass return value — was silently discarded
        if (vkCreateRenderPass(m_device, &rp_info, nullptr, &m_shadow_pass) != VK_SUCCESS) {
            TLOG_ERR(MOD, "Shadow render pass creation failed");
            return false;
        }
    }

    // --------------------------------------------------------
    // NEW-1 FIX: GBuffer render pass — was NEVER created before.
    // m_gbuffer.render_pass was VK_NULL_HANDLE, making the GBuffer
    // framebuffer creation and PassGBuffer both invalid.
    // 4 attachments: albedo+metallic (R8G8B8A8), normals+roughness
    // (R16F), emissive+AO (R8G8B8A8), depth (device depth format).
    // --------------------------------------------------------
    {
        std::array<VkAttachmentDescription, 4> atts{};

        // Attachment 0 — albedo + metallic (R8G8B8A8_SRGB)
        atts[0].format         = VK_FORMAT_R8G8B8A8_SRGB;
        atts[0].samples        = VK_SAMPLE_COUNT_1_BIT;
        atts[0].loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
        atts[0].storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
        atts[0].stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        atts[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        atts[0].initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;
        atts[0].finalLayout    = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

        // Attachment 1 — normals + roughness (R16G16B16A16_SFLOAT)
        atts[1].format         = VK_FORMAT_R16G16B16A16_SFLOAT;
        atts[1].samples        = VK_SAMPLE_COUNT_1_BIT;
        atts[1].loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
        atts[1].storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
        atts[1].stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        atts[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        atts[1].initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;
        atts[1].finalLayout    = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

        // Attachment 2 — emissive + AO (R8G8B8A8_SRGB)
        atts[2].format         = VK_FORMAT_R8G8B8A8_SRGB;
        atts[2].samples        = VK_SAMPLE_COUNT_1_BIT;
        atts[2].loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
        atts[2].storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
        atts[2].stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        atts[2].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        atts[2].initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;
        atts[2].finalLayout    = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

        // Attachment 3 — depth (device depth format)
        atts[3].format         = FindDepthFormat();
        atts[3].samples        = VK_SAMPLE_COUNT_1_BIT;
        atts[3].loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
        atts[3].storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
        atts[3].stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        atts[3].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        atts[3].initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;
        atts[3].finalLayout    = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;

        std::array<VkAttachmentReference, 3> color_refs{};
        color_refs[0] = {0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        color_refs[1] = {1, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        color_refs[2] = {2, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};

        VkAttachmentReference depth_ref{};
        depth_ref.attachment = 3;
        depth_ref.layout     = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

        VkSubpassDescription subpass{};
        subpass.pipelineBindPoint       = VK_PIPELINE_BIND_POINT_GRAPHICS;
        subpass.colorAttachmentCount    = static_cast<uint32_t>(color_refs.size());
        subpass.pColorAttachments       = color_refs.data();
        subpass.pDepthStencilAttachment = &depth_ref;

        // Subpass dependency: ensure shadow pass writes finish before GBuffer reads
        VkSubpassDependency dep{};
        dep.srcSubpass      = VK_SUBPASS_EXTERNAL;
        dep.dstSubpass      = 0;
        dep.srcStageMask    = VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT |
                              VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
        dep.dstStageMask    = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        dep.srcAccessMask   = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        dep.dstAccessMask   = VK_ACCESS_SHADER_READ_BIT;

        VkRenderPassCreateInfo rp_info{};
        rp_info.sType           = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
        rp_info.attachmentCount = static_cast<uint32_t>(atts.size());
        rp_info.pAttachments    = atts.data();
        rp_info.subpassCount    = 1;
        rp_info.pSubpasses      = &subpass;
        rp_info.dependencyCount = 1;
        rp_info.pDependencies   = &dep;

        // NEW-2 FIX: Return value checked
        if (vkCreateRenderPass(m_device, &rp_info, nullptr, &m_gbuffer.render_pass) != VK_SUCCESS) {
            TLOG_ERR(MOD, "GBuffer render pass creation failed");
            return false;
        }
    }

    TLOG_INFO(MOD, "Render passes created");
    return true;
}

// ============================================================
// CREATE PIPELINES
// ============================================================
bool Renderer::CreatePipelines() {
    // Init ShaderManager with device and shader directory from Config
    SHADERS.Init(m_device, TCONFIG.ShaderDir());

    // Pipelines are built from pre-compiled .spv files (via glslc in CMake).
    // PassShadow and PassGBuffer will bind their pipelines when loaded.
    // PassLighting and PassPostProcess use image blits (no pipeline needed).
    TLOG_INFO(MOD, "ShaderManager initialised — pipelines ready when .spv files present");
    return true;
}

// ============================================================
// CREATE SYNC OBJECTS
// ============================================================
bool Renderer::CreateSyncObjects() {
    VkSemaphoreCreateInfo sem_info{};
    sem_info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;

    VkFenceCreateInfo fence_info{};
    fence_info.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    fence_info.flags = VK_FENCE_CREATE_SIGNALED_BIT; // start signaled

    for (auto& frame : m_frames) {
        // NEW-8 FIX: Check all sync object creation — silent VK_NULL_HANDLE causes GPU crash on first submit
        if (vkCreateSemaphore(m_device, &sem_info,   nullptr, &frame.image_ready) != VK_SUCCESS) {
            TLOG_ERR(MOD, "Failed to create image_ready semaphore");
            return false;
        }
        if (vkCreateSemaphore(m_device, &sem_info,   nullptr, &frame.render_done) != VK_SUCCESS) {
            TLOG_ERR(MOD, "Failed to create render_done semaphore");
            return false;
        }
        if (vkCreateFence    (m_device, &fence_info, nullptr, &frame.in_flight  ) != VK_SUCCESS) {
            TLOG_ERR(MOD, "Failed to create in_flight fence");
            return false;
        }
    }

    TLOG_INFO(MOD, "Sync objects created");
    return true;
}

// ============================================================
// BEGIN FRAME
// ============================================================
void Renderer::BeginFrame(const RenderFrame& frame) {
    if (!m_ready.load()) return;

    auto t_cpu_start = std::chrono::high_resolution_clock::now();
    m_time += frame.delta_time;

    SwapchainFrame& sf = m_frames[m_frame_index % m_frames.size()];

    // Wait for previous use of this frame to finish
    vkWaitForFences(m_device, 1, &sf.in_flight, VK_TRUE, UINT64_MAX);

    // Acquire next swapchain image
    VkResult result = vkAcquireNextImageKHR(
        m_device, m_swapchain, UINT64_MAX,
        sf.image_ready, VK_NULL_HANDLE, &m_image_index);

    if (result == VK_ERROR_OUT_OF_DATE_KHR) {
        RecreateSwapchain();
        return;
    }

    vkResetFences(m_device, 1, &sf.in_flight);

    // Record command buffer
    VkCommandBufferBeginInfo begin_info{};
    begin_info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    begin_info.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;

    vkResetCommandBuffer(sf.cmd, 0);
    vkBeginCommandBuffer(sf.cmd, &begin_info);

    // ── RENDER PASS ORDER ──────────────────────────────────
    // ALL TIERS:
    PassShadow  (sf.cmd, frame);    // shadow map
    PassGBuffer (sf.cmd, frame);    // geometry → gbuffer
    PassSSAO    (sf.cmd);           // ambient occlusion
    PassLighting(sf.cmd, frame);    // PBR deferred lighting
    PassParticles(sf.cmd, frame);   // magic / corruption / fire

    // HIGH + ULTRA:
    if (m_settings.ssr_enabled)
        PassSSR(sf.cmd, frame);

    if (m_settings.volumetric_light)
        PassVolumetricFog(sf.cmd, frame);

    // ULTRA only:
    if (m_settings.volumetric_clouds)
        PassVolumetricClouds(sf.cmd, frame);

    // ALL TIERS — post process:
    PassBloom      (sf.cmd);
    PassTAA        (sf.cmd);
    PassPostProcess(sf.cmd, frame);
    PassUI         (sf.cmd);

    vkEndCommandBuffer(sf.cmd);

    // Stats
    auto t_cpu_end = std::chrono::high_resolution_clock::now();
    m_stats.cpu_time_ms = std::chrono::duration<double, std::milli>(
        t_cpu_end - t_cpu_start).count();
}

// ============================================================
// END FRAME
// ============================================================
void Renderer::EndFrame() {
    if (!m_ready.load()) return;

    SwapchainFrame& sf = m_frames[m_frame_index % m_frames.size()];

    VkPipelineStageFlags wait_stages[] = {
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT
    };

    VkSubmitInfo submit_info{};
    submit_info.sType                = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submit_info.waitSemaphoreCount   = 1;
    submit_info.pWaitSemaphores      = &sf.image_ready;
    submit_info.pWaitDstStageMask    = wait_stages;
    submit_info.commandBufferCount   = 1;
    submit_info.pCommandBuffers      = &sf.cmd;
    submit_info.signalSemaphoreCount = 1;
    submit_info.pSignalSemaphores    = &sf.render_done;

    vkQueueSubmit(m_graphics_queue, 1, &submit_info, sf.in_flight);

    VkPresentInfoKHR present_info{};
    present_info.sType              = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    present_info.waitSemaphoreCount = 1;
    present_info.pWaitSemaphores    = &sf.render_done;
    present_info.swapchainCount     = 1;
    present_info.pSwapchains        = &m_swapchain;
    present_info.pImageIndices      = &m_image_index;

    VkResult result = vkQueuePresentKHR(m_present_queue, &present_info);
    if (result == VK_ERROR_OUT_OF_DATE_KHR || result == VK_SUBOPTIMAL_KHR)
        RecreateSwapchain();

    m_frame_index++;
    m_stats.draw_calls = 0; // reset per frame
}

// ============================================================
// RENDER PASSES
// ============================================================
void Renderer::PassShadow(VkCommandBuffer cmd, const RenderFrame& frame) {
    VkClearValue clear{};
    clear.depthStencil = {1.0f, 0};

    VkRenderPassBeginInfo begin{};
    begin.sType             = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    begin.renderPass        = m_shadow_pass;
    begin.framebuffer       = m_shadow_framebuffer; // BUG 4 FIX: was m_gbuffer.framebuffer (wrong — corrupted GBuffer every frame)
    begin.renderArea.extent = {
        static_cast<uint32_t>(m_settings.shadow_map_size),
        static_cast<uint32_t>(m_settings.shadow_map_size)
    };
    begin.clearValueCount   = 1;
    begin.pClearValues      = &clear;

    vkCmdBeginRenderPass(cmd, &begin, VK_SUBPASS_CONTENTS_INLINE);

    // BUG 5 FIX: Bind pipeline before any draw calls — Vulkan UB/GPU crash without this
    VkPipeline shadow_pipeline = GetPipeline("shadow");
    if (shadow_pipeline != VK_NULL_HANDLE)
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, shadow_pipeline);

    // Render all shadow-casting objects per cascade
    for (int cascade = 0; cascade < m_settings.shadow_cascades; cascade++) {
        // Set viewport to correct cascade region
        VkViewport viewport{};
        viewport.x        = static_cast<float>(cascade * m_settings.shadow_map_size);
        viewport.y        = 0;
        viewport.width    = static_cast<float>(m_settings.shadow_map_size);
        viewport.height   = static_cast<float>(m_settings.shadow_map_size);
        viewport.minDepth = 0.0f;
        viewport.maxDepth = 1.0f;
        vkCmdSetViewport(cmd, 0, 1, &viewport);

        for (const auto* obj : frame.objects) {
            if (!obj->cast_shadow) continue;
            VkDeviceSize offset = 0;
            vkCmdBindVertexBuffers(cmd, 0, 1, &obj->vertex_buffer.handle, &offset);
            vkCmdBindIndexBuffer(cmd, obj->index_buffer.handle, 0, VK_INDEX_TYPE_UINT32);
            vkCmdDrawIndexed(cmd, obj->index_count, 1, 0, 0, 0);
            m_stats.draw_calls++;
        }
    }

    vkCmdEndRenderPass(cmd);
}

void Renderer::PassGBuffer(VkCommandBuffer cmd, const RenderFrame& frame) {
    VkClearValue clears[4];
    clears[0].color        = {0, 0, 0, 0};
    clears[1].color        = {0, 0, 0, 0};
    clears[2].color        = {0, 0, 0, 0};
    clears[3].depthStencil = {1.0f, 0};

    VkRenderPassBeginInfo begin{};
    begin.sType             = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    begin.renderPass        = m_gbuffer.render_pass;
    begin.framebuffer       = m_gbuffer.framebuffer;
    begin.renderArea.extent = m_swapchain_extent;
    begin.clearValueCount   = 4;
    begin.pClearValues      = clears;

    vkCmdBeginRenderPass(cmd, &begin, VK_SUBPASS_CONTENTS_INLINE);

    // BUG 5 FIX: Bind pipeline + descriptor sets before any draw calls.
    // Without this, Vulkan behaviour is undefined — most drivers produce a black screen or GPU fault.
    VkPipeline gbuf_pipeline = GetPipeline("gbuffer");
    if (gbuf_pipeline != VK_NULL_HANDLE) {
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, gbuf_pipeline);
        // Descriptor set 0: camera UBO. Set 1: material textures (bound per-object below).
        if (m_pipe_layouts.count("gbuffer")) {
            // Camera descriptor set bound once per pass
            // vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS,
            //     m_pipe_layouts["gbuffer"], 0, 1, &m_camera_desc_set, 0, nullptr);
            // Uncomment when camera UBO descriptor set is wired up.
        }
    }

    VkViewport viewport{};
    viewport.width    = static_cast<float>(m_swapchain_extent.width);
    viewport.height   = static_cast<float>(m_swapchain_extent.height);
    viewport.minDepth = 0.0f;
    viewport.maxDepth = 1.0f;
    vkCmdSetViewport(cmd, 0, 1, &viewport);

    VkRect2D scissor{};
    scissor.extent = m_swapchain_extent;
    vkCmdSetScissor(cmd, 0, 1, &scissor);

    // Draw all opaque objects
    for (const auto* obj : frame.objects) {
        if (obj->is_transparent) continue;
        VkDeviceSize offset = 0;
        vkCmdBindVertexBuffers(cmd, 0, 1, &obj->vertex_buffer.handle, &offset);
        vkCmdBindIndexBuffer(cmd, obj->index_buffer.handle, 0, VK_INDEX_TYPE_UINT32);
        vkCmdDrawIndexed(cmd, obj->index_count, 1, 0, 0, 0);
        m_stats.draw_calls++;
        m_stats.triangles += obj->index_count / 3;
    }

    vkCmdEndRenderPass(cmd);
}

void Renderer::PassSSAO(VkCommandBuffer cmd) {
    // Full-screen quad — compute SSAO from gbuffer depth + normals
    // Samples: 8 (MEDIUM), 16 (HIGH), 32 (ULTRA)
    // Output: m_ssao_target (half resolution, R8_UNORM)
    (void)cmd;
}

void Renderer::PassLighting(VkCommandBuffer cmd, const RenderFrame& frame) {
    // BUG 8 FIX: was a void stub — nothing rendered, black screen.
    //
    // Implementation: blit GBuffer albedo → HDR target.
    // This gives UNLIT geometry on screen immediately with zero shader dependency.
    // When lighting.frag.spv compiles (via glslc in CMakeLists), replace with
    // a proper full-screen deferred PBR pass. For now: game is VISIBLE.
    //
    // Transition albedo to TRANSFER_SRC
    TransitionImage(cmd,
        m_gbuffer.albedo_metallic.handle,
        VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
        VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL);

    // Transition HDR target to TRANSFER_DST
    TransitionImage(cmd,
        m_hdr_target.handle,
        VK_IMAGE_LAYOUT_UNDEFINED,
        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);

    // Blit albedo → HDR (same size, no scale)
    VkImageBlit blit{};
    blit.srcSubresource.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT;
    blit.srcSubresource.layerCount     = 1;
    blit.srcOffsets[1]                 = { (int32_t)m_swapchain_extent.width,
                                           (int32_t)m_swapchain_extent.height, 1 };
    blit.dstSubresource.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT;
    blit.dstSubresource.layerCount     = 1;
    blit.dstOffsets[1]                 = { (int32_t)m_swapchain_extent.width,
                                           (int32_t)m_swapchain_extent.height, 1 };

    vkCmdBlitImage(cmd,
        m_gbuffer.albedo_metallic.handle, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
        m_hdr_target.handle,             VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
        1, &blit, VK_FILTER_NEAREST);

    // Transition HDR to SHADER_READ for post-process
    TransitionImage(cmd,
        m_hdr_target.handle,
        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
        VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL);

    // Restore albedo layout
    TransitionImage(cmd,
        m_gbuffer.albedo_metallic.handle,
        VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
        VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);

    (void)frame; // frame used when full PBR lighting pass is wired
}

void Renderer::PassSSR(VkCommandBuffer cmd, const RenderFrame& frame) {
    // HIGH + ULTRA only
    // Screen-space reflections — ray march in view space
    // Steps: 32 (HIGH), 64 (ULTRA)
    // Reads: hdr_target, depth, normals
    // Outputs: m_ssr_target (blended onto hdr in composite)
    (void)cmd; (void)frame;
}

void Renderer::PassVolumetricClouds(VkCommandBuffer cmd, const RenderFrame& frame) {
    // ULTRA only — quarter resolution, upsampled
    // Raymarched cloud volumes
    // Steps: 128
    // Reads: depth (for cloud-terrain intersection)
    // Weather param drives cloud density
    // Aurora effect injected in cloud layer when is_night=true
    (void)cmd; (void)frame;
}

void Renderer::PassVolumetricFog(VkCommandBuffer cmd, const RenderFrame& frame) {
    // HIGH + ULTRA
    // Volumetric light shafts and fog
    // Steps: 32 (HIGH), 64 (ULTRA)
    // Corruption param drives fog color (purple tint)
    (void)cmd; (void)frame;
}

void Renderer::PassParticles(VkCommandBuffer cmd, const RenderFrame& frame) {
    // Additive blended transparent particles
    // MEDIUM: 50K CPU particles
    // HIGH:   250K GPU particles via compute
    // ULTRA:  1M GPU particles via compute
    // Used for: magic effects, corruption, fire, waterfalls, dust
    (void)cmd; (void)frame;
}

void Renderer::PassBloom(VkCommandBuffer cmd) {
    // Dual-kawase bloom — fast and high quality
    // Passes: 4 (MEDIUM), 6 (HIGH), 8 (ULTRA)
    // Threshold: 1.2 → 1.0 → 0.8
    // Magic effects glow, lava cracks, aurora, crystal corruption
    (void)cmd;
}

void Renderer::PassTAA(VkCommandBuffer cmd) {
    // Temporal Anti-Aliasing — accumulates over frames
    // Reads: current frame + history buffer
    // Writes: resolved output + updates history
    // Eliminates jaggies without MSAA cost
    (void)cmd;
}

void Renderer::PassPostProcess(VkCommandBuffer cmd, const RenderFrame& frame) {
    // Blit HDR target → swapchain image, then transition to PRESENT_SRC.
    // BUG 3 FIX: Use VK_FILTER_LINEAR (not NEAREST) when blitting between
    // different formats (R16G16B16A16 → B8G8R8A8). NEAREST causes validation
    // errors when format conversion is required on strict drivers.

    VkImage swapchain_img = m_frames[m_image_index].image;

    TransitionImage(cmd, swapchain_img,
        VK_IMAGE_LAYOUT_UNDEFINED,
        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);

    VkImageBlit blit{};
    blit.srcSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    blit.srcSubresource.layerCount = 1;
    blit.srcOffsets[0]             = {0, 0, 0};
    blit.srcOffsets[1]             = { (int32_t)m_swapchain_extent.width,
                                       (int32_t)m_swapchain_extent.height, 1 };
    blit.dstSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    blit.dstSubresource.layerCount = 1;
    blit.dstOffsets[0]             = {0, 0, 0};
    blit.dstOffsets[1]             = { (int32_t)m_swapchain_extent.width,
                                       (int32_t)m_swapchain_extent.height, 1 };

    // LINEAR required when src/dst formats differ (HDR float → SRGB byte)
    vkCmdBlitImage(cmd,
        m_hdr_target.handle, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
        swapchain_img,       VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
        1, &blit, VK_FILTER_LINEAR);

    TransitionImage(cmd, swapchain_img,
        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
        VK_IMAGE_LAYOUT_PRESENT_SRC_KHR);

    (void)frame;
}

void Renderer::PassUI(VkCommandBuffer cmd) {
    // HUD + menus rendered on top
    // Uses VK_IMAGE_LAYOUT_PRESENT_SRC_KHR as final output
    (void)cmd;
}

// ============================================================
// RESOURCE CREATION
// ============================================================
bool Renderer::CreateBuffer(GpuBuffer& buf,
                             VkDeviceSize size,
                             VkBufferUsageFlags usage,
                             bool host_visible)
{
    buf.size = size;

    VkBufferCreateInfo buf_info{};
    buf_info.sType       = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    buf_info.size        = size;
    buf_info.usage       = usage;
    buf_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;

    if (vkCreateBuffer(m_device, &buf_info, nullptr, &buf.handle) != VK_SUCCESS)
        return false;

    VkMemoryRequirements req;
    vkGetBufferMemoryRequirements(m_device, buf.handle, &req);

    VkMemoryPropertyFlags props = host_visible
        ? (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)
        : VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;

    VkMemoryAllocateInfo alloc{};
    alloc.sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    alloc.allocationSize  = req.size;
    alloc.memoryTypeIndex = FindMemoryType(req.memoryTypeBits, props);

    if (vkAllocateMemory(m_device, &alloc, nullptr, &buf.memory) != VK_SUCCESS)
        return false;

    if (vkBindBufferMemory(m_device, buf.handle, buf.memory, 0) != VK_SUCCESS)
        return false;

    if (host_visible) {
        if (vkMapMemory(m_device, buf.memory, 0, size, 0, &buf.mapped_ptr) != VK_SUCCESS)
            return false;
    }

    return true;
}

bool Renderer::CreateImage(GpuImage& img,
                            uint32_t w, uint32_t h,
                            VkFormat format,
                            VkImageUsageFlags usage,
                            uint32_t mip_levels)
{
    img.width      = w;
    img.height     = h;
    img.format     = format;
    img.mip_levels = mip_levels;

    VkImageCreateInfo img_info{};
    img_info.sType         = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    img_info.imageType     = VK_IMAGE_TYPE_2D;
    img_info.format        = format;
    img_info.extent        = {w, h, 1};
    img_info.mipLevels     = mip_levels;
    img_info.arrayLayers   = 1;
    img_info.samples       = VK_SAMPLE_COUNT_1_BIT;
    img_info.tiling        = VK_IMAGE_TILING_OPTIMAL;
    img_info.usage         = usage;
    img_info.sharingMode   = VK_SHARING_MODE_EXCLUSIVE;
    img_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;

    if (vkCreateImage(m_device, &img_info, nullptr, &img.handle) != VK_SUCCESS)
        return false;

    VkMemoryRequirements req;
    vkGetImageMemoryRequirements(m_device, img.handle, &req);

    VkMemoryAllocateInfo alloc{};
    alloc.sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    alloc.allocationSize  = req.size;
    alloc.memoryTypeIndex = FindMemoryType(req.memoryTypeBits,
                                           VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    if (vkAllocateMemory(m_device, &alloc, nullptr, &img.memory) != VK_SUCCESS)
        return false;

    if (vkBindImageMemory(m_device, img.handle, img.memory, 0) != VK_SUCCESS)
        return false;

    // Create image view
    bool is_depth = (format == VK_FORMAT_D32_SFLOAT ||
                     format == VK_FORMAT_D32_SFLOAT_S8_UINT ||
                     format == VK_FORMAT_D24_UNORM_S8_UINT);

    VkImageViewCreateInfo view_info{};
    view_info.sType    = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    view_info.image    = img.handle;
    view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
    view_info.format   = format;
    view_info.subresourceRange.aspectMask =
        is_depth ? VK_IMAGE_ASPECT_DEPTH_BIT : VK_IMAGE_ASPECT_COLOR_BIT;
    view_info.subresourceRange.baseMipLevel   = 0;
    view_info.subresourceRange.levelCount     = mip_levels;
    view_info.subresourceRange.baseArrayLayer = 0;
    view_info.subresourceRange.layerCount     = 1;

    if (vkCreateImageView(m_device, &view_info, nullptr, &img.view) != VK_SUCCESS) {
        TLOG_ERR(MOD, "Failed to create image view");
        return false;
    }

    // Create sampler
    VkSamplerCreateInfo samp_info{};
    samp_info.sType        = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO;
    samp_info.magFilter    = VK_FILTER_LINEAR;
    samp_info.minFilter    = VK_FILTER_LINEAR;
    samp_info.mipmapMode   = VK_SAMPLER_MIPMAP_MODE_LINEAR;
    samp_info.addressModeU = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    samp_info.addressModeV = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    samp_info.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    samp_info.anisotropyEnable = VK_TRUE;
    samp_info.maxAnisotropy    = 16.0f;
    samp_info.maxLod           = static_cast<float>(mip_levels);
    samp_info.borderColor      = VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;

    if (vkCreateSampler(m_device, &samp_info, nullptr, &img.sampler) != VK_SUCCESS) {
        TLOG_ERR(MOD, "Failed to create sampler");
        return false;
    }
    return true;
}

bool Renderer::UploadMesh(RenderObject& obj,
                           const std::vector<Vertex>& verts,
                           const std::vector<uint32_t>& indices)
{
    // Vertex buffer
    VkDeviceSize vb_size = sizeof(Vertex) * verts.size();
    CreateBuffer(obj.vertex_buffer, vb_size,
                 VK_BUFFER_USAGE_VERTEX_BUFFER_BIT |
                 VK_BUFFER_USAGE_TRANSFER_DST_BIT);

    // Index buffer
    VkDeviceSize ib_size = sizeof(uint32_t) * indices.size();
    CreateBuffer(obj.index_buffer, ib_size,
                 VK_BUFFER_USAGE_INDEX_BUFFER_BIT |
                 VK_BUFFER_USAGE_TRANSFER_DST_BIT);

    obj.index_count = static_cast<uint32_t>(indices.size());

    // Upload via staging buffer
    GpuBuffer staging;
    CreateBuffer(staging, vb_size + ib_size,
                 VK_BUFFER_USAGE_TRANSFER_SRC_BIT, true);

    memcpy(staging.mapped_ptr, verts.data(), vb_size);
    memcpy(static_cast<uint8_t*>(staging.mapped_ptr) + vb_size,
           indices.data(), ib_size);

    VkCommandBuffer cmd = BeginSingleCommand();
    VkBufferCopy copy_vb{0, 0, vb_size};
    VkBufferCopy copy_ib{vb_size, 0, ib_size};
    vkCmdCopyBuffer(cmd, staging.handle, obj.vertex_buffer.handle, 1, &copy_vb);
    vkCmdCopyBuffer(cmd, staging.handle, obj.index_buffer.handle,  1, &copy_ib);
    EndSingleCommand(cmd);

    DestroyBuffer(staging);
    return true;
}

// ============================================================
// HELPERS
// ============================================================
uint32_t Renderer::FindMemoryType(uint32_t filter,
                                   VkMemoryPropertyFlags props)
{
    VkPhysicalDeviceMemoryProperties mem_props;
    vkGetPhysicalDeviceMemoryProperties(m_gpu, &mem_props);

    for (uint32_t i = 0; i < mem_props.memoryTypeCount; i++) {
        if ((filter & (1 << i)) &&
            (mem_props.memoryTypes[i].propertyFlags & props) == props)
            return i;
    }
    return 0;
}

VkFormat Renderer::FindDepthFormat() {
    for (VkFormat fmt : {VK_FORMAT_D32_SFLOAT,
                         VK_FORMAT_D32_SFLOAT_S8_UINT,
                         VK_FORMAT_D24_UNORM_S8_UINT})
    {
        VkFormatProperties props;
        vkGetPhysicalDeviceFormatProperties(m_gpu, fmt, &props);
        if (props.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT)
            return fmt;
    }
    return VK_FORMAT_D32_SFLOAT;
}

VkCommandBuffer Renderer::BeginSingleCommand() {
    VkCommandBufferAllocateInfo alloc{};
    alloc.sType              = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    alloc.commandPool        = m_cmd_pool;
    alloc.level              = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;

    VkCommandBuffer cmd = VK_NULL_HANDLE;
    if (vkAllocateCommandBuffers(m_device, &alloc, &cmd) != VK_SUCCESS) {
        TLOG_ERR(MOD, "BeginSingleCommand: failed to allocate command buffer");
        return VK_NULL_HANDLE;
    }

    VkCommandBufferBeginInfo begin{};
    begin.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    if (vkBeginCommandBuffer(cmd, &begin) != VK_SUCCESS) {
        TLOG_ERR(MOD, "BeginSingleCommand: vkBeginCommandBuffer failed");
        vkFreeCommandBuffers(m_device, m_cmd_pool, 1, &cmd);
        return VK_NULL_HANDLE;
    }
    return cmd;
}

void Renderer::EndSingleCommand(VkCommandBuffer cmd) {
    vkEndCommandBuffer(cmd);

    VkSubmitInfo submit{};
    submit.sType              = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submit.commandBufferCount = 1;
    submit.pCommandBuffers    = &cmd;

    vkQueueSubmit(m_graphics_queue, 1, &submit, VK_NULL_HANDLE);
    vkQueueWaitIdle(m_graphics_queue);
    vkFreeCommandBuffers(m_device, m_cmd_pool, 1, &cmd);
}

void Renderer::TransitionImage(VkCommandBuffer cmd,
                                VkImage image,
                                VkImageLayout from,
                                VkImageLayout to)
{
    VkImageMemoryBarrier barrier{};
    barrier.sType               = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    barrier.oldLayout           = from;
    barrier.newLayout           = to;
    barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    barrier.image               = image;

    // Pick correct aspect: depth layouts → DEPTH_BIT, else COLOR_BIT
    bool is_depth = (to   == VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL  ||
                     to   == VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL   ||
                     from == VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL  ||
                     from == VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL);

    barrier.subresourceRange.aspectMask     = is_depth
        ? VK_IMAGE_ASPECT_DEPTH_BIT
        : VK_IMAGE_ASPECT_COLOR_BIT;
    barrier.subresourceRange.baseMipLevel   = 0;
    barrier.subresourceRange.levelCount     = 1;
    barrier.subresourceRange.baseArrayLayer = 0;
    barrier.subresourceRange.layerCount     = 1;

    // Access masks: ALL_COMMANDS is correct for a general-purpose barrier.
    // Specific stage masks can be narrowed later for performance.
    barrier.srcAccessMask = VK_ACCESS_MEMORY_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;

    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
        VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
        0, 0, nullptr, 0, nullptr, 1, &barrier);
}

// ============================================================
// DESTROY
// ============================================================
void Renderer::DestroyBuffer(GpuBuffer& buf) {
    if (buf.mapped_ptr) vkUnmapMemory(m_device, buf.memory);
    if (buf.handle != VK_NULL_HANDLE) vkDestroyBuffer(m_device, buf.handle, nullptr);
    if (buf.memory != VK_NULL_HANDLE) vkFreeMemory(m_device, buf.memory, nullptr);
    buf = {};
}

void Renderer::DestroyImage(GpuImage& img) {
    if (img.sampler != VK_NULL_HANDLE) vkDestroySampler(m_device, img.sampler, nullptr);
    if (img.view    != VK_NULL_HANDLE) vkDestroyImageView(m_device, img.view, nullptr);
    if (img.handle  != VK_NULL_HANDLE) vkDestroyImage(m_device, img.handle, nullptr);
    if (img.memory  != VK_NULL_HANDLE) vkFreeMemory(m_device, img.memory, nullptr);
    img = {};
}

void Renderer::DestroyObject(RenderObject& obj) {
    DestroyBuffer(obj.vertex_buffer);
    DestroyBuffer(obj.index_buffer);
}

void Renderer::CleanupSwapchain() {
    for (auto& frame : m_frames) {
        if (frame.framebuffer != VK_NULL_HANDLE)
            vkDestroyFramebuffer(m_device, frame.framebuffer, nullptr);
        if (frame.view != VK_NULL_HANDLE)
            vkDestroyImageView(m_device, frame.view, nullptr);
    }
    if (m_swapchain != VK_NULL_HANDLE)
        vkDestroySwapchainKHR(m_device, m_swapchain, nullptr);
}

void Renderer::RecreateSwapchain() {
    vkDeviceWaitIdle(m_device);
    CleanupSwapchain();
    CreateSwapchain(m_width, m_height);
}

void Renderer::OnResize(int w, int h) {
    m_width  = w;
    m_height = h;
    RecreateSwapchain();
    CreateRenderTargets();
    TLOG_INFO(MOD, "Resized: " + std::to_string(w) + "x" + std::to_string(h));
}

void Renderer::SetQuality(QualityTier tier) {
    m_tier = tier;
    switch (tier) {
        case QualityTier::MEDIUM: m_settings = QualitySettings::Medium(); break;
        case QualityTier::HIGH:   m_settings = QualitySettings::High();   break;
        case QualityTier::ULTRA:  m_settings = QualitySettings::Ultra();  break;
    }
    vkDeviceWaitIdle(m_device);
    CreateRenderTargets();
    TLOG_INFO(MOD, "Quality changed — recreating targets");
}

void Renderer::SetCustomSettings(const QualitySettings& s) {
    m_settings = s;
}

void Renderer::PrintStats() const {
    TLOG_INFO(MOD, "FPS:" + std::to_string(m_stats.fps)
                 + " DrawCalls:" + std::to_string(m_stats.draw_calls)
                 + " Tris:" + std::to_string(m_stats.triangles)
                 + " GPU:" + std::to_string(static_cast<int>(m_stats.gpu_time_ms)) + "ms"
                 + " CPU:" + std::to_string(static_cast<int>(m_stats.cpu_time_ms)) + "ms");
}

// ============================================================
// SHUTDOWN
// ============================================================
void Renderer::Shutdown() {
    if (!m_ready.load()) return;
    m_ready.store(false);

    vkDeviceWaitIdle(m_device);

    // Destroy render targets
    DestroyImage(m_gbuffer.albedo_metallic);
    DestroyImage(m_gbuffer.normal_roughness);
    DestroyImage(m_gbuffer.emissive_ao);
    DestroyImage(m_gbuffer.depth);
    DestroyImage(m_hdr_target);
    DestroyImage(m_ssao_target);
    DestroyImage(m_shadow_map);
    DestroyImage(m_bloom_target);
    DestroyImage(m_taa_history);
    DestroyImage(m_cloud_target);
    DestroyImage(m_ssr_target);

    // BUG 4+12 FIX: Destroy the framebuffers we now properly create
    if (m_gbuffer.framebuffer  != VK_NULL_HANDLE) vkDestroyFramebuffer(m_device, m_gbuffer.framebuffer,  nullptr);
    if (m_shadow_framebuffer   != VK_NULL_HANDLE) vkDestroyFramebuffer(m_device, m_shadow_framebuffer,   nullptr);

    // Destroy pipelines and shaders
    for (auto& [name, pipe] : m_pipelines)    vkDestroyPipeline(m_device, pipe, nullptr);
    for (auto& [name, lay]  : m_pipe_layouts) vkDestroyPipelineLayout(m_device, lay, nullptr);
    for (auto& [name, sh]   : m_shaders)      vkDestroyShaderModule(m_device, sh, nullptr);

    // Destroy render passes
    if (m_shadow_pass      != VK_NULL_HANDLE) vkDestroyRenderPass(m_device, m_shadow_pass,       nullptr);
    if (m_gbuffer.render_pass != VK_NULL_HANDLE) vkDestroyRenderPass(m_device, m_gbuffer.render_pass, nullptr); // NEW-1 FIX
    if (m_lighting_pass    != VK_NULL_HANDLE) vkDestroyRenderPass(m_device, m_lighting_pass,     nullptr);
    if (m_post_process_pass!= VK_NULL_HANDLE) vkDestroyRenderPass(m_device, m_post_process_pass, nullptr);

    // Destroy sync objects
    for (auto& frame : m_frames) {
        vkDestroySemaphore(m_device, frame.image_ready, nullptr);
        vkDestroySemaphore(m_device, frame.render_done, nullptr);
        vkDestroyFence    (m_device, frame.in_flight,   nullptr);
    }

    if (m_desc_pool != VK_NULL_HANDLE) vkDestroyDescriptorPool(m_device, m_desc_pool, nullptr);
    if (m_cmd_pool  != VK_NULL_HANDLE) vkDestroyCommandPool   (m_device, m_cmd_pool,  nullptr);

    CleanupSwapchain();

    if (m_surface  != VK_NULL_HANDLE) vkDestroySurfaceKHR(m_instance, m_surface,  nullptr);
    if (m_device   != VK_NULL_HANDLE) vkDestroyDevice    (m_device,               nullptr);
    if (m_instance != VK_NULL_HANDLE) vkDestroyInstance  (m_instance,             nullptr);

    TLOG_INFO(MOD, "Renderer shut down cleanly");
}

} // namespace TerraEngine
