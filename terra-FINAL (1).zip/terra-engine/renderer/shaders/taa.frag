// ============================================================
// TERRA ENGINE — TEMPORAL ANTI-ALIASING
// taa.frag — ALL TIERS
// ============================================================
// Accumulates multiple jittered frames for smooth edges.
// No MSAA cost. Handles ghosting with velocity rejection.
// Also resolves SSAO, SSR, and volumetric noise over time.
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;
layout(location = 0) out vec4 out_resolved;   // current frame output
layout(location = 1) out vec4 out_history;    // feedback to next frame

layout(set = 0, binding = 0) uniform sampler2D current_frame;
layout(set = 0, binding = 1) uniform sampler2D history_buffer;
layout(set = 0, binding = 2) uniform sampler2D velocity_buffer;
layout(set = 0, binding = 3) uniform sampler2D depth_buffer;

layout(set = 1, binding = 0) uniform TAAData {
    vec2  jitter;           // current frame sub-pixel jitter (Halton sequence)
    float blend_factor;     // 0.1 = smooth, 0.5 = responsive
    float sharpness;        // contrast-adaptive sharpening strength
    vec2  resolution;
    int   frame_count;
} taa;

// ============================================================
// NEIGHBOURHOOD CLAMP — prevents ghosting from fast motion
// AABB clamp in YCoCg colour space (better for luminance)
// ============================================================
vec3 RGBToYCoCg(vec3 rgb) {
    return vec3(
         0.25 * rgb.r + 0.5 * rgb.g + 0.25 * rgb.b,
        -0.25 * rgb.r + 0.5 * rgb.g - 0.25 * rgb.b,
         0.5  * rgb.r               - 0.5  * rgb.b
    );
}

vec3 YCoCgToRGB(vec3 ycocg) {
    return clamp(vec3(
        ycocg.x - ycocg.y + ycocg.z,
        ycocg.x + ycocg.y,
        ycocg.x - ycocg.y - ycocg.z
    ), 0.0, 1.0);
}

vec3 ClipAABB(vec3 q, vec3 aabb_min, vec3 aabb_max) {
    vec3  p_clip  = 0.5 * (aabb_max + aabb_min);
    vec3  e_clip  = 0.5 * (aabb_max - aabb_min) + 0.0001;
    vec3  v_clip  = q - p_clip;
    vec3  v_unit  = v_clip / e_clip;
    vec3  a_unit  = abs(v_unit);
    float ma_unit = max(a_unit.x, max(a_unit.y, a_unit.z));
    if (ma_unit > 1.0) return p_clip + v_clip / ma_unit;
    return q;
}

// ============================================================
// CONTRAST ADAPTIVE SHARPENING
// ============================================================
vec3 CAS(sampler2D tex, vec2 uv, float strength) {
    vec2 t    = 1.0 / taa.resolution;
    vec3 cen  = texture(tex, uv).rgb;
    vec3 top  = texture(tex, uv + vec2( 0, -t.y)).rgb;
    vec3 bot  = texture(tex, uv + vec2( 0,  t.y)).rgb;
    vec3 lft  = texture(tex, uv + vec2(-t.x,  0)).rgb;
    vec3 rgt  = texture(tex, uv + vec2( t.x,  0)).rgb;

    vec3 mn   = min(cen, min(min(top, bot), min(lft, rgt)));
    vec3 mx   = max(cen, max(max(top, bot), max(lft, rgt)));
    vec3 k    = -1.0 / (sqrt(clamp(min(mn, 2.0 - mx) / mx, 0.0, 1.0)) + 4.0);

    return clamp((cen * (1.0 - 4.0 * k * strength)
                + (top + bot + lft + rgt) * (k * strength))
                / (1.0 + 4.0 * k * strength - 4.0 * k * strength), 0.0, 1.0);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec2  t      = 1.0 / taa.resolution;

    // Sample 3x3 neighbourhood for AABB
    vec3  nmin   = vec3(1.0);
    vec3  nmax   = vec3(0.0);
    vec3  current = vec3(0.0);

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec3 s = RGBToYCoCg(
                texture(current_frame, in_uv + vec2(x, y) * t).rgb);
            nmin = min(nmin, s);
            nmax = max(nmax, s);
            if (x == 0 && y == 0) current = s;
        }
    }

    // Velocity for reprojection
    vec2  velocity = texture(velocity_buffer, in_uv).rg;
    vec2  prev_uv  = in_uv - velocity;

    // Disocclusion check — if history is invalid use current
    vec3  history_sample = vec3(0.0);
    float history_weight = taa.blend_factor;

    if (prev_uv.x >= 0.0 && prev_uv.x <= 1.0 &&
        prev_uv.y >= 0.0 && prev_uv.y <= 1.0) {
        history_sample = RGBToYCoCg(texture(history_buffer, prev_uv).rgb);

        // Clamp history to neighbourhood AABB — prevents ghosting
        history_sample = ClipAABB(history_sample, nmin, nmax);

        // Weight by velocity magnitude — fast motion uses less history
        float vel_len  = length(velocity) * 100.0;
        history_weight = mix(taa.blend_factor,
                             min(taa.blend_factor * 3.0, 0.5),
                             clamp(vel_len, 0.0, 1.0));
    } else {
        history_weight = 1.0; // no valid history = use current fully
        history_sample = current;
    }

    // Blend current with clamped history
    vec3 resolved = mix(history_sample, current, history_weight);
    resolved      = YCoCgToRGB(resolved);

    // Contrast adaptive sharpening (recovers TAA blur)
    resolved = mix(resolved,
                   CAS(current_frame, in_uv, 1.0),
                   taa.sharpness * 0.5);

    out_resolved = vec4(resolved, 1.0);
    out_history  = vec4(resolved, 1.0); // write back for next frame
}
